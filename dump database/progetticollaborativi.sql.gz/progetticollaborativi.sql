-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Lug 10, 2024 alle 20:21
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12
SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `progetticollaborativi`
--
CREATE DATABASE IF NOT EXISTS `progetticollaborativi` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `progetticollaborativi`;

DELIMITER $$
--
-- Procedure
--
DROP PROCEDURE IF EXISTS `OrdinaSchede`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `OrdinaSchede` ()   BEGIN
    DECLARE is_righe_finite INT DEFAULT FALSE;
    DECLARE progetto INT;
    DECLARE categoria VARCHAR(20) COLLATE utf8mb4_unicode_ci;
    DECLARE min_ordine INT;

    DECLARE cur CURSOR FOR SELECT DISTINCT id_progetto, stato FROM schede;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET is_righe_finite = TRUE;

    OPEN cur;

    ciclo_lettura: LOOP
        FETCH cur INTO progetto, categoria;
        IF is_righe_finite THEN
            LEAVE ciclo_lettura;
        END IF;

        -- Trovo il valore minimo di ordine_schede per la combinazione id_progetto e stato
        SELECT MIN(ordine_schede) INTO min_ordine FROM schede WHERE id_progetto = progetto AND stato = categoria;

        -- Decremento tutti gli ordini di min_ordine per la combinazione id_progetto e stato
        UPDATE schede SET ordine_schede = ordine_schede - min_ordine WHERE id_progetto = progetto AND stato = categoria;

        -- Assegno gli ordini incrementali partendo da 0
        SET @ordine := -1;
        UPDATE schede SET ordine_schede = (@ordine := @ordine + 1) WHERE id_progetto = progetto AND stato = categoria ORDER BY ordine_schede;

    END LOOP;

    CLOSE cur;
END$$

DROP PROCEDURE IF EXISTS `OrdinaSchedeSelettivo`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `OrdinaSchedeSelettivo` (IN `progetto` INT, IN `categoria` VARCHAR(20) COLLATE utf8mb4_unicode_ci)   BEGIN
    DECLARE min_ordine INT;

    -- Trovo il valore minimo di ordine_schede per la combinazione id_progetto e stato
    SELECT MIN(ordine_schede) INTO min_ordine FROM schede WHERE id_progetto = progetto AND stato = categoria;

    -- Decremento tutti gli ordini di min_ordine per la combinazione id_progetto e stato
    UPDATE schede SET ordine_schede = ordine_schede - min_ordine WHERE id_progetto = progetto AND stato = categoria;

    -- Assegno gli ordini incrementali partendo da 0
    SET @ordine := -1;
    UPDATE schede SET ordine_schede = (@ordine := @ordine + 1) WHERE id_progetto = progetto AND stato = categoria ORDER BY ordine_schede;

END$$

DROP PROCEDURE IF EXISTS `OrdinaStati`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `OrdinaStati` ()   BEGIN
    DECLARE is_righe_finite INT DEFAULT FALSE;
    DECLARE progetto INT;
    DECLARE min_ordine INT;
    DECLARE cur CURSOR FOR SELECT DISTINCT id_progetto FROM stati;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET is_righe_finite = TRUE;

    OPEN cur;

    ciclo_lettura: LOOP
        FETCH cur INTO progetto;
        IF is_righe_finite THEN
            LEAVE ciclo_lettura;
        END IF;

        -- Trovo il valore minimo di ordine_stati per la chiave esterna id_progetto 
        SELECT MIN(ordine_stati) INTO min_ordine FROM stati WHERE id_progetto = progetto;

        -- Decremento tutti gli ordini di min_ordine per la combinazione id_progetto
        UPDATE stati SET ordine_stati = ordine_stati - min_ordine WHERE id_progetto = progetto;

        -- Assegno gli ordini incrementali partendo da 0
        SET @ordine := -1;
        UPDATE stati SET ordine_stati = (@ordine := @ordine + 1) WHERE id_progetto = progetto ORDER BY ordine_stati;

    END LOOP;

    CLOSE cur;
END$$

DROP PROCEDURE IF EXISTS `OrdinaStatiSelettivo`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `OrdinaStatiSelettivo` (IN `progetto` INT)   BEGIN
    DECLARE min_ordine INT;

    -- Trovo il valore minimo di ordine_stati per la chiave esterna id_progetto 
    SELECT MIN(ordine_stati) INTO min_ordine FROM stati WHERE id_progetto = progetto;

    -- Decremento tutti gli ordini di min_ordine per la chiave esterna id_progetto
    UPDATE stati SET ordine_stati = ordine_stati - min_ordine WHERE id_progetto = progetto;

    -- Assegno gli ordini incrementali partendo da 0
    SET @ordine := -1;
    UPDATE stati SET ordine_stati = (@ordine := @ordine + 1) WHERE id_progetto = progetto ORDER BY ordine_stati;

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

DROP TABLE IF EXISTS `utenti`;
CREATE TABLE IF NOT EXISTS `utenti` (
  `uuid` binary(16) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `genere` enum('maschio','femmina') NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `ruolo` enum('admin','capo_team','utente') NOT NULL DEFAULT 'utente',
  `data_creazione` datetime DEFAULT current_timestamp(),
  `team` varchar(3) DEFAULT NULL,
  `ultimo_accesso` datetime DEFAULT NULL
) ;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`uuid`, `nome`, `cognome`, `genere`, `email`, `password`, `ruolo`, `data_creazione`, `team`, `ultimo_accesso`) VALUES
(0x11eeff47867d82d6876df02f74204fe8, 'Admin', 'Procol', 'maschio', 'admin@procol.com', '$2y$10$GX9ediqmlgA9QP9bxG3T/.mYzLidmjyXSAbq2D20nFc0gXF2V2hIK', 'admin', '2024-04-20 20:55:15', NULL, '2024-07-10 19:40:42'),
(0x11eeff542545ed77876df02f74204fe8, 'Luigi', 'Puca', 'maschio', 'goshin26@icloud.com', '$2y$10$x2rNg1emjidsQsMgfwFRGOHltS4bqXpw7qda4PW1.Bm0jeu1zQOpq', 'capo_team', '2024-04-20 22:25:36', 'PCU', '2024-07-10 19:42:11'),
(0x11ef023d904e450994eef02f74204fe8, 'Filomena', 'Marasco', 'femmina', 'filomena.marasco@procol.it', '$2y$10$mn4syjXCdK9vl3TgPDjM2.4cnvoMzTQypCSVG1g/3JnUiLFFzVH3G', 'capo_team', '2024-04-24 15:21:26', 'PCU', '2024-07-01 20:03:19'),
(0x11ef19fdc47427898123f02f74204fe8, 'Mario', 'Uno', 'maschio', 'utente.prova1@procol.com', '$2y$10$0ahx926ToYrsfaLNrmIES5ulspB6dX0UNHBewc4loV92BwkY7q7U/2', 'capo_team', '2024-05-24 20:45:14', 'MVN', NULL),
(0x11ef19fdcdd49fc18123f02f74204fe8, 'Maria', 'Due', 'femmina', 'utente.prova2@procol.com', '$2y$10$0ahx926ToYwfaLNrmIES5ulspB6dX0UNHBewc4loV92BwkY7q7U^s', 'capo_team', '2024-05-24 20:45:29', 'CAI', NULL),
(0x11ef37cd23a939c78309f02f74204fe8, 'Luigi', 'Puca', 'maschio', 'luigi.puca@procol.com', '$2y$10$dWQ2cwt4lEZ3Bvd5jKp.KOOvaXoEFEPdlZf9IjsFlyWq7D/6F9/IC', 'utente', '2024-07-01 19:12:39', NULL, '2024-07-08 14:18:01'),
(0x11ef3af4593d05608309f02f74204fe8, 'Imma', 'Capuano', 'femmina', 'imma.capuano@procol.com', '$2y$10$0ahx926ToYwfaLNrmIES5ulspB6dX0UNHBewc4loV92BwkY7q7U/2', 'capo_team', '2024-07-05 19:30:47', 'GFS', '2024-07-05 19:33:51'),
(0x11ef3b036fcc77258309f02f74204fe8, 'Luigi', 'Campi', 'maschio', 'luigi.campi@procol.com', '$2y$10$F581k5spG4y5xhcMqG2Yse3zN47fKZ0HWzK9hsqc9VxEaMFScM/sO', 'utente', '2024-07-05 21:18:47', 'GFS', '2024-07-05 22:01:07'),
(0x11ef3d18fdecdb9c8309f02f74204fe8, 'Alberto', 'De Luca', 'maschio', 'alberto.deluca@procol.com', '$2y$10$lz3hVtSBCOWhzIzL67APW.rEzWNiYuCpBljjQe/fHF2akF3YbnM3G', 'utente', '2024-07-08 12:58:03', 'QWO', NULL),
(0x11ef3d193f7587bc8309f02f74204fe8, 'Martina', 'Venturini', 'femmina', 'martina.venturini@procol.com', '$2y$10$IQAh/cfd1XGVBT3e4v6O9.hmGXJudrxFljKh3kcxu0ClmcJxLAY6m', 'utente', '2024-07-08 12:59:53', 'GFS', NULL),
(0x11ef3d1959716cdc8309f02f74204fe8, 'Gian Domenico', 'Riccardo', 'maschio', 'giandomenico.riccardo@procol.com', '$2y$10$KXaHFrPqNDkiMePMK7n/0.IUhbGhYMkTzKJp3L232u/DKr5kPf.cC', 'utente', '2024-07-08 13:00:37', 'GFS', NULL),
(0x11ef3d19d17867f08309f02f74204fe8, 'Marco', 'Rossi', 'maschio', 'marco.rossi@procol.com', '$2y$10$Qj.7XMp7lRORumEM5hR/7uMw5xEW.Ed29OcXucDrO/PAsvD0Xbf1C', 'capo_team', '2024-07-08 13:03:58', 'LUF', NULL),
(0x11ef3d19e23852018309f02f74204fe8, 'Luca', 'Bianchi', 'maschio', 'luca.bianchi@procol.com', '$2y$10$XXR9pvbQ/XGnD1/bNDjFcOMIsCmTcer7spxIWJqUvGia5MokFVFNW', 'capo_team', '2024-07-08 13:04:26', 'SLX', NULL),
(0x11ef3d1a1721b95b8309f02f74204fe8, 'Giulia', 'Verdi', 'femmina', 'giulia.verdi@procol.com', '$2y$10$GGY6PEM8Uq/EARDkUu9X.ORg3FqnsuZOEhCex.0izNMSIOYbqfXcq', 'capo_team', '2024-07-08 13:05:55', 'QWO', NULL),
(0x11ef3d1a30bccc0d8309f02f74204fe8, 'Francesca', 'Neri', 'femmina', 'francesca.neri@procol.com', '$2y$10$.hzmSbNmRTVzQOhXe4HHsOyHDfOz62KDTFMacEzBpe9IOF6xpT6Ja', 'capo_team', '2024-07-08 13:06:38', 'CRH', '2024-07-10 02:28:53'),
(0x11ef3d1a43e272df8309f02f74204fe8, 'Andrea', 'Conti', 'maschio', 'andre.conti@procol.com', '$2y$10$dp3v0wkQWtZTUxGPBodx7.1U3CmkOZ.GrlLzN23h/sGYsx7K2LFNW', 'capo_team', '2024-07-08 13:07:10', 'GPH', NULL),
(0x11ef3d1a6741e59b8309f02f74204fe8, 'Valentina', 'Esposito', 'femmina', 'valentina.esposito@procol.com', '$2y$10$TVufQQOeyXBQkdtK9wdWuutVA2VGsIjiBnLLZ9TVq4/gw2ZeC03ze', 'capo_team', '2024-07-08 13:08:09', 'MYT', NULL),
(0x11ef3d1a93376ca48309f02f74204fe8, 'Federico', 'Greco', 'maschio', 'federico.greco@procol.com', '$2y$10$ORITubzJ0316PNVLvLl68.nChqI27YGDCfqyFuKImot45Jz3PyVza', 'capo_team', '2024-07-08 13:09:23', 'ETE', NULL),
(0x11ef3d1ab097ec668309f02f74204fe8, 'Elena', 'Ferri', 'femmina', 'elena.ferri@procol.com', '$2y$10$YqI58cgHwkqz65y1SMh70ukOku3OEEX9ko.Tk07X4tmZ5Qwq6ruPi', 'utente', '2024-07-08 13:10:12', 'SLX', NULL),
(0x11ef3d1ac2f87a418309f02f74204fe8, 'Simone', 'Lombardi', 'maschio', 'simone.lombardi@procol.com', '$2y$10$F8ZTZwOT844iUIXOPJAGWePyVqOBTrdnPl5iqcuUNtlLQDrw7s672', 'utente', '2024-07-08 13:10:43', 'CRH', '2024-07-09 20:15:53'),
(0x11ef3d1add1fb4078309f02f74204fe8, 'Alessia', 'Marino', 'femmina', 'alessia.marino@procol.com', '$2y$10$pEteu4w8KQCI6sMGqD7BhOtecUFyBX/s9T4wAw4W7PyB41qqTv90C', 'utente', '2024-07-08 13:11:27', 'NBD', NULL),
(0x11ef3d1af6c70e5a8309f02f74204fe8, 'Matteo', 'Ricci', 'maschio', 'matteo.ricci@procol.com', '$2y$10$O/tvpSx8BNYuR61UY1CxQ.dOqgkUZ1xpUIMkhUBXUBnIncBLpjjGm', 'utente', '2024-07-08 13:12:10', 'MYT', NULL),
(0x11ef3d1b159e46348309f02f74204fe8, 'Sara', 'Moretti', 'maschio', 'sara.moretti@procol.com', '$2y$10$FxS5ZXHLI2Bd6K74wvP3suM3ce3AdXm/MkXvPtPb0qETKsLxvMeoO', 'utente', '2024-07-08 13:13:02', 'LUF', NULL),
(0x11ef3d1b353ffe318309f02f74204fe8, 'Davide', 'Gallo', 'maschio', 'davide.gallo@procol.com', '$2y$10$VnKJ/8coevfoghhp48PdI.0tSY.hUgWBcO3NenTv7vMas1a0E5z4W', 'utente', '2024-07-08 13:13:55', 'LUF', NULL),
(0x11ef3d1b43e63f0e8309f02f74204fe8, 'Chiara', 'Pellegrini', 'femmina', 'chiara.pellegrini@procol.com', '$2y$10$eXheR8HAzzsjQO5dwf3VguNhgrZfXI94l5yQ6FWzOLAXSUcr9oRvO', 'utente', '2024-07-08 13:14:19', 'ETE', NULL),
(0x11ef3d1b702d46e98309f02f74204fe8, 'Laura', 'Gatti', 'femmina', 'laura.gatti@procol.com', '$2y$10$NQXCYHiNYn.SZcVnYfq2hORpvhyg/q4nG5V.mYJ2VzSh9QSy6kEHK', 'utente', '2024-07-08 13:15:34', 'ETE', NULL),
(0x11ef3d1b880de9eb8309f02f74204fe8, 'Stefano', 'Romano', 'femmina', 'stefano.romano@procol.com', '$2y$10$soq3gEnn7gyJ2usA7db2ou89njzgLeCFxr02CEQbNV3DGOBG20k2y', 'capo_team', '2024-07-08 13:16:14', 'NBD', '2024-07-09 19:51:21'),
(0x11ef3d1bb08b7b748309f02f74204fe8, 'Martina', 'Sanna', 'femmina', 'martina.sanna@procol.com', '$2y$10$LAHhgn6QDV71Dmxp8j/i6ufYKsuystCGAUPuddvH7g8GC36U5vd16', 'utente', '2024-07-08 13:17:22', 'GPH', NULL),
(0x11ef3d1bca86be128309f02f74204fe8, 'Carlo', 'Barbieri', 'maschio', 'carlo.barbieri@procol.com', '$2y$10$CktLeZBAFowf28ipjXMK9emlz1iX.A7hquUvjhhwEAkphoCAbTzvG', 'utente', '2024-07-08 13:18:05', 'CRH', '2024-07-09 20:16:10'),
(0x11ef3d1bdb9e56898309f02f74204fe8, 'Beatrice', 'Ruggieri', 'femmina', 'beatrice.ruggieri@procol.com', '$2y$10$C7AB2UgFTZYy3ZUJEdSI9uDINNutBkxJ2gUU0g8u8xuiPexreT/mS', 'utente', '2024-07-08 13:18:34', 'LUF', NULL),
(0x11ef3d1c12a879c98309f02f74204fe8, 'Enrico', 'Costantini', 'maschio', 'enrico.costantini@procol.com', '$2y$10$c25r9GOGefVz0xPH9osLS.FdMRCovi.XS2jEESvL5w/J3QUMqd7ee', 'utente', '2024-07-08 13:20:06', 'QWO', NULL),
(0x11ef3d1c2ae9a4ab8309f02f74204fe8, 'Roberta', 'Fabbri', 'femmina', 'roberta.fabbri@procol.com', '$2y$10$d19a223wQvGBVMkyTrhcSeWpOQTIh2RpIdlQLXp0sJz7buePo8xGK', 'utente', '2024-07-08 13:20:47', 'GPH', NULL),
(0x11ef3d1c3e7280aa8309f02f74204fe8, 'Giorgio', 'Amato', 'maschio', 'giorgio.amato@procol.com', '$2y$10$pxHP8pzvNd9vtZbwU9z/E.0tGFAZmUC/.s44qeQ2d74tKgTa9rOk2', 'utente', '2024-07-08 13:21:20', 'MYT', NULL),
(0x11ef3d1c4c1fd52a8309f02f74204fe8, 'Anna', 'Parisi', 'femmina', 'anna.parisi@procol.com', '$2y$10$AR3jNnwvzBYUOqvAnQ7oAOR1ykhK2qcgAMg4zeBrdh/lYRj86onUa', 'utente', '2024-07-08 13:21:43', 'SLX', NULL),
(0x11ef3d1c5f7e09ec8309f02f74204fe8, 'Tommaso', 'Valli', 'maschio', 'tommaso.valli@procol.com', '$2y$10$WgL0AqeuLPX/8bTx.UWHPuyxEP7LDxZn25gSDnAabFnJwO6g0Ftd6', 'utente', '2024-07-08 13:22:15', 'QWO', NULL),
(0x11ef3ee324887bc18309f02f74204fe8, 'Antimo', 'Puca', 'maschio', 'antimo.puca@procol.com', '$2y$10$3CESuB5D89zXO0BdElhXLuvOkoTSnoe8EnDWXYtV6SXv1SUItvkym', 'utente', '2024-07-10 19:37:34', 'PCU', NULL),
(0x11ef3ee35167d6928309f02f74204fe8, 'Giuseppina', 'Puca', 'femmina', 'giuseppina.puca@procol.com', '$2y$10$x/lxaZp7MJPqN4Bz/EOh7eCr4n/yIle9ip9pX5lEe7kuBeeVVyM0y', 'utente', '2024-07-10 19:38:49', 'PCU', NULL),
(0x11ef3ee371dde3dc8309f02f74204fe8, 'Giovanni', 'Puca', 'maschio', 'giovanni.puca@procol.com', '$2y$10$BM1v8b63i0cPwxDBJGLMJuS21oGaxBkHz1Xb1Uw8mkcgS55oRxicS', 'utente', '2024-07-10 19:39:44', 'PCU', NULL);

--
-- Trigger `utenti`
--
DROP TRIGGER IF EXISTS `anticipo_inserimento`;
DELIMITER $$
CREATE TRIGGER `anticipo_inserimento` BEFORE INSERT ON `utenti` FOR EACH ROW BEGIN
	SET @uuid = UUID();
	SET NEW.uuid = UNHEX(CONCAT(
		SUBSTR(@uuid, 15, 4),
		SUBSTR(@uuid, 10, 4),
		SUBSTR(@uuid, 1, 8),
		SUBSTR(@uuid, 20, 4),
		SUBSTR(@uuid, 25))
	);
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `valida_appartenenza_team`;
DELIMITER $$
CREATE TRIGGER `valida_appartenenza_team` BEFORE INSERT ON `utenti` FOR EACH ROW BEGIN
    DECLARE team_count INT;
    IF NEW.team IS NOT NULL THEN
        SET team_count = (SELECT COUNT(*) FROM team WHERE sigla = NEW.team);
        IF team_count = 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Nessun team ha la sigla specificata.';
        END IF;
    END IF;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `valida_appartenenza_team_anticipa_update`;
DELIMITER $$
CREATE TRIGGER `valida_appartenenza_team_anticipa_update` BEFORE UPDATE ON `utenti` FOR EACH ROW BEGIN
    DECLARE team_count INT;
    IF NEW.team IS NOT NULL THEN
        SET team_count = (SELECT COUNT(*) FROM team WHERE sigla = NEW.team);
        IF team_count = 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Nessun team ha la sigla specificata.';
        END IF;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struttura della tabella `progetti`
--

DROP TABLE IF EXISTS `progetti`;
CREATE TABLE IF NOT EXISTS `progetti` (
  `id_progetto` int(11) NOT NULL,
  `PROGETTO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `descrizione` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `scadenza` datetime NOT NULL,
  `team_responsabile` varchar(3) DEFAULT NULL
) ;

--
-- Dump dei dati per la tabella `progetti`
--

INSERT INTO `progetti` (`id_progetto`, `PROGETTO`, `descrizione`, `scadenza`, `team_responsabile`) VALUES
(14, 'sql', '', '2024-08-27 12:41:48', NULL),
(15, 'Progetto Collaborativo', '', '2024-05-21 19:43:00', 'PCU'),
(24, 'Miglioramento della Customer Experience', 'Iniziative per aumentare la soddisfazione e la fedeltà dei clienti attraverso un servizio migliore e personalizzato.', '2025-05-23 21:38:00', NULL),
(25, 'Analisi dei Big Data', 'Utilizzo di tecniche di analisi dei big data per ottenere informazioni utili e migliorare le decisioni strategiche aziendali.', '2025-05-13 23:09:25', NULL),
(27, 'Miglioramento UX UI', 'Revisione e ottimizzazione dell\'interfaccia utente e dell\'esperienza utente per aumentare la soddisfazione dei clienti.', '2024-05-13 23:44:28', NULL),
(35, 'Rebranding Aziendale', 'Rinnovamento dell\'immagine aziendale per riflettere una nuova visione o strategia di mercato.', '2025-05-17 18:45:51', 'LUF'),
(39, 'Sviluppo App Mobile', 'Creazione di un\'applicazione mobile per migliorare l\'accesso ai servizi aziendali e interagire con i clienti.', '2025-01-01 00:00:00', NULL),
(40, 'Implementazione di Blockchain', 'Adozione della tecnologia blockchain per migliorare la sicurezza e la trasparenza delle transazioni aziendali.', '2025-01-01 00:00:00', NULL),
(41, 'Implementazione IoT', 'Utilizzo di dispositivi Internet of Things per migliorare la raccolta di dati e il monitoraggio delle operazioni aziendali.', '2040-01-01 00:00:00', 'NBD'),
(42, 'Formazione del Personale', '', '2070-01-01 00:00:00', 'CRH'),
(45, 'Ottimizzazione della Supply Chain', 'Revisione e miglioramento della catena di approvvigionamento per ridurre i costi e aumentare la velocità di consegna.', '2090-01-01 00:00:00', NULL),
(46, 'Progetto Green Energy', 'Promuoviamo l\'uso di fonti di energia rinnovabile e sostenibile, come solare, eolica e idroelettrica, per ridurre l\'impatto ambientale e le emissioni del gas serra', '2070-01-01 00:00:00', 'CRH'),
(47, 'Strategia di Marketing Digitale', 'Creazione di un piano di marketing digitale per aumentare la visibilità online e attrarre nuovi clienti.', '2070-01-01 00:00:00', 'ETE'),
(49, 'Ristrutturazione Server', 'Miglioramento e aggiornamento dei server aziendali per incrementare la capacità e la sicurezza.', '2070-01-01 00:00:00', 'LUF'),
(50, 'Sviluppo Software Interno', 'Creazione di un\'applicazione mobile per migliorare l\'accesso ai servizi aziendali e interagire con i clienti.', '2070-01-01 00:00:00', 'ETE'),
(52, 'Analisi di Mercato', 'Raccolta e analisi di dati di mercato per identificare nuove opportunità di business e tendenze del settore.', '2024-07-30 00:00:00', 'GPH'),
(55, 'Progetto Innovazione Prodotti', 'Sviluppo di nuovi prodotti o miglioramento di quelli esistenti per mantenere la competitività sul mercato.', '2040-01-01 00:00:00', NULL),
(57, 'Progetto AI', 'Sperimentazione di tecnologie di intelligenza artificiale per automatizzare processi e migliorare il decision-making.', '2024-06-07 00:00:00', 'CAI'),
(60, 'Metaverso', 'ah', '2090-01-01 00:00:00', NULL),
(61, 'Realtà Aumentata', '', '2024-07-15 00:00:00', 'MVN'),
(64, 'Realtà Virtuale', '', '2040-01-01 00:00:00', NULL),
(74, 'Giando Fa Schifo', '', '2024-07-05 19:32:18', 'GFS');

--
-- Trigger `progetti`
--
DROP TRIGGER IF EXISTS `conteggio_progetti_post_aggiornamento`;
DELIMITER $$
CREATE TRIGGER `conteggio_progetti_post_aggiornamento` AFTER UPDATE ON `progetti` FOR EACH ROW BEGIN
    
        UPDATE team
        SET numero_progetti = numero_progetti - 1
        WHERE sigla = OLD.team_responsabile;
        
        UPDATE team
        SET numero_progetti = numero_progetti + 1
        WHERE sigla = NEW.team_responsabile;
    
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `conteggio_progetti_post_eliminazione`;
DELIMITER $$
CREATE TRIGGER `conteggio_progetti_post_eliminazione` AFTER DELETE ON `progetti` FOR EACH ROW BEGIN
    UPDATE team
    SET numero_progetti = numero_progetti - 1
    WHERE sigla = OLD.team_responsabile;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `conteggio_progetti_post_inserimento`;
DELIMITER $$
CREATE TRIGGER `conteggio_progetti_post_inserimento` AFTER INSERT ON `progetti` FOR EACH ROW BEGIN
    UPDATE team
    SET numero_progetti = numero_progetti + 1
    WHERE sigla = NEW.team_responsabile;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `crea_tuple_stati`;
DELIMITER $$
CREATE TRIGGER `crea_tuple_stati` AFTER INSERT ON `progetti` FOR EACH ROW BEGIN
    INSERT INTO stati (id_progetto, stato, colore_hex, ordine_stati, visibile)
    VALUES (NEW.id_progetto, 'In Corso', '#FFA500FF', 0, TRUE),
           (NEW.id_progetto, 'In Attesa', '#FFFF00FF', 1, TRUE),
           (NEW.id_progetto, 'Completate', '#00FF00FF', 2, TRUE),
           (NEW.id_progetto, 'In Ritardo', '#FF0000FF', 3, TRUE),
           (NEW.id_progetto, 'Eliminate', '#808080FF', 4, FALSE);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struttura della tabella `commenti`
--

DROP TABLE IF EXISTS `commenti`;
CREATE TABLE IF NOT EXISTS `commenti` (
  `uuid_commento` binary(16) NOT NULL,
  `uuid_scheda` binary(16) NOT NULL,
  `contenuto` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Commento Eliminato',
  `mittente` varchar(255) DEFAULT NULL,
  `inviato` datetime NOT NULL DEFAULT current_timestamp(),
  `destinatario` varchar(255) DEFAULT NULL,
  `modificato_da` varchar(255) DEFAULT NULL,
  `modificato_il` datetime DEFAULT NULL,
  `uuid_in_risposta` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


--
-- Dump dei dati per la tabella `commenti`
--

INSERT INTO `commenti` (`uuid_commento`, `uuid_scheda`, `contenuto`, `mittente`, `inviato`, `destinatario`, `modificato_da`, `modificato_il`, `uuid_in_risposta`) VALUES
(0x11ef3570f0cefacc8309f02f74204fe8, 0x11ef34eb93b6eb178309f02f74204fe8, 'ciao', 'goshin26@icloud.com', '2024-06-28 19:07:42', NULL, NULL, NULL, NULL),
(0x11ef3571107f1fbb8309f02f74204fe8, 0x11ef34eb93b6eb178309f02f74204fe8, 'dobbiamo controllare il database', 'goshin26@icloud.com', '2024-06-28 19:08:35', NULL, NULL, NULL, NULL),
(0x11ef3807ff18e2948309f02f74204fe8, 0x11ef34eb93b6eb178309f02f74204fe8, 'prova', 'goshin26@icloud.com', '2024-07-02 02:13:58', NULL, NULL, NULL, NULL),
(0x11ef3d247a2b83728309f02f74204fe8, 0x11ef0bebc48c857e813af02f74204fe8, 'tabella utenti creata', 'goshin26@icloud.com', '2024-07-02 14:20:16', NULL, NULL, NULL, NULL),
(0x11ef3d247e1b6db68309f02f74204fe8, 0x11ef0bebc48c857e813af02f74204fe8, 'tabella utenti finita', 'goshin26@icloud.com', '2024-07-02 14:20:23', NULL, NULL, NULL, NULL),
(0x11ef3d248410cc0d8309f02f74204fe8, 0x11ef0bebc48c857e813af02f74204fe8, 'tabella team creata', 'goshin26@icloud.com', '2024-07-02 14:20:33', NULL, NULL, NULL, NULL),
(0x11ef3d248ca3d0a28309f02f74204fe8, 0x11ef0bebc48c857e813af02f74204fe8, 'tabella team finita', 'goshin26@icloud.com', '2024-07-02 14:20:47', NULL, NULL, NULL, NULL),
(0x11ef3d249575b92b8309f02f74204fe8, 0x11ef0bebc48c857e813af02f74204fe8, 'tabella progetti creata', 'goshin26@icloud.com', '2024-07-02 14:21:02', NULL, NULL, NULL, NULL),
(0x11ef3d249be921ab8309f02f74204fe8, 0x11ef0bebc48c857e813af02f74204fe8, 'tabella progetti completata', 'goshin26@icloud.com', '2024-07-03 14:21:13', NULL, NULL, NULL, NULL),
(0x11ef3d24a86166128309f02f74204fe8, 0x11ef0bebc48c857e813af02f74204fe8, 'tabella stati creata', 'goshin26@icloud.com', '2024-07-05 14:21:33', NULL, NULL, NULL, NULL),
(0x11ef3d24ab8c6eb88309f02f74204fe8, 0x11ef0bebc48c857e813af02f74204fe8, 'tabella stati finita', 'goshin26@icloud.com', '2024-07-05 14:21:39', NULL, NULL, NULL, NULL),
(0x11ef3d24af4541f58309f02f74204fe8, 0x11ef0bebc48c857e813af02f74204fe8, 'tabella schede creata', 'goshin26@icloud.com', '2024-07-08 14:21:45', NULL, NULL, NULL, NULL),
(0x11ef3d24b25377498309f02f74204fe8, 0x11ef0bebc48c857e813af02f74204fe8, 'tabella schede finita', 'goshin26@icloud.com', '2024-07-08 14:21:50', NULL, NULL, NULL, NULL),
(0x11ef3d24b57d37588309f02f74204fe8, 0x11ef0bebc48c857e813af02f74204fe8, 'tabella commenti creata', 'goshin26@icloud.com', '2024-07-08 14:21:55', NULL, NULL, NULL, NULL),
(0x11ef3d24bafb58e58309f02f74204fe8, 0x11ef0bebc48c857e813af02f74204fe8, 'tabella commenti finita', 'goshin26@icloud.com', '2024-07-08 14:22:05', NULL, NULL, NULL, NULL),
(0x11ef3d24bda1a4bf8309f02f74204fe8, 0x11ef0bebc48c857e813af02f74204fe8, 'taberlla report creata', 'goshin26@icloud.com', '2024-07-08 14:22:09', NULL, NULL, NULL, NULL),
(0x11ef3d24c0437abb8309f02f74204fe8, 0x11ef0bebc48c857e813af02f74204fe8, 'tabella report eliminata', 'goshin26@icloud.com', '2024-07-08 14:22:14', NULL, NULL, NULL, NULL),
(0x11ef3d24c447068f8309f02f74204fe8, 0x11ef0bebc48c857e813af02f74204fe8, 'tabella report ricreata e completata', 'goshin26@icloud.com', '2024-07-08 14:22:20', NULL, NULL, NULL, NULL),
(0x11ef3e1fd81efb9a8309f02f74204fe8, 0x11ef3e1fad8c5db68309f02f74204fe8, 'Abbiamo ricevuto tutti i pannelli, iniziamo l\'installazione domani mattina', 'francesca.neri@procol.com', '2024-07-09 20:19:35', NULL, NULL, NULL, NULL),
(0x11ef3e1ff15011098309f02f74204fe8, 0x11ef3e1fad8c5db68309f02f74204fe8, 'Perfetto! Ho già contattato i residenti per organizzare gli accessi.', 'carlo.barbieri@procol.com', '2024-07-09 20:20:17', 'francesca.neri@procol.com', NULL, NULL, '11ef3e1fd81efb9a8309f02f74204fe8'),
(0x11ef3e1fff66f0be8309f02f74204fe8, 0x11ef3e1fad8c5db68309f02f74204fe8, 'Ottimo lavoro, ragazzi. Siamo quasi alla fine.', 'francesca.neri@procol.com', '2024-07-09 20:20:41', NULL, NULL, NULL, NULL),
(0x11ef3e204242953a8309f02f74204fe8, 0x11ef3e1fb7cf32328309f02f74204fe8, 'Ho controllato le prime tre turbine, tutto sembra in ordine.', 'simone.lombardi@procol.com', '2024-07-09 20:22:33', NULL, NULL, NULL, NULL),
(0x11ef3e205ea4758a8309f02f74204fe8, 0x11ef3e1fb7cf32328309f02f74204fe8, 'Ben fatto, Simone! Continua così, stiamo facendo grandi progressi.', 'francesca.neri@procol.com', '2024-07-09 20:23:21', 'simone.lombardi@procol.com', NULL, NULL, '11ef3e204242953a8309f02f74204fe8'),
(0x11ef3e206c51da988309f02f74204fe8, 0x11ef3e1fb7cf32328309f02f74204fe8, 'Grazie, Francesca. Andrò avanti con le prossime.', 'simone.lombardi@procol.com', '2024-07-09 20:23:44', NULL, NULL, NULL, NULL),
(0x11ef3e20a6c5b99f8309f02f74204fe8, 0x11ef3e2082d10ec78309f02f74204fe8, 'Sto aspettando una risposta dal comune. Hanno detto che ci faranno sapere entro la settimana.', 'carlo.barbieri@procol.com', '2024-07-09 20:25:22', NULL, NULL, NULL, NULL),
(0x11ef3e20bd2e96d98309f02f74204fe8, 0x11ef3e2082d10ec78309f02f74204fe8, 'Va bene, Carlo. Teniamoci pronti per quando avremo il via libera.', 'francesca.neri@procol.com', '2024-07-09 20:25:59', NULL, NULL, NULL, NULL),
(0x11ef3e20f48a79db8309f02f74204fe8, 0x11ef3e20d4a4d26d8309f02f74204fe8, 'Il finanziamento è ancora in attesa di approvazione dalla banca.', 'francesca.neri@procol.com', '2024-07-09 20:27:32', NULL, 'francesca.neri@procol.com', '2024-07-09 20:28:59', NULL),
(0x11ef3e20fe5a1cbc8309f02f74204fe8, 0x11ef3e20d4a4d26d8309f02f74204fe8, 'Speriamo che arrivi presto, siamo pronti a partire!!', 'simone.lombardi@procol.com', '2024-07-09 20:27:49', NULL, 'simone.lombardi@procol.com', '2024-07-09 20:39:38', NULL),
(0x11ef3e4f598e891c8309f02f74204fe8, 0x11ef3e4f023a977b8309f02f74204fe8, 'Simone, dovevamo aver finito questo progetto la settimana scorsa. Che succede?', 'francesca.neri@procol.com', '2024-07-10 01:59:40', NULL, NULL, NULL, NULL),
(0x11ef3e4f707d16558309f02f74204fe8, 0x11ef3e4f023a977b8309f02f74204fe8, 'Ci sono stati dei ritardi nelle forniture. Sto facendo il possibile per recuperare.', 'simone.lombardi@procol.com', '2024-07-10 02:00:18', NULL, NULL, NULL, NULL),
(0x11ef3e503a4d6ece8309f02f74204fe8, 0x11ef3e4f89da63a88309f02f74204fe8, 'Carlo, dobbiamo accelerare su questo. È urgente!', 'francesca.neri@procol.com', '2024-07-10 02:05:57', NULL, NULL, NULL, NULL),
(0x11ef3e531444ea2c8309f02f74204fe8, 0x11ef3e4f89da63a88309f02f74204fe8, 'Capisco, Francesca. Sto cercando di risolvere il problema con il fornitore.', 'carlo.barbieri@procol.com', '2024-07-10 02:26:22', NULL, NULL, NULL, NULL),
(0x11ef3e53ad2bd25c8309f02f74204fe8, 0x11ef3e538c93655b8309f02f74204fe8, 'Purtroppo, il progetto non è fattibile con le risorse attuali. Dobbiamo archiviarlo.', 'francesca.neri@procol.com', '2024-07-10 02:30:38', NULL, NULL, NULL, NULL),
(0x11ef3e5438af32a38309f02f74204fe8, 0x11ef3e53fb405f018309f02f74204fe8, 'Dopo un\'analisi approfondita, penso sia giusto archiviare questo progetto per l\'impossibilità tecnica.', 'simone.lombardi@procol.com', '2024-07-10 02:34:32', NULL, NULL, NULL, NULL),
(0x11ef3e544b258c2f8309f02f74204fe8, 0x11ef3e53fb405f018309f02f74204fe8, 'Grazie per l\'aggiornamento, Simone. Procediamo con altre iniziative.', 'francesca.neri@procol.com', '2024-07-10 02:35:03', NULL, NULL, NULL, NULL),
(0x11ef3e54855a9b968309f02f74204fe8, 0x11ef3e545bd1d33f8309f02f74204fe8, 'Abbiamo completato l\'installazione. La scuola è ora autosufficiente dal punto di vista energetico!', 'carlo.barbieri@procol.com', '2024-07-10 02:36:41', NULL, NULL, NULL, NULL),
(0x11ef3e5488e1d5978309f02f74204fe8, 0x11ef3e545bd1d33f8309f02f74204fe8, 'Ottimo lavoro, Carlo. Un grande successo per il team!', 'francesca.neri@procol.com', '2024-07-10 02:36:47', NULL, 'francesca.neri@procol.com', '2024-07-10 02:36:52', NULL),
(0x11ef3e54f52c2c2d8309f02f74204fe8, 0x11ef3e54decc890c8309f02f74204fe8, 'Il sistema è stato installato con successo e sta funzionando perfettamente', 'simone.lombardi@procol.com', '2024-07-10 02:39:48', NULL, NULL, NULL, NULL),
(0x11ef3e550f4afa448309f02f74204fe8, 0x11ef3e54decc890c8309f02f74204fe8, 'Fantastico! Questo è un risultato straordinario. Continuiamo così!', 'francesca.neri@procol.com', '2024-07-10 02:40:32', 'simone.lombardi@procol.com', NULL, NULL, '11ef3e54f52c2c2d8309f02f74204fe8');

--
-- Trigger `commenti`
--
DROP TRIGGER IF EXISTS `anticipo_inserimento_commento`;
DELIMITER $$
CREATE TRIGGER `anticipo_inserimento_commento` BEFORE INSERT ON `commenti` FOR EACH ROW BEGIN
	SET @uuid = UUID();
	SET NEW.uuid_commento = UNHEX(CONCAT(
		SUBSTR(@uuid, 15, 4),
		SUBSTR(@uuid, 10, 4),
		SUBSTR(@uuid, 1, 8),
		SUBSTR(@uuid, 20, 4),
		SUBSTR(@uuid, 25))
	);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struttura della tabella `info_schede`
--

DROP TABLE IF EXISTS `info_schede`;
CREATE TABLE IF NOT EXISTS `info_schede` (
  `uuid_scheda` binary(16) NOT NULL,
  `incaricato` varchar(255) DEFAULT NULL,
  `inizio_mandato` datetime DEFAULT NULL,
  `fine_mandato` datetime DEFAULT NULL,
  `spostamento` datetime NOT NULL DEFAULT current_timestamp(),
  `spostato_da` varchar(255) DEFAULT NULL,
  `data_inizio` datetime NOT NULL DEFAULT current_timestamp(),
  `data_fine` datetime DEFAULT NULL,
  `ultima_modifica` datetime DEFAULT NULL,
  `modificato_da` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `info_schede`
--

INSERT INTO `info_schede` (`uuid_scheda`, `incaricato`, `inizio_mandato`, `fine_mandato`, `spostamento`, `spostato_da`, `data_inizio`, `data_fine`, `ultima_modifica`, `modificato_da`) VALUES
(0x11ef0bebc48909f3813af02f74204fe8, NULL, NULL, NULL, '2024-07-04 23:01:06', 'goshin26@icloud.com', '2024-05-06 23:01:06', NULL, NULL, NULL),
(0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', '2024-07-08 14:21:19', '2024-07-08 14:26:19', '2024-07-03 23:01:06', 'goshin26@icloud.com', '2024-05-06 23:01:06', NULL, NULL, NULL),
(0x11ef0bebc48f1669813af02f74204fe8, NULL, NULL, NULL, '2024-07-06 23:01:06', 'goshin26@icloud.com', '2024-05-06 23:01:06', NULL, NULL, NULL),
(0x11ef0bebc491eb66813af02f74204fe8, NULL, NULL, NULL, '2024-07-07 23:01:06', 'goshin26@icloud.com', '2024-05-06 23:01:06', NULL, NULL, NULL),
(0x11ef0bebc495894b813af02f74204fe8, NULL, NULL, NULL, '2024-07-08 23:01:06', 'goshin26@icloud.com', '2024-05-06 23:01:06', NULL, NULL, NULL),
(0x11ef0bee92cbdddc813af02f74204fe8, NULL, NULL, NULL, '2024-07-06 23:21:11', 'goshin26@icloud.com', '2024-05-06 23:21:11', NULL, NULL, NULL),
(0x11ef0bee9fd76d48813af02f74204fe8, NULL, NULL, NULL, '2024-07-06 23:21:33', 'goshin26@icloud.com', '2024-05-06 23:21:33', NULL, NULL, NULL),
(0x11ef0bee9fdae55f813af02f74204fe8, NULL, NULL, NULL, '2024-07-07 23:21:33', 'goshin26@icloud.com', '2024-05-06 23:21:33', NULL, NULL, NULL),
(0x11ef0bee9fdbf109813af02f74204fe8, NULL, NULL, NULL, '2024-07-06 23:21:33', 'goshin26@icloud.com', '2024-05-06 23:21:33', NULL, NULL, NULL),
(0x11ef3491ab45987d8309f02f74204fe8, NULL, NULL, NULL, '2024-06-27 16:29:27', 'goshin26@icloud.com', '2024-06-27 16:29:27', NULL, NULL, NULL),
(0x11ef34db5d7220d08309f02f74204fe8, NULL, NULL, NULL, '2024-07-08 01:16:59', 'goshin26@icloud.com', '2024-06-28 01:16:59', '2024-06-28 01:24:24', NULL, NULL),
(0x11ef34e4ac36c58c8309f02f74204fe8, NULL, NULL, NULL, '2024-06-28 02:23:37', 'goshin26@icloud.com', '2024-06-28 02:23:37', NULL, NULL, NULL),
(0x11ef34eb93b6eb178309f02f74204fe8, 'goshin26@icloud.com', '2024-06-28 19:08:39', '2024-06-28 19:13:39', '2024-06-28 03:13:02', 'goshin26@icloud.com', '2024-06-28 03:13:02', NULL, NULL, NULL),
(0x11ef3af4d31f30bc8309f02f74204fe8, NULL, NULL, NULL, '2024-07-05 19:34:11', 'imma.capuano@procol.com', '2024-07-05 19:34:11', NULL, '2024-07-05 19:56:24', 'imma.capuano@procol.com'),
(0x11ef3e1fad8c5db68309f02f74204fe8, 'francesca.neri@procol.com', '2024-07-09 20:18:50', '2024-07-09 20:23:50', '2024-07-09 20:18:24', 'francesca.neri@procol.com', '2024-07-09 20:18:24', NULL, NULL, NULL),
(0x11ef3e1fb7cf32328309f02f74204fe8, 'simone.lombardi@procol.com', '2024-07-09 20:21:45', '2024-11-09 20:26:45', '2024-07-09 20:18:41', 'francesca.neri@procol.com', '2024-07-09 20:18:41', NULL, NULL, NULL),
(0x11ef3e2082d10ec78309f02f74204fe8, 'carlo.barbieri@procol.com', '2024-07-09 20:24:59', '2024-12-09 20:29:59', '2024-07-09 20:24:21', 'carlo.barbieri@procol.com', '2024-07-09 20:24:21', NULL, NULL, NULL),
(0x11ef3e20d4a4d26d8309f02f74204fe8, 'francesca.neri@procol.com', '2024-07-09 20:26:57', '2024-12-09 20:31:57', '2024-07-09 20:26:39', 'francesca.neri@procol.com', '2024-07-09 20:26:39', NULL, NULL, NULL),
(0x11ef3e4f023a977b8309f02f74204fe8, 'simone.lombardi@procol.com', '2024-07-10 01:59:01', '2024-07-10 02:04:01', '2024-07-10 01:57:13', 'simone.lombardi@procol.com', '2024-06-30 14:57:13', NULL, NULL, NULL),
(0x11ef3e4f89da63a88309f02f74204fe8, 'carlo.barbieri@procol.com', '2024-07-10 02:01:17', '2024-07-10 02:06:17', '2024-07-10 02:01:01', 'simone.lombardi@procol.com', '2024-04-10 02:01:01', NULL, NULL, NULL),
(0x11ef3e538c93655b8309f02f74204fe8, 'carlo.barbieri@procol.com', '2024-07-10 02:30:05', '2024-10-10 02:35:05', '2024-07-10 02:29:43', 'francesca.neri@procol.com', '2024-07-10 02:29:43', NULL, NULL, NULL),
(0x11ef3e53fb405f018309f02f74204fe8, 'simone.lombardi@procol.com', '2024-07-10 02:33:31', '2024-07-10 02:38:31', '2024-07-10 02:32:49', 'francesca.neri@procol.com', '2024-07-10 02:32:49', NULL, NULL, NULL),
(0x11ef3e545bd1d33f8309f02f74204fe8, 'carlo.barbieri@procol.com', '2024-07-10 02:35:57', '2024-07-10 02:40:57', '2024-07-10 02:35:31', 'francesca.neri@procol.com', '2024-07-10 02:35:31', '2024-07-10 02:37:01', NULL, NULL),
(0x11ef3e54decc890c8309f02f74204fe8, 'simone.lombardi@procol.com', '2024-07-10 02:39:28', '2024-07-10 02:44:28', '2024-07-10 02:39:11', 'francesca.neri@procol.com', '2024-07-10 02:39:11', '2024-07-10 02:40:36', NULL, NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `report`
--

DROP TABLE IF EXISTS `report`;
CREATE TABLE IF NOT EXISTS `report` (
  `uuid_report` binary(16) NOT NULL,
  `tipo_azione` enum('sessione','utente','team','progetto','scheda') NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp(),
  `attore` varchar(255) DEFAULT NULL,
  `descrizione` varchar(255) NOT NULL DEFAULT 'errore descrizione tipo azione',
  `link` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utente` varchar(255) DEFAULT NULL,
  `team` varchar(3) DEFAULT NULL,
  `progetto` int(11) DEFAULT NULL,
  `categoria` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scheda` binary(16) DEFAULT NULL,
  `attore_era` varchar(255) DEFAULT NULL,
  `bersaglio_era` varchar(255) DEFAULT NULL
) ;

--
-- Dump dei dati per la tabella `report`
--

INSERT INTO `report` (`uuid_report`, `tipo_azione`, `timestamp`, `attore`, `descrizione`, `link`, `utente`, `team`, `progetto`, `categoria`, `scheda`, `attore_era`, `bersaglio_era`) VALUES
(0x11ef31992c93ee0a9e85f02f74204fe8, 'scheda', '2024-06-23 21:45:37', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8#repl=11ef31992c93d00c9e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11ef30e4f47d76069e85f02f74204fe8-11ef31992c93d00c9e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef319936a71d919e85f02f74204fe8, 'scheda', '2024-06-23 21:45:54', 'goshin26@icloud.com', 'Modifica Commento', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8#repl=11ef31992c93d00c9e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-11ef31992c93d00c9e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef31993baa62a09e85f02f74204fe8, 'scheda', '2024-06-23 21:46:02', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8#repl=11ef31993ba9c8289e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11ef30e4f47d76069e85f02f74204fe8-11ef31993ba9c8289e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef31993e58d43c9e85f02f74204fe8, 'scheda', '2024-06-23 21:46:07', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8#repl=11ef31993e58c5409e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11ef30e4f47d76069e85f02f74204fe8-11ef31993e58c5409e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef319940f539e59e85f02f74204fe8, 'scheda', '2024-06-23 21:46:11', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8#repl=11ef319940f52cea9e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11ef30e4f47d76069e85f02f74204fe8-11ef319940f52cea9e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef31994be5d5279e85f02f74204fe8, 'scheda', '2024-06-23 21:46:29', 'goshin26@icloud.com', 'Risposta Commento', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8#repl=11ef31994be5ca069e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-11ef31994be5ca069e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef31998ed926dc9e85f02f74204fe8, 'scheda', '2024-06-23 21:48:22', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8#repl=11ef31998ed8b2269e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11ef30e4f47d76069e85f02f74204fe8-11ef31998ed8b2269e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef3199924615459e85f02f74204fe8, 'scheda', '2024-06-23 21:48:27', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8#repl=11ef31999246081b9e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11ef30e4f47d76069e85f02f74204fe8-11ef31999246081b9e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef3199940692b99e85f02f74204fe8, 'scheda', '2024-06-23 21:48:30', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8#repl=11ef3199940686b89e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11ef30e4f47d76069e85f02f74204fe8-11ef3199940686b89e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef31999af6d7da9e85f02f74204fe8, 'scheda', '2024-06-23 21:48:42', 'goshin26@icloud.com', 'Risposta Commento', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8#repl=11ef31999af6caec9e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-11ef31999af6caec9e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef3199aac74bac9e85f02f74204fe8, 'scheda', '2024-06-23 21:49:08', 'goshin26@icloud.com', 'Risposta Commento', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8#repl=11ef3199aac73e4a9e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-11ef3199aac73e4a9e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef3281ca62154d9e85f02f74204fe8, 'scheda', '2024-06-25 01:30:42', 'goshin26@icloud.com', 'Deassegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'utente.prova1@procol.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-utente.prova1@procol.com'),
(0x11ef3281ed4f0d039e85f02f74204fe8, 'scheda', '2024-06-25 01:31:41', 'goshin26@icloud.com', 'Deassegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', NULL, NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-admin2@procol.com'),
(0x11ef3284f5b467ac9e85f02f74204fe8, 'scheda', '2024-06-25 01:53:24', 'goshin26@icloud.com', 'Riassegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'utente.prova2@procol.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-utente.prova2@procol.com'),
(0x11ef32852af0a3209e85f02f74204fe8, 'scheda', '2024-06-25 01:54:53', 'goshin26@icloud.com', 'Deassegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'utente.prova2@procol.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-utente.prova2@procol.com'),
(0x11ef32852af0ad759e85f02f74204fe8, 'scheda', '2024-06-25 01:54:53', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef32858747cbff9e85f02f74204fe8, 'scheda', '2024-06-25 01:57:28', 'goshin26@icloud.com', 'Deassegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef32f66fb7003f9e85f02f74204fe8, 'scheda', '2024-06-25 15:25:39', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef32f6719220b99e85f02f74204fe8, 'scheda', '2024-06-25 15:25:42', 'goshin26@icloud.com', 'Deassegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef32f671922a479e85f02f74204fe8, 'scheda', '2024-06-25 15:25:42', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'utente.prova1@procol.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-utente.prova1@procol.com'),
(0x11ef32f8abdaf4e69e85f02f74204fe8, 'scheda', '2024-06-25 15:41:39', 'goshin26@icloud.com', 'Deassegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'utente.prova1@procol.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-utente.prova1@procol.com'),
(0x11ef32f8abdba8cc9e85f02f74204fe8, 'scheda', '2024-06-25 15:41:39', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef32f8bd6ba9d49e85f02f74204fe8, 'scheda', '2024-06-25 15:42:08', 'goshin26@icloud.com', 'Deassegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef32f8bd6bc8be9e85f02f74204fe8, 'scheda', '2024-06-25 15:42:08', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'utente.prova1@procol.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-utente.prova1@procol.com'),
(0x11ef32f8cc47df289e85f02f74204fe8, 'scheda', '2024-06-25 15:42:33', 'goshin26@icloud.com', 'Deassegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'utente.prova1@procol.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-utente.prova1@procol.com'),
(0x11ef32f8cc47e5619e85f02f74204fe8, 'scheda', '2024-06-25 15:42:33', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef32f8d052a23c9e85f02f74204fe8, 'scheda', '2024-06-25 15:42:40', 'goshin26@icloud.com', 'Deassegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef32f97a4409a39e85f02f74204fe8, 'scheda', '2024-06-25 15:47:25', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', NULL, NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-admin2@procol.com'),
(0x11ef32f9820103899e85f02f74204fe8, 'scheda', '2024-06-25 15:47:38', 'goshin26@icloud.com', 'Deassegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', NULL, NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-admin2@procol.com'),
(0x11ef32f9820108fa9e85f02f74204fe8, 'scheda', '2024-06-25 15:47:38', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef32f9ad0dae389e85f02f74204fe8, 'scheda', '2024-06-25 15:48:51', 'goshin26@icloud.com', 'Deassegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef32f9b83e54ab9e85f02f74204fe8, 'scheda', '2024-06-25 15:49:09', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef32f9b9abc46d9e85f02f74204fe8, 'scheda', '2024-06-25 15:49:12', 'goshin26@icloud.com', 'Deassegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef3302af2e0d4b9e85f02f74204fe8, 'scheda', '2024-06-25 16:53:20', 'goshin26@icloud.com', 'Modifica Descrizione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11ef30e4f47d76069e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef330ad77641649e85f02f74204fe8, 'scheda', '2024-06-25 17:51:43', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef33109841a77a9e85f02f74204fe8, 'scheda', '2024-06-25 18:32:54', 'goshin26@icloud.com', 'Deassegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef33109842169e9e85f02f74204fe8, 'scheda', '2024-06-25 18:32:54', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'utente.prova1@procol.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF30E4F47D76069E85F02F74204FE8-11ef30e4f47d76069e85f02f74204fe8-utente.prova1@procol.com'),
(0x11ef3310f408de929e85f02f74204fe8, 'progetto', '2024-06-25 18:35:28', 'goshin26@icloud.com', 'Creazione Categoria', 'board.html?proj=14', NULL, NULL, 14, '1', NULL, 'goshin26@icloud.com', '14-1'),
(0x11ef3310f80fee759e85f02f74204fe8, 'progetto', '2024-06-25 18:35:35', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, '1', NULL, 'goshin26@icloud.com', '14-1'),
(0x11ef3355b5677b6e9e85f02f74204fe8, 'scheda', '2024-06-26 02:47:38', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', NULL, NULL, 14, 'Comm Nu Verd', NULL, 'goshin26@icloud.com', '14--11ef30e4f47d76069e85f02f74204fe8-'),
(0x11ef33576c329d048309f02f74204fe8, 'scheda', '2024-06-26 03:00:04', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef33576c3263498309f02f74204fe8', NULL, NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF33576C3263498309F02F74204FE8'),
(0x11ef3357752de7278309f02f74204fe8, 'scheda', '2024-06-26 03:00:19', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef33576c3263498309f02f74204fe8', NULL, NULL, 14, 'Asdas', NULL, 'goshin26@icloud.com', '14-Asdas-11ef33576c3263498309f02f74204fe8-'),
(0x11ef33935e138f428309f02f74204fe8, 'scheda', '2024-06-26 10:09:07', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef309ca11ab6969e85f02f74204fe8', NULL, NULL, 14, 'Completate', NULL, 'goshin26@icloud.com', '14-Completate-11ef309ca11ab6969e85f02f74204fe8'),
(0x11ef33945d1ba8548309f02f74204fe8, 'scheda', '2024-06-26 10:16:15', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef309ca11ab6969e85f02f74204fe8', NULL, NULL, 14, 'Comm Nu Verd', NULL, 'goshin26@icloud.com', '14-Comm Nu Verd-11ef309ca11ab6969e85f02f74204fe8'),
(0x11ef339494197a0a8309f02f74204fe8, 'scheda', '2024-06-26 10:17:48', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef309ca11ab6969e85f02f74204fe8', NULL, NULL, 14, 'In Corso', NULL, 'goshin26@icloud.com', '14-In Corso-11ef309ca11ab6969e85f02f74204fe8'),
(0x11ef3394bbfbca3a8309f02f74204fe8, 'scheda', '2024-06-26 10:18:55', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef309ca11ab6969e85f02f74204fe8', NULL, NULL, 14, 'Completate', NULL, 'goshin26@icloud.com', '14-Completate-11ef309ca11ab6969e85f02f74204fe8'),
(0x11ef3394cde285e78309f02f74204fe8, 'scheda', '2024-06-26 10:19:25', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef309ca11ab6969e85f02f74204fe8', NULL, NULL, 14, 'Vittoria', NULL, 'goshin26@icloud.com', '14-Vittoria-11ef309ca11ab6969e85f02f74204fe8'),
(0x11ef3394e4429a128309f02f74204fe8, 'scheda', '2024-06-26 10:20:02', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=14&post=11ef309ca11ab6969e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Vittoria', NULL, 'goshin26@icloud.com', '14-Vittoria-11EF309CA11AB6969E85F02F74204FE8-11ef309ca11ab6969e85f02f74204fe8-goshin26@icloud.com'),
(0x11ef3396a543758e8309f02f74204fe8, 'scheda', '2024-06-26 10:32:35', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef309ca11ab6969e85f02f74204fe8#repl=11ef3396a542fe408309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Vittoria', NULL, 'goshin26@icloud.com', '14-Vittoria-11ef309ca11ab6969e85f02f74204fe8-11ef3396a542fe408309f02f74204fe8-goshin26@icloud.com'),
(0x11ef3396b185bcdf8309f02f74204fe8, 'scheda', '2024-06-26 10:32:56', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef309ca11ab6969e85f02f74204fe8#repl=11ef3396b1849e398309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Vittoria', NULL, 'goshin26@icloud.com', '14-Vittoria-11ef309ca11ab6969e85f02f74204fe8-11ef3396b1849e398309f02f74204fe8-goshin26@icloud.com'),
(0x11ef33986779bbf58309f02f74204fe8, 'scheda', '2024-06-26 10:45:11', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef309ca11ab6969e85f02f74204fe8#repl=11ef339867798ca38309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Vittoria', NULL, 'goshin26@icloud.com', '14-Vittoria-11ef309ca11ab6969e85f02f74204fe8-11ef339867798ca38309f02f74204fe8-goshin26@icloud.com'),
(0x11ef33991a25b0308309f02f74204fe8, 'scheda', '2024-06-26 10:50:10', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef309ca11ab6969e85f02f74204fe8#repl=11ef33991a24eff78309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Vittoria', NULL, 'goshin26@icloud.com', '14-Vittoria-11ef309ca11ab6969e85f02f74204fe8-11ef33991a24eff78309f02f74204fe8-goshin26@icloud.com'),
(0x11ef339941cdb40d8309f02f74204fe8, 'scheda', '2024-06-26 10:51:17', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef309ca11ab6969e85f02f74204fe8#repl=11ef339941cd9f048309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Vittoria', NULL, 'goshin26@icloud.com', '14-Vittoria-11ef309ca11ab6969e85f02f74204fe8-11ef339941cd9f048309f02f74204fe8-goshin26@icloud.com'),
(0x11ef339cde04aa4f8309f02f74204fe8, 'scheda', '2024-06-26 11:17:08', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef30ba0cb786909e85f02f74204fe8#repl=11ef339cde0419dd8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Fdsfsd', NULL, 'goshin26@icloud.com', '14-Fdsfsd-11ef30ba0cb786909e85f02f74204fe8-11ef339cde0419dd8309f02f74204fe8-goshin26@icloud.com'),
(0x11ef33a63f290b468309f02f74204fe8, 'scheda', '2024-06-26 12:24:16', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef33a63f2881098309f02f74204fe8', NULL, NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11EF33A63F2881098309F02F74204FE8'),
(0x11ef33d87f2d2b5f8309f02f74204fe8, 'progetto', '2024-06-26 18:23:58', 'goshin26@icloud.com', 'Creazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Aggiungo', NULL, 'goshin26@icloud.com', '14-Aggiungo'),
(0x11ef33d882dafbe88309f02f74204fe8, 'progetto', '2024-06-26 18:24:04', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Aggiungo', NULL, 'goshin26@icloud.com', '14-Aggiungo'),
(0x11ef33d889aac7268309f02f74204fe8, 'progetto', '2024-06-26 18:24:16', 'goshin26@icloud.com', 'Creazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Riaggiungo', NULL, 'goshin26@icloud.com', '14-Riaggiungo'),
(0x11ef33d88ffcd7368309f02f74204fe8, 'progetto', '2024-06-26 18:24:26', 'goshin26@icloud.com', 'Nascondimento Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Riaggiungo', NULL, 'goshin26@icloud.com', '14-Riaggiungo'),
(0x11ef33d891e011fa8309f02f74204fe8, 'progetto', '2024-06-26 18:24:30', 'goshin26@icloud.com', 'Visualizzazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Riaggiungo', NULL, 'goshin26@icloud.com', '14-Riaggiungo'),
(0x11ef33d8972dab1a8309f02f74204fe8, 'scheda', '2024-06-26 18:24:39', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef33d8972bcf8b8309f02f74204fe8', NULL, NULL, 14, 'Riaggiungo', NULL, 'goshin26@icloud.com', '14-Riaggiungo-11EF33D8972BCF8B8309F02F74204FE8'),
(0x11ef33d8a1d10f438309f02f74204fe8, 'progetto', '2024-06-26 18:24:56', 'goshin26@icloud.com', 'Creazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui'),
(0x11ef33d8b2b1b05b8309f02f74204fe8, 'scheda', '2024-06-26 18:25:25', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef33d8b2b189e18309f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11EF33D8B2B189E18309F02F74204FE8'),
(0x11ef33d8bbe7c3998309f02f74204fe8, 'scheda', '2024-06-26 18:25:40', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef33d8972bcf8b8309f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11ef33d8972bcf8b8309f02f74204fe8'),
(0x11ef33d8cee82ccc8309f02f74204fe8, 'scheda', '2024-06-26 18:26:12', 'goshin26@icloud.com', 'Rimozione Scheda', 'board.html?proj=14&post=11ef33d8b2b189e18309f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11ef33d8b2b189e18309f02f74204fe8'),
(0x11ef33d8e4e9cb988309f02f74204fe8, 'scheda', '2024-06-26 18:26:49', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef2b3cce49b7c69219f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11ef2b3cce49b7c69219f02f74204fe8'),
(0x11ef33debebbe8978309f02f74204fe8, 'scheda', '2024-06-26 19:08:42', 'goshin26@icloud.com', 'Rimozione Scheda', 'board.html?proj=14&post=11ef2b3cce49b7c69219f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11ef2b3cce49b7c69219f02f74204fe8'),
(0x11ef33dedeaae2be8309f02f74204fe8, 'scheda', '2024-06-26 19:09:35', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef2b3cce49b7c69219f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11ef2b3cce49b7c69219f02f74204fe8'),
(0x11ef33defebd23bf8309f02f74204fe8, 'scheda', '2024-06-26 19:10:29', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef3027674b2765935ff02f74204fe8', NULL, NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef3027674b2765935ff02f74204fe8'),
(0x11ef33df6a7c80028309f02f74204fe8, 'scheda', '2024-06-26 19:13:30', 'goshin26@icloud.com', 'Aggiunta Descrizione Scheda', 'board.html?proj=14&post=11ef2b3cce49b7c69219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11ef2b3cce49b7c69219f02f74204fe8-goshin26@icloud.com'),
(0x11ef33df6fc9e91b8309f02f74204fe8, 'scheda', '2024-06-26 19:13:39', 'goshin26@icloud.com', 'Modifica Descrizione Scheda', 'board.html?proj=14&post=11ef2b3cce49b7c69219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11ef2b3cce49b7c69219f02f74204fe8-goshin26@icloud.com'),
(0x11ef33df726cba538309f02f74204fe8, 'scheda', '2024-06-26 19:13:43', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef2b3cce49b7c69219f02f74204fe8#repl=11ef33df726c766c8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11ef2b3cce49b7c69219f02f74204fe8-11ef33df726c766c8309f02f74204fe8-goshin26@icloud.com'),
(0x11ef33df76df5cb78309f02f74204fe8, 'scheda', '2024-06-26 19:13:51', 'goshin26@icloud.com', 'Modifica Commento', 'board.html?proj=14&post=11ef2b3cce49b7c69219f02f74204fe8#repl=11ef33df726c766c8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11EF2B3CCE49B7C69219F02F74204FE8-11ef2b3cce49b7c69219f02f74204fe8-11ef33df726c766c8309f02f74204fe8-goshin26@icloud.com'),
(0x11ef33df7c65525a8309f02f74204fe8, 'scheda', '2024-06-26 19:14:00', 'goshin26@icloud.com', 'Risposta Commento', 'board.html?proj=14&post=11ef2b3cce49b7c69219f02f74204fe8#repl=11ef33df7c648fb48309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11EF2B3CCE49B7C69219F02F74204FE8-11ef2b3cce49b7c69219f02f74204fe8-11ef33df7c648fb48309f02f74204fe8-goshin26@icloud.com'),
(0x11ef33df8400e1e88309f02f74204fe8, 'scheda', '2024-06-26 19:14:13', 'goshin26@icloud.com', 'Modifica Commento', 'board.html?proj=14&post=11ef2b3cce49b7c69219f02f74204fe8#repl=11ef33df726c766c8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11EF2B3CCE49B7C69219F02F74204FE8-11ef2b3cce49b7c69219f02f74204fe8-11ef33df726c766c8309f02f74204fe8-goshin26@icloud.com'),
(0x11ef33df88a6b80d8309f02f74204fe8, 'scheda', '2024-06-26 19:14:21', 'goshin26@icloud.com', 'Eliminazione Commento', 'board.html?proj=14&post=11ef2b3cce49b7c69219f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11ef2b3cce49b7c69219f02f74204fe8-11ef33df726c766c8309f02f74204fe8-goshin26@icloud.com'),
(0x11ef33e01406c3828309f02f74204fe8, 'scheda', '2024-06-26 19:18:14', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=14&post=11ef2b3cce49b7c69219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11EF2B3CCE49B7C69219F02F74204FE8-11ef2b3cce49b7c69219f02f74204fe8-goshin26@icloud.com'),
(0x11ef33e02874b1878309f02f74204fe8, 'scheda', '2024-06-26 19:18:49', 'goshin26@icloud.com', 'Deassegnazione Scheda', 'board.html?proj=14&post=11ef2b3cce49b7c69219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11EF2B3CCE49B7C69219F02F74204FE8-11ef2b3cce49b7c69219f02f74204fe8-goshin26@icloud.com'),
(0x11ef33e02874b7668309f02f74204fe8, 'scheda', '2024-06-26 19:18:49', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=14&post=11ef2b3cce49b7c69219f02f74204fe8', 'utente.prova2@procol.com', NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11EF2B3CCE49B7C69219F02F74204FE8-11ef2b3cce49b7c69219f02f74204fe8-utente.prova2@procol.com'),
(0x11ef33e0328478318309f02f74204fe8, 'scheda', '2024-06-26 19:19:06', 'goshin26@icloud.com', 'Deassegnazione Scheda', 'board.html?proj=14&post=11ef2b3cce49b7c69219f02f74204fe8', 'utente.prova2@procol.com', NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11EF2B3CCE49B7C69219F02F74204FE8-11ef2b3cce49b7c69219f02f74204fe8-utente.prova2@procol.com'),
(0x11ef33ecb06525968309f02f74204fe8, 'scheda', '2024-06-26 20:48:31', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=14&post=11ef2b3cce49b7c69219f02f74204fe8', 'utente.prova1@procol.com', NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11EF2B3CCE49B7C69219F02F74204FE8-11ef2b3cce49b7c69219f02f74204fe8-utente.prova1@procol.com'),
(0x11ef33ecbc7a95388309f02f74204fe8, 'scheda', '2024-06-26 20:48:51', 'goshin26@icloud.com', 'Riassegnazione Scheda', 'board.html?proj=14&post=11ef2b3cce49b7c69219f02f74204fe8', 'utente.prova1@procol.com', NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11EF2B3CCE49B7C69219F02F74204FE8-11ef2b3cce49b7c69219f02f74204fe8-utente.prova1@procol.com'),
(0x11ef33f9a2d7cdf08309f02f74204fe8, 'progetto', '2024-06-26 22:21:12', 'goshin26@icloud.com', 'Creazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Invisibile', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Invisibile'),
(0x11ef340c1c0038de8309f02f74204fe8, 'scheda', '2024-06-27 00:33:26', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef2b3cce49b7c69219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Riaggiungo', NULL, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Riaggiungo-11ef2b3cce49b7c69219f02f74204fe8'),
(0x11ef3415cec55ae78309f02f74204fe8, 'scheda', '2024-06-27 01:42:51', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef30e4f47d76069e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Passa Qui-11ef30e4f47d76069e85f02f74204fe8'),
(0x11ef3416408ae8bc8309f02f74204fe8, 'scheda', '2024-06-27 01:46:02', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef33d8972bcf8b8309f02f74204fe8#repl=11ef3416408a8fc58309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Passa Qui-11ef33d8972bcf8b8309f02f74204fe8-11ef3416408a8fc58309f02f74204fe8'),
(0x11ef342596ef6a158309f02f74204fe8, 'scheda', '2024-06-27 03:35:49', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef1a0f1f23db0b8123f02f74204fe8', 'admin@procol.com', NULL, 14, 'In Ritardo', NULL, 'goshin26@icloud.com', '14-In Ritardo-11ef1a0f1f23db0b8123f02f74204fe8'),
(0x11ef3425981483588309f02f74204fe8, 'scheda', '2024-06-27 03:35:51', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef0bee9fd9b842813af02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'In Ritardo', NULL, 'goshin26@icloud.com', '14-In Ritardo-11ef0bee9fd9b842813af02f74204fe8'),
(0x11ef342599c5f57d8309f02f74204fe8, 'scheda', '2024-06-27 03:35:54', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef0bebc4931faa813af02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'In Ritardo', NULL, 'goshin26@icloud.com', '14-In Ritardo-11ef0bebc4931faa813af02f74204fe8'),
(0x11ef3425c569842f8309f02f74204fe8, 'scheda', '2024-06-27 03:37:07', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef0bebc490a8f6813af02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Completate', NULL, 'goshin26@icloud.com', '14-Completate-11ef0bebc490a8f6813af02f74204fe8'),
(0x11ef3425c667ddc98309f02f74204fe8, 'scheda', '2024-06-27 03:37:09', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef0bebc4946cf9813af02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Completate', NULL, 'goshin26@icloud.com', '14-Completate-11ef0bebc4946cf9813af02f74204fe8'),
(0x11ef3425c7f3814c8309f02f74204fe8, 'scheda', '2024-06-27 03:37:12', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef0bebc48b5ac9813af02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Completate', NULL, 'goshin26@icloud.com', '14-Completate-11ef0bebc48b5ac9813af02f74204fe8'),
(0x11ef3425cb9297db8309f02f74204fe8, 'scheda', '2024-06-27 03:37:18', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef0beb94cde5f9813af02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'In Ritardo', NULL, 'goshin26@icloud.com', '14-In Ritardo-11ef0beb94cde5f9813af02f74204fe8'),
(0x11ef3425cc9fa71b8309f02f74204fe8, 'scheda', '2024-06-27 03:37:19', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef0bebc48dcaaf813af02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'In Ritardo', NULL, 'goshin26@icloud.com', '14-In Ritardo-11ef0bebc48dcaaf813af02f74204fe8'),
(0x11ef3425cf5415e68309f02f74204fe8, 'scheda', '2024-06-27 03:37:24', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2b42858c96469219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2b42858c96469219f02f74204fe8'),
(0x11ef3425d14f8a0d8309f02f74204fe8, 'scheda', '2024-06-27 03:37:27', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2b3e72bfff4f9219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2b3e72bfff4f9219f02f74204fe8'),
(0x11ef3425d37896128309f02f74204fe8, 'scheda', '2024-06-27 03:37:31', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2b42e406fc069219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2b42e406fc069219f02f74204fe8'),
(0x11ef3425d47996878309f02f74204fe8, 'scheda', '2024-06-27 03:37:33', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2b3e55669dc19219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2b3e55669dc19219f02f74204fe8'),
(0x11ef3425d60a6a3b8309f02f74204fe8, 'scheda', '2024-06-27 03:37:35', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2b3af87d2fe09219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2b3af87d2fe09219f02f74204fe8'),
(0x11ef3425d758aa4e8309f02f74204fe8, 'scheda', '2024-06-27 03:37:37', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2c0b4cd35d459219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2c0b4cd35d459219f02f74204fe8'),
(0x11ef3425d9667de18309f02f74204fe8, 'scheda', '2024-06-27 03:37:41', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2c0b4aa0e2ea9219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2c0b4aa0e2ea9219f02f74204fe8'),
(0x11ef3425dd3f3d898309f02f74204fe8, 'scheda', '2024-06-27 03:37:47', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef33d8b2b189e18309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef33d8b2b189e18309f02f74204fe8'),
(0x11ef3425df72a5578309f02f74204fe8, 'scheda', '2024-06-27 03:37:51', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2b37e27ab2d99219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2b37e27ab2d99219f02f74204fe8'),
(0x11ef3425e0cd8b888309f02f74204fe8, 'scheda', '2024-06-27 03:37:53', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef1a0f1f23db0b8123f02f74204fe8', 'admin@procol.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef1a0f1f23db0b8123f02f74204fe8'),
(0x11ef3425e27dd67b8309f02f74204fe8, 'scheda', '2024-06-27 03:37:56', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2cd1b6ca572a9c84f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2cd1b6ca572a9c84f02f74204fe8'),
(0x11ef3425e4375b3e8309f02f74204fe8, 'scheda', '2024-06-27 03:37:59', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef0bee9fd9b842813af02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef0bee9fd9b842813af02f74204fe8'),
(0x11ef3425e5e77aed8309f02f74204fe8, 'scheda', '2024-06-27 03:38:02', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2c0b3398990e9219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2c0b3398990e9219f02f74204fe8'),
(0x11ef3425e702d3ea8309f02f74204fe8, 'scheda', '2024-06-27 03:38:04', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef0bebc4931faa813af02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef0bebc4931faa813af02f74204fe8'),
(0x11ef3425e8acf6148309f02f74204fe8, 'scheda', '2024-06-27 03:38:07', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef0bebc490a8f6813af02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef0bebc490a8f6813af02f74204fe8'),
(0x11ef3425ea0810d18309f02f74204fe8, 'scheda', '2024-06-27 03:38:09', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef0bebc4946cf9813af02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef0bebc4946cf9813af02f74204fe8'),
(0x11ef3425eb536c1d8309f02f74204fe8, 'scheda', '2024-06-27 03:38:11', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef0bebc48b5ac9813af02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef0bebc48b5ac9813af02f74204fe8'),
(0x11ef3425ecf338b58309f02f74204fe8, 'scheda', '2024-06-27 03:38:14', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef0beb94cde5f9813af02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef0beb94cde5f9813af02f74204fe8'),
(0x11ef3425ee160f628309f02f74204fe8, 'scheda', '2024-06-27 03:38:16', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef0bebc48dcaaf813af02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef0bebc48dcaaf813af02f74204fe8'),
(0x11ef3425ef75de108309f02f74204fe8, 'scheda', '2024-06-27 03:38:18', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2b3c04db35cc9219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2b3c04db35cc9219f02f74204fe8'),
(0x11ef3425f20188c78309f02f74204fe8, 'scheda', '2024-06-27 03:38:22', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef2e57726a64d6935ff02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Sql Prova', NULL, 'goshin26@icloud.com', '14-Sql Prova-11ef2e57726a64d6935ff02f74204fe8'),
(0x11ef3425f37729cb8309f02f74204fe8, 'scheda', '2024-06-27 03:38:25', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef309ca11ab6969e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Vittoria', NULL, 'goshin26@icloud.com', '14-Vittoria-11ef309ca11ab6969e85f02f74204fe8'),
(0x11ef3425f4e9a06e8309f02f74204fe8, 'scheda', '2024-06-27 03:38:27', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef2b3acde221799219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Dasdsad', NULL, 'goshin26@icloud.com', '14-Dasdsad-11ef2b3acde221799219f02f74204fe8'),
(0x11ef3425f5dc7e678309f02f74204fe8, 'scheda', '2024-06-27 03:38:29', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef2b3acec94ee49219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Dasdsad', NULL, 'goshin26@icloud.com', '14-Dasdsad-11ef2b3acec94ee49219f02f74204fe8'),
(0x11ef3425f7bde1a68309f02f74204fe8, 'scheda', '2024-06-27 03:38:32', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef2b3ae3b199fa9219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Dasdsad', NULL, 'goshin26@icloud.com', '14-Dasdsad-11ef2b3ae3b199fa9219f02f74204fe8'),
(0x11ef3425f939f2c28309f02f74204fe8, 'scheda', '2024-06-27 03:38:34', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef2b3c2a30d8629219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Dasdsad', NULL, 'goshin26@icloud.com', '14-Dasdsad-11ef2b3c2a30d8629219f02f74204fe8'),
(0x11ef3425faf399c98309f02f74204fe8, 'scheda', '2024-06-27 03:38:37', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef2b3d2dd39d879219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Dasdsad', NULL, 'goshin26@icloud.com', '14-Dasdsad-11ef2b3d2dd39d879219f02f74204fe8'),
(0x11ef3425fcdfcd1b8309f02f74204fe8, 'scheda', '2024-06-27 03:38:40', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef2b4300c3705f9219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Hfgh', NULL, 'goshin26@icloud.com', '14-Hfgh-11ef2b4300c3705f9219f02f74204fe8'),
(0x11ef342668771daf8309f02f74204fe8, 'scheda', '2024-06-27 03:41:41', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef2e4c53d40ba0935ff02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Fsdfdsfsdfsd', NULL, 'goshin26@icloud.com', '14-Fsdfdsfsdfsd-11ef2e4c53d40ba0935ff02f74204fe8'),
(0x11ef342718a30a1b8309f02f74204fe8, 'progetto', '2024-06-27 03:46:36', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Hfgh', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Hfgh'),
(0x11ef34271f56a1ad8309f02f74204fe8, 'progetto', '2024-06-27 03:46:48', 'goshin26@icloud.com', 'Oscuramento Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Fsdfdsfsdfsd', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Fsdfdsfsdfsd'),
(0x11ef3428a21c1b1c8309f02f74204fe8, 'scheda', '2024-06-27 03:57:37', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2e57726a64d6935ff02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2e57726a64d6935ff02f74204fe8'),
(0x11ef3428a30fd8678309f02f74204fe8, 'scheda', '2024-06-27 03:57:38', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef309ca11ab6969e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef309ca11ab6969e85f02f74204fe8'),
(0x11ef3428a557269a8309f02f74204fe8, 'scheda', '2024-06-27 03:57:42', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2b3acde221799219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2b3acde221799219f02f74204fe8'),
(0x11ef3428aa7f1c168309f02f74204fe8, 'scheda', '2024-06-27 03:57:51', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2b3c2a30d8629219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2b3c2a30d8629219f02f74204fe8'),
(0x11ef3428ab9f0bea8309f02f74204fe8, 'scheda', '2024-06-27 03:57:53', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2b3ae3b199fa9219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2b3ae3b199fa9219f02f74204fe8'),
(0x11ef3428ad25e1ec8309f02f74204fe8, 'scheda', '2024-06-27 03:57:55', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2b3acec94ee49219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2b3acec94ee49219f02f74204fe8'),
(0x11ef3428af7d902d8309f02f74204fe8, 'scheda', '2024-06-27 03:57:59', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2b4300c3705f9219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2b4300c3705f9219f02f74204fe8'),
(0x11ef3428b09e13778309f02f74204fe8, 'scheda', '2024-06-27 03:58:01', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2e4c53d40ba0935ff02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2e4c53d40ba0935ff02f74204fe8'),
(0x11ef3428b22de9738309f02f74204fe8, 'scheda', '2024-06-27 03:58:04', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef2b3d2dd39d879219f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef2b3d2dd39d879219f02f74204fe8'),
(0x11ef3428ece0a1b68309f02f74204fe8, 'scheda', '2024-06-27 03:59:42', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef3428ece086ef8309f02f74204fe8', NULL, NULL, 14, 'Dasdsad', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Dasdsad-11ef3428ece086ef8309f02f74204fe8'),
(0x11ef3428ef0495448309f02f74204fe8, 'scheda', '2024-06-27 03:59:46', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef3428ece086ef8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Dasdsad', NULL, 'goshin26@icloud.com', '14-Dasdsad-11ef3428ece086ef8309f02f74204fe8'),
(0x11ef3428f08464da8309f02f74204fe8, 'progetto', '2024-06-27 03:59:48', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Dasdsad', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Dasdsad'),
(0x11ef3428f1890e868309f02f74204fe8, 'progetto', '2024-06-27 03:59:50', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Fsdfdsfsdfsd', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Fsdfdsfsdfsd'),
(0x11ef3428f37606228309f02f74204fe8, 'progetto', '2024-06-27 03:59:53', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Ssssssssssssssssssss', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Ssssssssssssssssssss'),
(0x11ef3428f9f312fa8309f02f74204fe8, 'progetto', '2024-06-27 04:00:04', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Comm Nu Verd', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Comm Nu Verd'),
(0x11ef3428fb98ea3d8309f02f74204fe8, 'progetto', '2024-06-27 04:00:07', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Rewrwer', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Rewrwer'),
(0x11ef3428fcdfe9128309f02f74204fe8, 'progetto', '2024-06-27 04:00:09', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Asdas', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Asdas'),
(0x11ef3428fe02a35f8309f02f74204fe8, 'progetto', '2024-06-27 04:00:11', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Dsadsa', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Dsadsa'),
(0x11ef3429005536b78309f02f74204fe8, 'progetto', '2024-06-27 04:00:15', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Dsadsad', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Dsadsad'),
(0x11ef342902ccad658309f02f74204fe8, 'scheda', '2024-06-27 04:00:19', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef30239e842993935ff02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Dsfdsf', NULL, 'goshin26@icloud.com', '14-Dsfdsf-11ef30239e842993935ff02f74204fe8'),
(0x11ef34290442a1238309f02f74204fe8, 'scheda', '2024-06-27 04:00:21', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef3027bf0fd71a935ff02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Dsfdsf', NULL, 'goshin26@icloud.com', '14-Dsfdsf-11ef3027bf0fd71a935ff02f74204fe8'),
(0x11ef342907e0bff38309f02f74204fe8, 'scheda', '2024-06-27 04:00:27', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef309c857f4e379e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gfdgfdg', NULL, 'goshin26@icloud.com', '14-Gfdgfdg-11ef309c857f4e379e85f02f74204fe8'),
(0x11ef342909d163808309f02f74204fe8, 'progetto', '2024-06-27 04:00:31', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Gfdgfdg', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Gfdgfdg'),
(0x11ef34290b36cf288309f02f74204fe8, 'progetto', '2024-06-27 04:00:33', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Fdsfsd', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Fdsfsd'),
(0x11ef3429de476f378309f02f74204fe8, 'scheda', '2024-06-27 04:06:27', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef3429de475e728309f02f74204fe8', NULL, NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Gdfgfd-11ef3429de475e728309f02f74204fe8'),
(0x11ef342a9009baf18309f02f74204fe8, 'scheda', '2024-06-27 04:11:25', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef3428ece086ef8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef3428ece086ef8309f02f74204fe8'),
(0x11ef342a9104ea2f8309f02f74204fe8, 'scheda', '2024-06-27 04:11:27', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef3027bf0fd71a935ff02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef3027bf0fd71a935ff02f74204fe8'),
(0x11ef342a928f48478309f02f74204fe8, 'scheda', '2024-06-27 04:11:30', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef30239e842993935ff02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef30239e842993935ff02f74204fe8'),
(0x11ef342a93a632078309f02f74204fe8, 'scheda', '2024-06-27 04:11:31', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef309c857f4e379e85f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef309c857f4e379e85f02f74204fe8'),
(0x11ef342a982f4f9d8309f02f74204fe8, 'scheda', '2024-06-27 04:11:39', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef33a63f2881098309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', '14-Gdfgfd-11ef33a63f2881098309f02f74204fe8'),
(0x11ef342a9b14d07e8309f02f74204fe8, 'progetto', '2024-06-27 04:11:44', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Gdfgfd', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Gdfgfd'),
(0x11ef342a9d9421468309f02f74204fe8, 'progetto', '2024-06-27 04:11:48', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Dsfdsf', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Dsfdsf'),
(0x11ef342aa096768f8309f02f74204fe8, 'scheda', '2024-06-27 04:11:53', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef33a63f2881098309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef33a63f2881098309f02f74204fe8'),
(0x11ef3490b009493a8309f02f74204fe8, 'scheda', '2024-06-27 16:22:25', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef33d8972bcf8b8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11ef33d8972bcf8b8309f02f74204fe8'),
(0x11ef3490db048fd88309f02f74204fe8, 'scheda', '2024-06-27 16:23:37', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef33d8972bcf8b8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef33d8972bcf8b8309f02f74204fe8');
INSERT INTO `report` (`uuid_report`, `tipo_azione`, `timestamp`, `attore`, `descrizione`, `link`, `utente`, `team`, `progetto`, `categoria`, `scheda`, `attore_era`, `bersaglio_era`) VALUES
(0x11ef34918234cc568309f02f74204fe8, 'scheda', '2024-06-27 16:28:18', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34918234945d8309f02f74204fe8', NULL, NULL, 14, 'Invisibile', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Invisibile-11ef34918234945d8309f02f74204fe8'),
(0x11ef34918bca19068309f02f74204fe8, 'scheda', '2024-06-27 16:28:34', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef34918234945d8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Invisibile', NULL, 'goshin26@icloud.com', '14-Invisibile-11ef34918234945d8309f02f74204fe8'),
(0x11ef3491919ec7b38309f02f74204fe8, 'scheda', '2024-06-27 16:28:44', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef34918234945d8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef34918234945d8309f02f74204fe8'),
(0x11ef349196a2d3718309f02f74204fe8, 'scheda', '2024-06-27 16:28:52', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef349196a23aa68309f02f74204fe8', NULL, NULL, 14, 'Invisibile', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Invisibile-11ef349196a23aa68309f02f74204fe8'),
(0x11ef3491994967058309f02f74204fe8, 'scheda', '2024-06-27 16:28:57', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef349196a23aa68309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Invisibile', NULL, 'goshin26@icloud.com', '14-Invisibile-11ef349196a23aa68309f02f74204fe8'),
(0x11ef3491a2bdb3168309f02f74204fe8, 'scheda', '2024-06-27 16:29:13', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef349196a23aa68309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef349196a23aa68309f02f74204fe8'),
(0x11ef3491ab4640f68309f02f74204fe8, 'scheda', '2024-06-27 16:29:27', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef3491ab45987d8309f02f74204fe8', NULL, NULL, 14, 'Invisibile', 0x11ef3491ab45987d8309f02f74204fe8, 'goshin26@icloud.com', 'No Utente-SAD-14-Invisibile-11ef3491ab45987d8309f02f74204fe8'),
(0x11ef3491ad89594c8309f02f74204fe8, 'scheda', '2024-06-27 16:29:31', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef3491ab45987d8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Invisibile', 0x11ef3491ab45987d8309f02f74204fe8, 'goshin26@icloud.com', '14-Invisibile-11ef3491ab45987d8309f02f74204fe8'),
(0x11ef34c7c43bc9158309f02f74204fe8, 'scheda', '2024-06-27 22:56:42', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34c7c43b4b828309f02f74204fe8', NULL, NULL, 14, 'Invisibile', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Invisibile-11ef34c7c43b4b828309f02f74204fe8'),
(0x11ef34d93f474e8c8309f02f74204fe8, 'scheda', '2024-06-28 01:01:49', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34d93f466a0c8309f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Passa Qui-11ef34d93f466a0c8309f02f74204fe8'),
(0x11ef34d949f755e58309f02f74204fe8, 'scheda', '2024-06-28 01:02:07', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=14&post=11ef34d93f466a0c8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', '14-Passa Qui-11ef34d93f466a0c8309f02f74204fe8'),
(0x11ef34d9552a049e8309f02f74204fe8, 'scheda', '2024-06-28 01:02:26', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=14&post=11ef34d93f466a0c8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', NULL, 'goshin26@icloud.com', '14-Eliminate-11ef34d93f466a0c8309f02f74204fe8'),
(0x11ef34daf48058398309f02f74204fe8, 'scheda', '2024-06-28 01:14:03', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34daf47f518e8309f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Passa Qui-11ef34daf47f518e8309f02f74204fe8'),
(0x11ef34daf6e30e248309f02f74204fe8, 'scheda', '2024-06-28 01:14:07', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34daf6e2fb528309f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Passa Qui-11ef34daf6e2fb528309f02f74204fe8'),
(0x11ef34daf7dc89758309f02f74204fe8, 'scheda', '2024-06-28 01:14:09', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34daf7dc53298309f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Passa Qui-11ef34daf7dc53298309f02f74204fe8'),
(0x11ef34daf913bc908309f02f74204fe8, 'scheda', '2024-06-28 01:14:11', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34daf91394898309f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Passa Qui-11ef34daf91394898309f02f74204fe8'),
(0x11ef34dafa423a9f8309f02f74204fe8, 'scheda', '2024-06-28 01:14:13', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34dafa42120f8309f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Passa Qui-11ef34dafa42120f8309f02f74204fe8'),
(0x11ef34dafb8929268309f02f74204fe8, 'scheda', '2024-06-28 01:14:15', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34dafb891a088309f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Passa Qui-11ef34dafb891a088309f02f74204fe8'),
(0x11ef34dafc9435fe8309f02f74204fe8, 'scheda', '2024-06-28 01:14:17', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34dafc9423a08309f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Passa Qui-11ef34dafc9423a08309f02f74204fe8'),
(0x11ef34dafdaf7d118309f02f74204fe8, 'scheda', '2024-06-28 01:14:18', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34dafdaf62ea8309f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Passa Qui-11ef34dafdaf62ea8309f02f74204fe8'),
(0x11ef34db0190a11c8309f02f74204fe8, 'scheda', '2024-06-28 01:14:25', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34db01908f968309f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Passa Qui-11ef34db01908f968309f02f74204fe8'),
(0x11ef34db02e0e7808309f02f74204fe8, 'scheda', '2024-06-28 01:14:27', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34db02e0ca8f8309f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Passa Qui-11ef34db02e0ca8f8309f02f74204fe8'),
(0x11ef34db05eaf9de8309f02f74204fe8, 'scheda', '2024-06-28 01:14:32', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34db05eae1728309f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Passa Qui-11ef34db05eae1728309f02f74204fe8'),
(0x11ef34db28751f448309f02f74204fe8, 'scheda', '2024-06-28 01:15:30', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34db28747d168309f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Passa Qui-11ef34db28747d168309f02f74204fe8'),
(0x11ef34db2adefd568309f02f74204fe8, 'scheda', '2024-06-28 01:15:34', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34db2adef1408309f02f74204fe8', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Passa Qui-11ef34db2adef1408309f02f74204fe8'),
(0x11ef34db485276298309f02f74204fe8, 'progetto', '2024-06-28 01:16:24', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Passa Qui', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Passa Qui'),
(0x11ef34db527d0f1d8309f02f74204fe8, 'progetto', '2024-06-28 01:16:41', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Invisibile', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Invisibile'),
(0x11ef34db53ebee6e8309f02f74204fe8, 'progetto', '2024-06-28 01:16:43', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Comm Nu Verde', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Comm Nu Verde'),
(0x11ef34db552c3a188309f02f74204fe8, 'progetto', '2024-06-28 01:16:45', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Riaggiungo', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Riaggiungo'),
(0x11ef34db5d7249c28309f02f74204fe8, 'scheda', '2024-06-28 01:16:59', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34db5d7220d08309f02f74204fe8', NULL, NULL, 14, 'Vittoria', 0x11ef34db5d7220d08309f02f74204fe8, 'goshin26@icloud.com', 'No Utente-SAD-14-Vittoria-11ef34db5d7220d08309f02f74204fe8'),
(0x11ef34db6cfda81c8309f02f74204fe8, 'scheda', '2024-06-28 01:17:25', 'goshin26@icloud.com', 'Aggiunta Descrizione Scheda', 'board.html?proj=14&post=11ef34db5d7220d08309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Vittoria', 0x11ef34db5d7220d08309f02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Vittoria-11ef34db5d7220d08309f02f74204fe8'),
(0x11ef34dba40eccbb8309f02f74204fe8, 'progetto', '2024-06-28 01:18:58', 'goshin26@icloud.com', 'Creazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Hahah', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Hahah'),
(0x11ef34dc57a548d68309f02f74204fe8, 'scheda', '2024-06-28 01:23:59', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef34db5d7220d08309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Completate', 0x11ef34db5d7220d08309f02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Completate-11ef34db5d7220d08309f02f74204fe8'),
(0x11ef34dc5b24556a8309f02f74204fe8, 'scheda', '2024-06-28 01:24:05', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef34db5d7220d08309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'In Corso', 0x11ef34db5d7220d08309f02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-In Corso-11ef34db5d7220d08309f02f74204fe8'),
(0x11ef34dc6259d8348309f02f74204fe8, 'scheda', '2024-06-28 01:24:17', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef34db5d7220d08309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Hahah', 0x11ef34db5d7220d08309f02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Hahah-11ef34db5d7220d08309f02f74204fe8'),
(0x11ef34dc66b00c0b8309f02f74204fe8, 'scheda', '2024-06-28 01:24:24', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef34db5d7220d08309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Completate', 0x11ef34db5d7220d08309f02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Completate-11ef34db5d7220d08309f02f74204fe8'),
(0x11ef34e4a403d6938309f02f74204fe8, 'progetto', '2024-06-28 02:23:23', 'goshin26@icloud.com', 'Creazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Ciao', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Ciao'),
(0x11ef34e4ac38b6308309f02f74204fe8, 'scheda', '2024-06-28 02:23:37', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34e4ac36c58c8309f02f74204fe8', NULL, NULL, 14, 'Ciao', 0x11ef34e4ac36c58c8309f02f74204fe8, 'goshin26@icloud.com', 'No Utente-SAD-14-Ciao-11ef34e4ac36c58c8309f02f74204fe8'),
(0x11ef34e4b0dc74228309f02f74204fe8, 'scheda', '2024-06-28 02:23:44', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef34e4ac36c58c8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Sql Prova', 0x11ef34e4ac36c58c8309f02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Sql Prova-11ef34e4ac36c58c8309f02f74204fe8'),
(0x11ef34eb93b7d6df8309f02f74204fe8, 'scheda', '2024-06-28 03:13:02', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef34eb93b6eb178309f02f74204fe8', NULL, NULL, 14, 'Ciao', 0x11ef34eb93b6eb178309f02f74204fe8, 'goshin26@icloud.com', 'No Utente-SAD-14-Ciao-11ef34eb93b6eb178309f02f74204fe8'),
(0x11ef35689948c18f8309f02f74204fe8, 'progetto', '2024-06-28 18:07:59', 'goshin26@icloud.com', 'Creazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Dsadsad', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Dsadsad'),
(0x11ef35689b8920308309f02f74204fe8, 'progetto', '2024-06-28 18:08:03', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Dsadsad', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Dsadsad'),
(0x11ef3570f0d178878309f02f74204fe8, 'scheda', '2024-06-28 19:07:42', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef34eb93b6eb178309f02f74204fe8#repl=11ef3570f0cefacc8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Ciao', 0x11ef34eb93b6eb178309f02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Ciao-11ef34eb93b6eb178309f02f74204fe8-11ef3570f0cefacc8309f02f74204fe8'),
(0x11ef3571107fbef68309f02f74204fe8, 'scheda', '2024-06-28 19:08:35', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef34eb93b6eb178309f02f74204fe8#repl=11ef3571107f1fbb8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Ciao', 0x11ef34eb93b6eb178309f02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Ciao-11ef34eb93b6eb178309f02f74204fe8-11ef3571107f1fbb8309f02f74204fe8'),
(0x11ef357118e36bbe8309f02f74204fe8, 'scheda', '2024-06-28 19:08:49', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=14&post=11ef34eb93b6eb178309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Ciao', 0x11ef34eb93b6eb178309f02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Ciao-11ef34eb93b6eb178309f02f74204fe8'),
(0x11ef35712c1edb1c8309f02f74204fe8, 'scheda', '2024-06-28 19:09:21', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef34eb93b6eb178309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'In Attesa', 0x11ef34eb93b6eb178309f02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-In Attesa-11ef34eb93b6eb178309f02f74204fe8'),
(0x11ef3571839c5f1e8309f02f74204fe8, 'scheda', '2024-06-28 19:11:48', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef34eb93b6eb178309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Completate', 0x11ef34eb93b6eb178309f02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Completate-11ef34eb93b6eb178309f02f74204fe8'),
(0x11ef357187dca2438309f02f74204fe8, 'scheda', '2024-06-28 19:11:55', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef34eb93b6eb178309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Ciao', 0x11ef34eb93b6eb178309f02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Ciao-11ef34eb93b6eb178309f02f74204fe8'),
(0x11ef37137d62e0bc8309f02f74204fe8, 'utente', '2024-06-30 21:03:44', 'admin@procol.com', 'Promozione Utente', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'ciccio@bastardo.it'),
(0x11ef37137f4870fb8309f02f74204fe8, 'utente', '2024-06-30 21:03:47', 'admin@procol.com', 'Promozione Utente', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'ciccio@bastardo.it'),
(0x11ef37138144952b8309f02f74204fe8, 'utente', '2024-06-30 21:03:51', 'admin@procol.com', 'Declassamento Utente', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'ciccio@bastardo.it'),
(0x11ef3713835e57a88309f02f74204fe8, 'utente', '2024-06-30 21:03:54', 'admin@procol.com', 'Declassamento Utente', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'ciccio@bastardo.it'),
(0x11ef3713890361f08309f02f74204fe8, 'team', '2024-06-30 21:04:04', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'ciccio@bastardo.it-SAD'),
(0x11ef37138c1650fe8309f02f74204fe8, 'team', '2024-06-30 21:04:09', 'admin@procol.com', 'Rimozione Utente Da Team', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'ciccio@bastardo.it-SAD'),
(0x11ef371399fad45c8309f02f74204fe8, 'progetto', '2024-06-30 21:04:32', 'admin@procol.com', 'Creazione Progetto', 'board.html?proj=71', NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'No Utente-No Team-71'),
(0x11ef37139cf5efc98309f02f74204fe8, 'progetto', '2024-06-30 21:04:37', 'admin@procol.com', 'Cancellazione Progetto', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'No Utente-No Team-70'),
(0x11ef3713a2eac4d78309f02f74204fe8, 'progetto', '2024-06-30 21:04:47', 'admin@procol.com', 'Aggiornamento Progetto', 'board.html?proj=61', NULL, NULL, 61, NULL, NULL, 'admin@procol.com', 'No Utente--61'),
(0x11ef3713a7cb9cbc8309f02f74204fe8, 'progetto', '2024-06-30 21:04:55', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=61', NULL, NULL, 61, NULL, NULL, 'admin@procol.com', 'No Utente-MRS-61'),
(0x11ef3713b0158dfc8309f02f74204fe8, 'utente', '2024-06-30 21:05:09', 'admin@procol.com', 'Promozione Utente', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'ciccio@bastardo.it'),
(0x11ef3713b016c03a8309f02f74204fe8, 'team', '2024-06-30 21:05:09', 'admin@procol.com', 'Creazione Team', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'ciccio@bastardo.it-BOH'),
(0x11ef3713b671a4f28309f02f74204fe8, 'team', '2024-06-30 21:05:20', 'admin@procol.com', 'Assegnazione Team', NULL, 'utente.prova1@procol.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'utente.prova1@procol.com-BOH'),
(0x11ef3713b9acc0e88309f02f74204fe8, 'progetto', '2024-06-30 21:05:25', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=71', NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'No Utente-BOH-71'),
(0x11ef3713bd0412258309f02f74204fe8, 'progetto', '2024-06-30 21:05:31', 'admin@procol.com', 'Cancellazione Progetto', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'No Utente-No Team-71'),
(0x11ef3713bec2cd0e8309f02f74204fe8, 'team', '2024-06-30 21:05:34', 'admin@procol.com', 'Eliminazione Team', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'No Utente-BOH'),
(0x11ef3713c33df65a8309f02f74204fe8, 'utente', '2024-06-30 21:05:41', 'admin@procol.com', 'Eliminazione Utente', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'ciccio@bastardo.it'),
(0x11ef372567c4c7ba8309f02f74204fe8, 'progetto', '2024-06-30 23:12:00', 'admin@procol.com', 'Aggiornamento Progetto', 'board.html?proj=61', NULL, NULL, 61, NULL, NULL, 'admin@procol.com', 'No Utente-MRS-61'),
(0x11ef372b57724ea78309f02f74204fe8, 'team', '2024-06-30 23:54:30', 'admin@procol.com', 'Aggiornamento Team', NULL, 'goshin26@icloud.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'goshin26@icloud.com-SAD'),
(0x11ef372b5c63f3f08309f02f74204fe8, 'team', '2024-06-30 23:54:38', 'admin@procol.com', 'Aggiornamento Team', NULL, 'goshin26@icloud.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'goshin26@icloud.com-SAD'),
(0x11ef374468f6408e8309f02f74204fe8, 'scheda', '2024-07-01 02:53:56', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef374468f510a58309f02f74204fe8', NULL, NULL, 14, 'Ciao', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Ciao-11ef374468f510a58309f02f74204fe8'),
(0x11ef37446ccf1ae38309f02f74204fe8, 'scheda', '2024-07-01 02:54:03', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef374468f510a58309f02f74204fe8#repl=11ef37446cce610f8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Ciao', NULL, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Ciao-11ef374468f510a58309f02f74204fe8-11ef37446cce610f8309f02f74204fe8'),
(0x11ef37446eebf41b8309f02f74204fe8, 'scheda', '2024-07-01 02:54:06', 'goshin26@icloud.com', 'Risposta Commento', 'board.html?proj=14&post=11ef374468f510a58309f02f74204fe8#repl=11ef37446eebcb2a8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Ciao', NULL, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Ciao-11ef374468f510a58309f02f74204fe8-11ef37446eebcb2a8309f02f74204fe8'),
(0x11ef3744e204bbdd8309f02f74204fe8, 'scheda', '2024-07-01 02:57:20', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef374468f510a58309f02f74204fe8#repl=11ef3744e2047d5c8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Ciao', NULL, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Ciao-11ef374468f510a58309f02f74204fe8-11ef3744e2047d5c8309f02f74204fe8'),
(0x11ef3744e69b479c8309f02f74204fe8, 'scheda', '2024-07-01 02:57:27', 'goshin26@icloud.com', 'Eliminazione Commento', 'board.html?proj=14&post=11ef374468f510a58309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Ciao', NULL, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Ciao-11ef374468f510a58309f02f74204fe8-11ef3744e2047d5c8309f02f74204fe8'),
(0x11ef3745c71c0f128309f02f74204fe8, 'progetto', '2024-07-01 03:03:44', 'admin@procol.com', 'Creazione Categoria', 'board.html?proj=55', NULL, NULL, 55, 'Asd', NULL, 'admin@procol.com', 'No Utente-MRS-55-Asd'),
(0x11ef3745cc5f0e2c8309f02f74204fe8, 'scheda', '2024-07-01 03:03:53', 'admin@procol.com', 'Creazione Scheda', 'board.html?proj=55&post=11ef3745cc5ee2db8309f02f74204fe8', NULL, NULL, 55, 'Asd', NULL, 'admin@procol.com', 'No Utente-MRS-55-Asd-11ef3745cc5ee2db8309f02f74204fe8'),
(0x11ef3745cf0a66488309f02f74204fe8, 'scheda', '2024-07-01 03:03:57', 'admin@procol.com', 'Creazione Commento', 'board.html?proj=55&post=11ef3745cc5ee2db8309f02f74204fe8#repl=11ef3745cf0a36618309f02f74204fe8', 'admin@procol.com', NULL, 55, 'Asd', NULL, 'admin@procol.com', 'admin@procol.com-MRS-55-Asd-11ef3745cc5ee2db8309f02f74204fe8-11ef3745cf0a36618309f02f74204fe8'),
(0x11ef3745d4f01a9d8309f02f74204fe8, 'scheda', '2024-07-01 03:04:07', 'admin@procol.com', 'Modifica Commento', 'board.html?proj=55&post=11ef3745cc5ee2db8309f02f74204fe8#repl=11ef3745cf0a36618309f02f74204fe8', 'admin@procol.com', NULL, 55, 'Asd', NULL, 'admin@procol.com', 'admin@procol.com-MRS-55-Asd-11ef3745cc5ee2db8309f02f74204fe8-11ef3745cf0a36618309f02f74204fe8'),
(0x11ef378d3b26a5778309f02f74204fe8, 'sessione', '2024-07-01 11:35:11', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef378dbd3d5f1c8309f02f74204fe8, 'sessione', '2024-07-01 11:38:49', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef37921f547a7d8309f02f74204fe8, 'sessione', '2024-07-01 12:10:11', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef379242926d918309f02f74204fe8, 'sessione', '2024-07-01 12:11:11', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef37951de51f9c8309f02f74204fe8, 'progetto', '2024-07-01 12:31:37', 'admin@procol.com', 'Creazione Progetto', 'board.html?proj=72', NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'No Utente-No Team-72'),
(0x11ef37959013fcdc8309f02f74204fe8, 'progetto', '2024-07-01 12:34:49', 'admin@procol.com', 'Aggiornamento Progetto', 'board.html?proj=72', NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'No Utente--72'),
(0x11ef379ade8c604a8309f02f74204fe8, 'progetto', '2024-07-01 13:12:48', 'admin@procol.com', 'Creazione Progetto', 'board.html?proj=73', NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'No Utente-No Team-73'),
(0x11ef379ca624c6528309f02f74204fe8, 'progetto', '2024-07-01 13:25:33', 'admin@procol.com', '', 'board.html?proj=55', NULL, NULL, 55, NULL, NULL, 'admin@procol.com', 'No Utente-MRS-55'),
(0x11ef379ca8cb51568309f02f74204fe8, 'progetto', '2024-07-01 13:25:37', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=55', NULL, NULL, 55, NULL, NULL, 'admin@procol.com', 'No Utente--55'),
(0x11ef379cad1a07f48309f02f74204fe8, 'progetto', '2024-07-01 13:25:44', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=55', NULL, NULL, 55, NULL, NULL, 'admin@procol.com', 'No Utente--55'),
(0x11ef379d864602d68309f02f74204fe8, 'progetto', '2024-07-01 13:31:49', 'admin@procol.com', '', 'board.html?proj=55', NULL, NULL, 55, NULL, NULL, 'admin@procol.com', 'No Utente-MRS-55'),
(0x11ef379e393318c88309f02f74204fe8, 'progetto', '2024-07-01 13:36:49', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=61', NULL, NULL, 61, NULL, NULL, 'admin@procol.com', ''),
(0x11ef379e3bcda7f98309f02f74204fe8, 'progetto', '2024-07-01 13:36:53', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=61', NULL, NULL, 61, NULL, NULL, 'admin@procol.com', 'MRS'),
(0x11ef379e8b656bb38309f02f74204fe8, 'progetto', '2024-07-01 13:39:07', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=61', NULL, NULL, 61, NULL, NULL, 'admin@procol.com', 'No Utente--61'),
(0x11ef379e8db971668309f02f74204fe8, 'progetto', '2024-07-01 13:39:11', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=61', NULL, NULL, 61, NULL, NULL, 'admin@procol.com', 'No Utente-MRS-61'),
(0x11ef379ea398a0fd8309f02f74204fe8, 'progetto', '2024-07-01 13:39:47', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=61', NULL, NULL, 61, NULL, NULL, 'admin@procol.com', 'No Utente-No Team-61'),
(0x11ef379ea631c1418309f02f74204fe8, 'progetto', '2024-07-01 13:39:52', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=61', NULL, NULL, 61, NULL, NULL, 'admin@procol.com', 'No Utente-MRS-61'),
(0x11ef379eb9d1d0968309f02f74204fe8, 'team', '2024-07-01 13:40:25', 'admin@procol.com', 'Assegnazione Team', NULL, 'utente.prova1@procol.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'utente.prova1@procol.com-MRS'),
(0x11ef379ec21c74b98309f02f74204fe8, 'team', '2024-07-01 13:40:38', 'admin@procol.com', 'Assegnazione Team', NULL, 'filomena.marasco@procol.it', NULL, NULL, NULL, NULL, 'admin@procol.com', 'filomena.marasco@procol.it-MRS'),
(0x11ef37a06f8a54fd8309f02f74204fe8, 'team', '2024-07-01 13:52:39', 'admin@procol.com', 'Rimozione Utente Da Team', NULL, 'utente.prova1@procol.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'utente.prova1@procol.com-MRS'),
(0x11ef37a1aa595f968309f02f74204fe8, 'scheda', '2024-07-01 14:01:27', 'admin@procol.com', 'Creazione Commento', 'board.html?proj=14&post=11ef374468f510a58309f02f74204fe8#repl=11ef37a1aa5728238309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Ciao', NULL, 'admin@procol.com', 'goshin26@icloud.com-MRS-14-Ciao-11ef374468f510a58309f02f74204fe8-11ef37a1aa5728238309f02f74204fe8'),
(0x11ef37a23f23e2768309f02f74204fe8, 'scheda', '2024-07-01 14:05:37', 'admin@procol.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef374468f510a58309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Hahah', NULL, 'admin@procol.com', 'goshin26@icloud.com-MRS-14-Hahah-11ef374468f510a58309f02f74204fe8'),
(0x11ef37a24258eef08309f02f74204fe8, 'scheda', '2024-07-01 14:05:42', 'admin@procol.com', 'Cambiamento Stato', 'board.html?proj=14&post=11ef374468f510a58309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Ciao', NULL, 'admin@procol.com', 'goshin26@icloud.com-MRS-14-Ciao-11ef374468f510a58309f02f74204fe8'),
(0x11ef37a2fc8b3f7a8309f02f74204fe8, 'scheda', '2024-07-01 14:10:54', 'admin@procol.com', 'Modifica Commento', 'board.html?proj=14&post=11ef374468f510a58309f02f74204fe8#repl=11ef37a1aa5728238309f02f74204fe8', 'admin@procol.com', NULL, 14, 'Ciao', NULL, 'admin@procol.com', 'admin@procol.com-MRS-14-Ciao-11ef374468f510a58309f02f74204fe8-11ef37a1aa5728238309f02f74204fe8'),
(0x11ef37a32327b12e8309f02f74204fe8, 'sessione', '2024-07-01 14:11:59', 'filomena.marasco@procol.it', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'filomena.marasco@procol.it', NULL),
(0x11ef37a37f5922008309f02f74204fe8, 'sessione', '2024-07-01 14:14:34', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef37a39c4f45228309f02f74204fe8, 'sessione', '2024-07-01 14:15:23', 'filomena.marasco@procol.it', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'filomena.marasco@procol.it', NULL),
(0x11ef37ad367459b18309f02f74204fe8, 'sessione', '2024-07-01 15:24:07', 'filomena.marasco@procol.it', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'filomena.marasco@procol.it', NULL),
(0x11ef37aec64895108309f02f74204fe8, 'sessione', '2024-07-01 15:35:17', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef37aef0a714ce8309f02f74204fe8, 'sessione', '2024-07-01 15:36:28', 'filomena.marasco@procol.it', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'filomena.marasco@procol.it', NULL),
(0x11ef37ccf3d2cc798309f02f74204fe8, 'sessione', '2024-07-01 19:11:19', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef37cd39f543248309f02f74204fe8, 'sessione', '2024-07-01 19:13:16', 'luigi.puca@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'luigi.puca@procol.com', NULL),
(0x11ef37cd8cf8ed118309f02f74204fe8, 'sessione', '2024-07-01 19:15:36', 'filomena.marasco@procol.it', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'filomena.marasco@procol.it', NULL),
(0x11ef37d0e83686ea8309f02f74204fe8, 'sessione', '2024-07-01 19:39:37', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef37d11933665d8309f02f74204fe8, 'sessione', '2024-07-01 19:40:59', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef37d4122afc618309f02f74204fe8, 'scheda', '2024-07-01 20:02:16', 'admin@procol.com', 'Creazione Commento', 'board.html?proj=14&post=11ef374468f510a58309f02f74204fe8#repl=11ef37d4122782218309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Ciao', NULL, 'admin@procol.com', 'goshin26@icloud.com-SAD-14-Ciao-11ef374468f510a58309f02f74204fe8-11ef37d4122782218309f02f74204fe8'),
(0x11ef37d4378e130c8309f02f74204fe8, 'sessione', '2024-07-01 20:03:19', 'filomena.marasco@procol.it', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'filomena.marasco@procol.it', NULL),
(0x11ef37d66fa9ceb58309f02f74204fe8, 'sessione', '2024-07-01 20:19:12', 'luigi.puca@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'luigi.puca@procol.com', NULL),
(0x11ef37d781e980068309f02f74204fe8, 'sessione', '2024-07-01 20:26:52', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef37d89848797b8309f02f74204fe8, 'sessione', '2024-07-01 20:34:39', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef37d8e43af8238309f02f74204fe8, 'sessione', '2024-07-01 20:36:47', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef37d8f9bb60588309f02f74204fe8, 'sessione', '2024-07-01 20:37:23', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef37e15f41871c8309f02f74204fe8, 'sessione', '2024-07-01 21:37:29', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef37fb6d55f3438309f02f74204fe8, 'sessione', '2024-07-02 00:43:59', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef380169e268068309f02f74204fe8, 'sessione', '2024-07-02 01:26:51', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3801af0ad63f8309f02f74204fe8, 'scheda', '2024-07-02 01:28:47', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef374468f510a58309f02f74204fe8#repl=11ef3801af0a10488309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Ciao', NULL, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Ciao-11ef374468f510a58309f02f74204fe8-11ef3801af0a10488309f02f74204fe8'),
(0x11ef3801b15c3a248309f02f74204fe8, 'scheda', '2024-07-02 01:28:51', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef374468f510a58309f02f74204fe8#repl=11ef3801b15c19f58309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Ciao', NULL, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Ciao-11ef374468f510a58309f02f74204fe8-11ef3801b15c19f58309f02f74204fe8'),
(0x11ef3801b550fbe08309f02f74204fe8, 'scheda', '2024-07-02 01:28:57', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef374468f510a58309f02f74204fe8#repl=11ef3801b54fc16a8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Ciao', NULL, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Ciao-11ef374468f510a58309f02f74204fe8-11ef3801b54fc16a8309f02f74204fe8'),
(0x11ef3801b95714998309f02f74204fe8, 'scheda', '2024-07-02 01:29:04', 'goshin26@icloud.com', 'Risposta Commento', 'board.html?proj=14&post=11ef374468f510a58309f02f74204fe8#repl=11ef3801b956bf7f8309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Ciao', NULL, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Ciao-11ef374468f510a58309f02f74204fe8-11ef3801b956bf7f8309f02f74204fe8'),
(0x11ef3807ff1bbd888309f02f74204fe8, 'scheda', '2024-07-02 02:13:58', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=14&post=11ef34eb93b6eb178309f02f74204fe8#repl=11ef3807ff18e2948309f02f74204fe8', 'goshin26@icloud.com', NULL, 14, 'Eliminate', 0x11ef34eb93b6eb178309f02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-SAD-14-Eliminate-11ef34eb93b6eb178309f02f74204fe8-11ef3807ff18e2948309f02f74204fe8'),
(0x11ef38cf87ffe7488309f02f74204fe8, 'sessione', '2024-07-03 02:02:15', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef38cfb3a2296a8309f02f74204fe8, 'sessione', '2024-07-03 02:03:28', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3a3f491d01168309f02f74204fe8, 'sessione', '2024-07-04 21:54:42', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3a3f7b2d557e8309f02f74204fe8, 'scheda', '2024-07-04 21:56:06', 'goshin26@icloud.com', 'Modifica Commento', 'board.html?proj=14&post=11ef374468f510a58309f02f74204fe8#repl=11ef37a1aa5728238309f02f74204fe8', 'admin@procol.com', NULL, 14, 'Ciao', NULL, 'goshin26@icloud.com', 'admin@procol.com-SAD-14-Ciao-11ef374468f510a58309f02f74204fe8-11ef37a1aa5728238309f02f74204fe8'),
(0x11ef3af049893ddd8309f02f74204fe8, 'sessione', '2024-07-05 19:01:42', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3af2451903558309f02f74204fe8, 'sessione', '2024-07-05 19:15:54', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3af468dfb9ac8309f02f74204fe8, 'sessione', '2024-07-05 19:31:13', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef3af47c4a54d88309f02f74204fe8, 'progetto', '2024-07-05 19:31:46', 'admin@procol.com', 'Creazione Progetto', 'board.html?proj=74', NULL, NULL, 74, NULL, NULL, 'admin@procol.com', 'No Utente-No Team-74'),
(0x11ef3af483f12fc48309f02f74204fe8, 'utente', '2024-07-05 19:31:58', 'admin@procol.com', 'Promozione Utente', NULL, 'imma.capuano@procol.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'imma.capuano@procol.com'),
(0x11ef3af48ebc9dda8309f02f74204fe8, 'team', '2024-07-05 19:32:17', 'admin@procol.com', 'Creazione Team', NULL, 'imma.capuano@procol.com', 'GFS', NULL, NULL, NULL, 'admin@procol.com', 'imma.capuano@procol.com-GFS'),
(0x11ef3af49b9264ef8309f02f74204fe8, 'sessione', '2024-07-05 19:32:38', 'Imma.capuano@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'Imma.capuano@procol.com', NULL),
(0x11ef3af4a9e88a668309f02f74204fe8, 'sessione', '2024-07-05 19:33:02', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef3af4ae2cdbae8309f02f74204fe8, 'progetto', '2024-07-05 19:33:09', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=74', NULL, 'GFS', 74, NULL, NULL, 'admin@procol.com', 'No Utente-GFS-74'),
(0x11ef3af4c7575ba68309f02f74204fe8, 'sessione', '2024-07-05 19:33:51', 'Imma.capuano@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'Imma.capuano@procol.com', NULL),
(0x11ef3af4d31fd2be8309f02f74204fe8, 'scheda', '2024-07-05 19:34:11', 'imma.capuano@procol.com', 'Creazione Scheda', 'board.html?proj=74&post=11ef3af4d31f30bc8309f02f74204fe8', NULL, 'GFS', 74, 'In Corso', 0x11ef3af4d31f30bc8309f02f74204fe8, 'imma.capuano@procol.com', 'No Utente-GFS-74-In Corso-11ef3af4d31f30bc8309f02f74204fe8'),
(0x11ef3af50fe3213a8309f02f74204fe8, 'scheda', '2024-07-05 19:35:53', 'imma.capuano@procol.com', 'Aggiunta Descrizione Scheda', 'board.html?proj=74&post=11ef3af4d31f30bc8309f02f74204fe8', 'imma.capuano@procol.com', 'GFS', 74, 'In Corso', 0x11ef3af4d31f30bc8309f02f74204fe8, 'imma.capuano@procol.com', 'imma.capuano@procol.com-GFS-74-In Corso-11ef3af4d31f30bc8309f02f74204fe8'),
(0x11ef3af552939dfd8309f02f74204fe8, 'scheda', '2024-07-05 19:37:45', 'imma.capuano@procol.com', 'Creazione Commento', 'board.html?proj=74&post=11ef3af4d31f30bc8309f02f74204fe8#repl=11ef3af552925f818309f02f74204fe8', 'imma.capuano@procol.com', 'GFS', 74, 'In Corso', 0x11ef3af4d31f30bc8309f02f74204fe8, 'imma.capuano@procol.com', 'imma.capuano@procol.com-GFS-74-In Corso-11ef3af4d31f30bc8309f02f74204fe8-11ef3af552925f818309f02f74204fe8'),
(0x11ef3af561af2a398309f02f74204fe8, 'scheda', '2024-07-05 19:38:10', 'imma.capuano@procol.com', 'Eliminazione Commento', 'board.html?proj=74&post=11ef3af4d31f30bc8309f02f74204fe8', 'imma.capuano@procol.com', 'GFS', 74, 'In Corso', 0x11ef3af4d31f30bc8309f02f74204fe8, 'imma.capuano@procol.com', 'imma.capuano@procol.com-GFS-74-In Corso-11ef3af4d31f30bc8309f02f74204fe8-11ef3af552925f818309f02f74204fe8'),
(0x11ef3af5a8ddb9998309f02f74204fe8, 'scheda', '2024-07-05 19:40:10', 'imma.capuano@procol.com', 'Creazione Scheda', 'board.html?proj=74&post=11ef3af5a8dd44558309f02f74204fe8', NULL, 'GFS', 74, 'In Attesa', NULL, 'imma.capuano@procol.com', 'No Utente-GFS-74-In Attesa-11ef3af5a8dd44558309f02f74204fe8'),
(0x11ef3af5ad39b7298309f02f74204fe8, 'scheda', '2024-07-05 19:40:17', 'imma.capuano@procol.com', 'Aggiunta Descrizione Scheda', 'board.html?proj=74&post=11ef3af5a8dd44558309f02f74204fe8', 'imma.capuano@procol.com', 'GFS', 74, 'In Attesa', NULL, 'imma.capuano@procol.com', 'imma.capuano@procol.com-GFS-74-In Attesa-11ef3af5a8dd44558309f02f74204fe8'),
(0x11ef3af5b1ef54048309f02f74204fe8, 'scheda', '2024-07-05 19:40:25', 'imma.capuano@procol.com', 'Archiviazione Scheda', 'board.html?proj=74&post=11ef3af5a8dd44558309f02f74204fe8', 'imma.capuano@procol.com', 'GFS', 74, 'In Attesa', NULL, 'imma.capuano@procol.com', '74-In Attesa-11ef3af5a8dd44558309f02f74204fe8'),
(0x11ef3af63bfcf9b58309f02f74204fe8, 'scheda', '2024-07-05 19:44:17', 'imma.capuano@procol.com', 'Creazione Commento', 'board.html?proj=74&post=11ef3af4d31f30bc8309f02f74204fe8#repl=11ef3af63bfc28af8309f02f74204fe8', 'imma.capuano@procol.com', 'GFS', 74, 'In Corso', 0x11ef3af4d31f30bc8309f02f74204fe8, 'imma.capuano@procol.com', 'imma.capuano@procol.com-GFS-74-In Corso-11ef3af4d31f30bc8309f02f74204fe8-11ef3af63bfc28af8309f02f74204fe8'),
(0x11ef3af6458e983f8309f02f74204fe8, 'scheda', '2024-07-05 19:44:33', 'imma.capuano@procol.com', 'Creazione Commento', 'board.html?proj=74&post=11ef3af4d31f30bc8309f02f74204fe8#repl=11ef3af6458e69528309f02f74204fe8', 'imma.capuano@procol.com', 'GFS', 74, 'In Corso', 0x11ef3af4d31f30bc8309f02f74204fe8, 'imma.capuano@procol.com', 'imma.capuano@procol.com-GFS-74-In Corso-11ef3af4d31f30bc8309f02f74204fe8-11ef3af6458e69528309f02f74204fe8'),
(0x11ef3af6651e42a18309f02f74204fe8, 'scheda', '2024-07-05 19:45:26', 'imma.capuano@procol.com', 'Eliminazione Commento', 'board.html?proj=74&post=11ef3af4d31f30bc8309f02f74204fe8', 'imma.capuano@procol.com', 'GFS', 74, 'In Corso', 0x11ef3af4d31f30bc8309f02f74204fe8, 'imma.capuano@procol.com', 'imma.capuano@procol.com-GFS-74-In Corso-11ef3af4d31f30bc8309f02f74204fe8-11ef3af6458e69528309f02f74204fe8'),
(0x11ef3af66660172c8309f02f74204fe8, 'scheda', '2024-07-05 19:45:28', 'imma.capuano@procol.com', 'Eliminazione Commento', 'board.html?proj=74&post=11ef3af4d31f30bc8309f02f74204fe8', 'imma.capuano@procol.com', 'GFS', 74, 'In Corso', 0x11ef3af4d31f30bc8309f02f74204fe8, 'imma.capuano@procol.com', 'imma.capuano@procol.com-GFS-74-In Corso-11ef3af4d31f30bc8309f02f74204fe8-11ef3af63bfc28af8309f02f74204fe8'),
(0x11ef3af67261a8f28309f02f74204fe8, 'scheda', '2024-07-05 19:45:48', 'imma.capuano@procol.com', 'Creazione Commento', 'board.html?proj=74&post=11ef3af4d31f30bc8309f02f74204fe8#repl=11ef3af672617a5c8309f02f74204fe8', 'imma.capuano@procol.com', 'GFS', 74, 'In Corso', 0x11ef3af4d31f30bc8309f02f74204fe8, 'imma.capuano@procol.com', 'imma.capuano@procol.com-GFS-74-In Corso-11ef3af4d31f30bc8309f02f74204fe8-11ef3af672617a5c8309f02f74204fe8'),
(0x11ef3af6752d73fb8309f02f74204fe8, 'scheda', '2024-07-05 19:45:53', 'imma.capuano@procol.com', 'Risposta Commento', 'board.html?proj=74&post=11ef3af4d31f30bc8309f02f74204fe8#repl=11ef3af6752c00508309f02f74204fe8', 'imma.capuano@procol.com', 'GFS', 74, 'In Corso', 0x11ef3af4d31f30bc8309f02f74204fe8, 'imma.capuano@procol.com', 'imma.capuano@procol.com-GFS-74-In Corso-11ef3af4d31f30bc8309f02f74204fe8-11ef3af6752c00508309f02f74204fe8'),
(0x11ef3af6778e3d218309f02f74204fe8, 'scheda', '2024-07-05 19:45:57', 'imma.capuano@procol.com', 'Eliminazione Commento', 'board.html?proj=74&post=11ef3af4d31f30bc8309f02f74204fe8', 'imma.capuano@procol.com', 'GFS', 74, 'In Corso', 0x11ef3af4d31f30bc8309f02f74204fe8, 'imma.capuano@procol.com', 'imma.capuano@procol.com-GFS-74-In Corso-11ef3af4d31f30bc8309f02f74204fe8-11ef3af672617a5c8309f02f74204fe8'),
(0x11ef3af6cd7d9a4e8309f02f74204fe8, 'scheda', '2024-07-05 19:48:21', 'imma.capuano@procol.com', 'Risposta Commento', 'board.html?proj=74&post=11ef3af4d31f30bc8309f02f74204fe8#repl=11ef3af6cd7c6f8d8309f02f74204fe8', 'imma.capuano@procol.com', 'GFS', 74, 'In Corso', 0x11ef3af4d31f30bc8309f02f74204fe8, 'imma.capuano@procol.com', 'imma.capuano@procol.com-GFS-74-In Corso-11ef3af4d31f30bc8309f02f74204fe8-11ef3af6cd7c6f8d8309f02f74204fe8'),
(0x11ef3af7ed694f898309f02f74204fe8, 'scheda', '2024-07-05 19:56:24', 'imma.capuano@procol.com', 'Modifica Descrizione Scheda', 'board.html?proj=74&post=11ef3af4d31f30bc8309f02f74204fe8', 'imma.capuano@procol.com', 'GFS', 74, 'In Corso', 0x11ef3af4d31f30bc8309f02f74204fe8, 'imma.capuano@procol.com', 'imma.capuano@procol.com-GFS-74-In Corso-11ef3af4d31f30bc8309f02f74204fe8'),
(0x11ef3af7f5dddca38309f02f74204fe8, 'scheda', '2024-07-05 19:56:38', 'imma.capuano@procol.com', 'Eliminazione Commento', 'board.html?proj=74&post=11ef3af4d31f30bc8309f02f74204fe8', 'imma.capuano@procol.com', 'GFS', 74, 'In Corso', 0x11ef3af4d31f30bc8309f02f74204fe8, 'imma.capuano@procol.com', 'imma.capuano@procol.com-GFS-74-In Corso-11ef3af4d31f30bc8309f02f74204fe8-11ef3af6752c00508309f02f74204fe8'),
(0x11ef3af7f743c36f8309f02f74204fe8, 'scheda', '2024-07-05 19:56:40', 'imma.capuano@procol.com', 'Eliminazione Commento', 'board.html?proj=74&post=11ef3af4d31f30bc8309f02f74204fe8', 'imma.capuano@procol.com', 'GFS', 74, 'In Corso', 0x11ef3af4d31f30bc8309f02f74204fe8, 'imma.capuano@procol.com', 'imma.capuano@procol.com-GFS-74-In Corso-11ef3af4d31f30bc8309f02f74204fe8-11ef3af6cd7c6f8d8309f02f74204fe8'),
(0x11ef3b031953b7ff8309f02f74204fe8, 'sessione', '2024-07-05 21:16:22', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3b0372b392748309f02f74204fe8, 'sessione', '2024-07-05 21:18:52', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3b038147cf918309f02f74204fe8, 'sessione', '2024-07-05 21:19:16', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef3b0398093d358309f02f74204fe8, 'team', '2024-07-05 21:19:55', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'luigi.campi@procol.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'luigi.campi@procol.com-SAD'),
(0x11ef3b039bbdadd28309f02f74204fe8, 'sessione', '2024-07-05 21:20:01', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3b03ad2109708309f02f74204fe8, 'progetto', '2024-07-05 21:20:30', 'goshin26@icloud.com', 'Oscuramento Categoria', 'board.html?proj=14', NULL, NULL, 14, 'In Ritardo', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-In Ritardo'),
(0x11ef3b03af9808db8309f02f74204fe8, 'progetto', '2024-07-05 21:20:34', 'goshin26@icloud.com', 'Visualizzazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'In Ritardo', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-In Ritardo'),
(0x11ef3b03b40684068309f02f74204fe8, 'progetto', '2024-07-05 21:20:42', 'goshin26@icloud.com', 'Oscuramento Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Completate', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Completate'),
(0x11ef3b03b5894b528309f02f74204fe8, 'progetto', '2024-07-05 21:20:44', 'goshin26@icloud.com', 'Visualizzazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Completate', NULL, 'goshin26@icloud.com', 'No Utente-SAD-14-Completate'),
(0x11ef3b05148d3e888309f02f74204fe8, 'sessione', '2024-07-05 21:30:33', 'luigi.campi@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'luigi.campi@procol.com', NULL),
(0x11ef3b05200bb5ba8309f02f74204fe8, 'progetto', '2024-07-05 21:30:52', 'luigi.campi@procol.com', 'Creazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Nuooo', NULL, 'luigi.campi@procol.com', 'No Utente-SAD-14-Nuooo'),
(0x11ef3b05327f8dc88309f02f74204fe8, 'progetto', '2024-07-05 21:31:23', 'luigi.campi@procol.com', 'Creazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Sddasd', NULL, 'luigi.campi@procol.com', 'No Utente-SAD-14-Sddasd'),
(0x11ef3b053e24d5a48309f02f74204fe8, 'scheda', '2024-07-05 21:31:43', 'luigi.campi@procol.com', 'Creazione Scheda', 'board.html?proj=14&post=11ef3b053e2400e58309f02f74204fe8', NULL, NULL, 14, 'Sddasd', NULL, 'luigi.campi@procol.com', 'No Utente-SAD-14-Sddasd-11ef3b053e2400e58309f02f74204fe8'),
(0x11ef3b05415960c48309f02f74204fe8, 'scheda', '2024-07-05 21:31:48', 'luigi.campi@procol.com', 'Creazione Commento', 'board.html?proj=14&post=11ef3b053e2400e58309f02f74204fe8#repl=11ef3b0541593cba8309f02f74204fe8', 'luigi.campi@procol.com', NULL, 14, 'Sddasd', NULL, 'luigi.campi@procol.com', 'luigi.campi@procol.com-SAD-14-Sddasd-11ef3b053e2400e58309f02f74204fe8-11ef3b0541593cba8309f02f74204fe8'),
(0x11ef3b0569c1bab88309f02f74204fe8, 'progetto', '2024-07-05 21:32:56', 'luigi.campi@procol.com', 'Creazione Categoria', 'board.html?proj=14', NULL, NULL, 14, 'Asdsaasdsadsad', NULL, 'luigi.campi@procol.com', 'No Utente-SAD-14-Asdsaasdsadsad'),
(0x11ef3b0595ca618b8309f02f74204fe8, 'scheda', '2024-07-05 21:34:10', 'luigi.campi@procol.com', 'Creazione Commento', 'board.html?proj=14&post=11ef3b053e2400e58309f02f74204fe8#repl=11ef3b0595c9a7e58309f02f74204fe8', 'luigi.campi@procol.com', NULL, 14, 'Sddasd', NULL, 'luigi.campi@procol.com', 'luigi.campi@procol.com-SAD-14-Sddasd-11ef3b053e2400e58309f02f74204fe8-11ef3b0595c9a7e58309f02f74204fe8'),
(0x11ef3b093d7157718309f02f74204fe8, 'sessione', '2024-07-05 22:00:20', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3b09489c79d68309f02f74204fe8, 'scheda', '2024-07-05 22:00:38', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=14&post=11ef374468f510a58309f02f74204fe8', 'luigi.campi@procol.com', NULL, 14, 'Ciao', NULL, 'goshin26@icloud.com', 'luigi.campi@procol.com-SAD-14-Ciao-11ef374468f510a58309f02f74204fe8'),
(0x11ef3b0959a5b8f48309f02f74204fe8, 'sessione', '2024-07-05 22:01:07', 'luigi.campi@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'luigi.campi@procol.com', NULL),
(0x11ef3bcb2db7f7248309f02f74204fe8, 'sessione', '2024-07-06 21:08:33', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3bcb8dac07858309f02f74204fe8, 'sessione', '2024-07-06 21:11:14', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef3d14bc3f98808309f02f74204fe8, 'sessione', '2024-07-08 12:27:35', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef3d17eeca6fb18309f02f74204fe8, 'team', '2024-07-08 12:50:28', 'admin@procol.com', 'Creazione Team', NULL, 'utente.prova1@procol.com', 'MVN', NULL, NULL, NULL, 'admin@procol.com', 'utente.prova1@procol.com-MVN'),
(0x11ef3d17fb83f8c68309f02f74204fe8, 'team', '2024-07-08 12:50:49', 'admin@procol.com', 'Creazione Team', NULL, 'utente.prova2@procol.com', 'CAI', NULL, NULL, NULL, 'admin@procol.com', 'utente.prova2@procol.com-CAI'),
(0x11ef3d1c8fd8d9888309f02f74204fe8, 'sessione', '2024-07-08 13:23:36', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef3d1cba510c188309f02f74204fe8, 'utente', '2024-07-08 13:24:48', 'admin@procol.com', 'Promozione Utente', NULL, 'marco.rossi@procol.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'marco.rossi@procol.com'),
(0x11ef3d1cba52192e8309f02f74204fe8, 'team', '2024-07-08 13:24:48', 'admin@procol.com', 'Creazione Team', NULL, 'marco.rossi@procol.com', 'LUF', NULL, NULL, NULL, 'admin@procol.com', 'marco.rossi@procol.com-LUF'),
(0x11ef3d1cda4055c48309f02f74204fe8, 'utente', '2024-07-08 13:25:41', 'admin@procol.com', 'Promozione Utente', NULL, 'luca.bianchi@procol.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'luca.bianchi@procol.com'),
(0x11ef3d1cda40652d8309f02f74204fe8, 'team', '2024-07-08 13:25:41', 'admin@procol.com', 'Creazione Team', NULL, 'luca.bianchi@procol.com', 'SLX', NULL, NULL, NULL, 'admin@procol.com', 'luca.bianchi@procol.com-SLX'),
(0x11ef3d1cee9417e48309f02f74204fe8, 'utente', '2024-07-08 13:26:15', 'admin@procol.com', 'Promozione Utente', NULL, 'giulia.verdi@procol.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'giulia.verdi@procol.com'),
(0x11ef3d1cee94d1f78309f02f74204fe8, 'team', '2024-07-08 13:26:15', 'admin@procol.com', 'Creazione Team', NULL, 'giulia.verdi@procol.com', 'QWO', NULL, NULL, NULL, 'admin@procol.com', 'giulia.verdi@procol.com-QWO'),
(0x11ef3d1d098715d48309f02f74204fe8, 'utente', '2024-07-08 13:27:00', 'admin@procol.com', 'Promozione Utente', NULL, 'francesca.neri@procol.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'francesca.neri@procol.com'),
(0x11ef3d1d098733ac8309f02f74204fe8, 'team', '2024-07-08 13:27:00', 'admin@procol.com', 'Creazione Team', NULL, 'francesca.neri@procol.com', 'CRH', NULL, NULL, NULL, 'admin@procol.com', 'francesca.neri@procol.com-CRH');
INSERT INTO `report` (`uuid_report`, `tipo_azione`, `timestamp`, `attore`, `descrizione`, `link`, `utente`, `team`, `progetto`, `categoria`, `scheda`, `attore_era`, `bersaglio_era`) VALUES
(0x11ef3d1d27c1add98309f02f74204fe8, 'utente', '2024-07-08 13:27:51', 'admin@procol.com', 'Promozione Utente', NULL, 'andre.conti@procol.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'andre.conti@procol.com'),
(0x11ef3d1d27c1bd458309f02f74204fe8, 'team', '2024-07-08 13:27:51', 'admin@procol.com', 'Creazione Team', NULL, 'andre.conti@procol.com', 'GPH', NULL, NULL, NULL, 'admin@procol.com', 'andre.conti@procol.com-GPH'),
(0x11ef3d1d37718dde8309f02f74204fe8, 'utente', '2024-07-08 13:28:18', 'admin@procol.com', 'Promozione Utente', NULL, 'valentina.esposito@procol.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'valentina.esposito@procol.com'),
(0x11ef3d1d377217ce8309f02f74204fe8, 'team', '2024-07-08 13:28:18', 'admin@procol.com', 'Creazione Team', NULL, 'valentina.esposito@procol.com', 'MYT', NULL, NULL, NULL, 'admin@procol.com', 'valentina.esposito@procol.com-MYT'),
(0x11ef3d1d48c6f9d18309f02f74204fe8, 'utente', '2024-07-08 13:28:47', 'admin@procol.com', 'Promozione Utente', NULL, 'federico.greco@procol.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'federico.greco@procol.com'),
(0x11ef3d1d48c70a918309f02f74204fe8, 'team', '2024-07-08 13:28:47', 'admin@procol.com', 'Creazione Team', NULL, 'federico.greco@procol.com', 'ETE', NULL, NULL, NULL, 'admin@procol.com', 'federico.greco@procol.com-ETE'),
(0x11ef3d1d69dc80418309f02f74204fe8, 'utente', '2024-07-08 13:29:42', 'admin@procol.com', 'Promozione Utente', NULL, 'stefano.romano@procol.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'stefano.romano@procol.com'),
(0x11ef3d1d69dca3458309f02f74204fe8, 'team', '2024-07-08 13:29:42', 'admin@procol.com', 'Creazione Team', NULL, 'stefano.romano@procol.com', 'NBD', NULL, NULL, NULL, 'admin@procol.com', 'stefano.romano@procol.com-NBD'),
(0x11ef3d1de6c5a93a8309f02f74204fe8, 'team', '2024-07-08 13:33:12', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'sara.moretti@procol.com', 'LUF', NULL, NULL, NULL, 'admin@procol.com', 'sara.moretti@procol.com-LUF'),
(0x11ef3d1dfe9a64b58309f02f74204fe8, 'team', '2024-07-08 13:33:52', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'davide.gallo@procol.com', 'LUF', NULL, NULL, NULL, 'admin@procol.com', 'davide.gallo@procol.com-LUF'),
(0x11ef3d1dfe9a79428309f02f74204fe8, 'team', '2024-07-08 13:33:52', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'beatrice.ruggieri@procol.com', 'LUF', NULL, NULL, NULL, 'admin@procol.com', 'beatrice.ruggieri@procol.com-LUF'),
(0x11ef3d1e26560e088309f02f74204fe8, 'team', '2024-07-08 13:34:58', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'elena.ferri@procol.com', 'SLX', NULL, NULL, NULL, 'admin@procol.com', 'elena.ferri@procol.com-SLX'),
(0x11ef3d1e3960718f8309f02f74204fe8, 'team', '2024-07-08 13:35:30', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'anna.parisi@procol.com', 'SLX', NULL, NULL, NULL, 'admin@procol.com', 'anna.parisi@procol.com-SLX'),
(0x11ef3d1ebf217a8d8309f02f74204fe8, 'team', '2024-07-08 13:39:15', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'alberto.deluca@procol.com', 'QWO', NULL, NULL, NULL, 'admin@procol.com', 'alberto.deluca@procol.com-QWO'),
(0x11ef3d1ece11e1928309f02f74204fe8, 'team', '2024-07-08 13:39:40', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'enrico.costantini@procol.com', 'QWO', NULL, NULL, NULL, 'admin@procol.com', 'enrico.costantini@procol.com-QWO'),
(0x11ef3d1ece126a638309f02f74204fe8, 'team', '2024-07-08 13:39:40', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'tommaso.valli@procol.com', 'QWO', NULL, NULL, NULL, 'admin@procol.com', 'tommaso.valli@procol.com-QWO'),
(0x11ef3d1edc46e85d8309f02f74204fe8, 'team', '2024-07-08 13:40:04', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'carlo.barbieri@procol.com', 'CRH', NULL, NULL, NULL, 'admin@procol.com', 'carlo.barbieri@procol.com-CRH'),
(0x11ef3d1ee6c1baf28309f02f74204fe8, 'team', '2024-07-08 13:40:21', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'simone.lombardi@procol.com', 'CRH', NULL, NULL, NULL, 'admin@procol.com', 'simone.lombardi@procol.com-CRH'),
(0x11ef3d1f0fc23b898309f02f74204fe8, 'team', '2024-07-08 13:41:30', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'martina.sanna@procol.com', 'GPH', NULL, NULL, NULL, 'admin@procol.com', 'martina.sanna@procol.com-GPH'),
(0x11ef3d1f0fc24be88309f02f74204fe8, 'team', '2024-07-08 13:41:30', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'roberta.fabbri@procol.com', 'GPH', NULL, NULL, NULL, 'admin@procol.com', 'roberta.fabbri@procol.com-GPH'),
(0x11ef3d1f2c6ed6288309f02f74204fe8, 'team', '2024-07-08 13:42:18', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'giorgio.amato@procol.com', 'MYT', NULL, NULL, NULL, 'admin@procol.com', 'giorgio.amato@procol.com-MYT'),
(0x11ef3d1f34cbe41e8309f02f74204fe8, 'team', '2024-07-08 13:42:32', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'matteo.ricci@procol.com', 'MYT', NULL, NULL, NULL, 'admin@procol.com', 'matteo.ricci@procol.com-MYT'),
(0x11ef3d1f44ac0df98309f02f74204fe8, 'team', '2024-07-08 13:42:59', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'chiara.pellegrini@procol.com', 'ETE', NULL, NULL, NULL, 'admin@procol.com', 'chiara.pellegrini@procol.com-ETE'),
(0x11ef3d1f44ac20878309f02f74204fe8, 'team', '2024-07-08 13:42:59', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'laura.gatti@procol.com', 'ETE', NULL, NULL, NULL, 'admin@procol.com', 'laura.gatti@procol.com-ETE'),
(0x11ef3d1f5895f50d8309f02f74204fe8, 'team', '2024-07-08 13:43:32', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'alessia.marino@procol.com', 'NBD', NULL, NULL, NULL, 'admin@procol.com', 'alessia.marino@procol.com-NBD'),
(0x11ef3d1f9568a50e8309f02f74204fe8, 'team', '2024-07-08 13:45:14', 'admin@procol.com', 'Rimozione Utente Da Team', NULL, 'luigi.campi@procol.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'luigi.campi@procol.com-SAD'),
(0x11ef3d1f9568aaa78309f02f74204fe8, 'team', '2024-07-08 13:45:14', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'luigi.campi@procol.com', 'GFS', NULL, NULL, NULL, 'admin@procol.com', 'luigi.campi@procol.com-GFS'),
(0x11ef3d1f9568be3f8309f02f74204fe8, 'team', '2024-07-08 13:45:14', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'martina.venturini@procol.com', 'GFS', NULL, NULL, NULL, 'admin@procol.com', 'martina.venturini@procol.com-GFS'),
(0x11ef3d1f9568d4b68309f02f74204fe8, 'team', '2024-07-08 13:45:14', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'giandomenico.riccardo@procol.com', 'GFS', NULL, NULL, NULL, 'admin@procol.com', 'giandomenico.riccardo@procol.com-GFS'),
(0x11ef3d1fe4df65b38309f02f74204fe8, 'progetto', '2024-07-08 13:47:27', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=49', NULL, 'LUF', 49, NULL, NULL, 'admin@procol.com', 'No Utente-LUF-49'),
(0x11ef3d201ef235c58309f02f74204fe8, 'progetto', '2024-07-08 13:49:05', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=35', NULL, 'LUF', 35, NULL, NULL, 'admin@procol.com', 'No Utente-LUF-35'),
(0x11ef3d2034691e648309f02f74204fe8, 'progetto', '2024-07-08 13:49:41', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=27', NULL, NULL, 27, NULL, NULL, 'admin@procol.com', 'No Utente-No Team-27'),
(0x11ef3d2070333fa08309f02f74204fe8, 'progetto', '2024-07-08 13:51:21', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=46', NULL, 'CRH', 46, NULL, NULL, 'admin@procol.com', 'No Utente-CRH-46'),
(0x11ef3d207a93fc108309f02f74204fe8, 'progetto', '2024-07-08 13:51:39', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=42', NULL, 'CRH', 42, NULL, NULL, 'admin@procol.com', 'No Utente-CRH-42'),
(0x11ef3d208bfe51d68309f02f74204fe8, 'progetto', '2024-07-08 13:52:08', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=52', NULL, 'GPH', 52, NULL, NULL, 'admin@procol.com', 'No Utente-GPH-52'),
(0x11ef3d2096fed1648309f02f74204fe8, 'progetto', '2024-07-08 13:52:26', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=50', NULL, 'ETE', 50, NULL, NULL, 'admin@procol.com', 'No Utente-ETE-50'),
(0x11ef3d20a62f799c8309f02f74204fe8, 'progetto', '2024-07-08 13:52:52', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=41', NULL, 'NBD', 41, NULL, NULL, 'admin@procol.com', 'No Utente-NBD-41'),
(0x11ef3d20b2caf59e8309f02f74204fe8, 'progetto', '2024-07-08 13:53:13', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=57', NULL, 'CAI', 57, NULL, NULL, 'admin@procol.com', 'No Utente-CAI-57'),
(0x11ef3d20be44c4808309f02f74204fe8, 'progetto', '2024-07-08 13:53:32', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=47', NULL, 'ETE', 47, NULL, NULL, 'admin@procol.com', 'No Utente-ETE-47'),
(0x11ef3d20c853d0708309f02f74204fe8, 'progetto', '2024-07-08 13:53:49', 'admin@procol.com', '', 'board.html?proj=24', NULL, NULL, 24, NULL, NULL, 'admin@procol.com', 'No Utente-SAD-24'),
(0x11ef3d20dd4b0dc98309f02f74204fe8, 'progetto', '2024-07-08 13:54:24', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=14', NULL, NULL, 14, NULL, NULL, 'admin@procol.com', 'No Utente-No Team-14'),
(0x11ef3d20e5ddb3c98309f02f74204fe8, 'progetto', '2024-07-08 13:54:39', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=61', NULL, 'MVN', 61, NULL, NULL, 'admin@procol.com', 'No Utente-MVN-61'),
(0x11ef3d20ec58dff88309f02f74204fe8, 'team', '2024-07-08 13:54:50', 'admin@procol.com', 'Eliminazione Team', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'No Utente-MRS'),
(0x11ef3d20f08560378309f02f74204fe8, 'team', '2024-07-08 13:54:57', 'admin@procol.com', 'Eliminazione Team', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'No Utente-SAD'),
(0x11ef3d216345e4bf8309f02f74204fe8, 'team', '2024-07-08 13:58:09', 'admin@procol.com', 'Aggiornamento Team', NULL, 'imma.capuano@procol.com', 'GFS', NULL, NULL, NULL, 'admin@procol.com', 'imma.capuano@procol.com-GFS'),
(0x11ef3d23abbed0148309f02f74204fe8, 'sessione', '2024-07-08 14:14:30', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef3d24042d81d88309f02f74204fe8, 'sessione', '2024-07-08 14:16:58', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3d2429ed93908309f02f74204fe8, 'sessione', '2024-07-08 14:18:01', 'luigi.puca@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'luigi.puca@procol.com', NULL),
(0x11ef3d2444caec058309f02f74204fe8, 'team', '2024-07-08 14:18:46', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'goshin26@icloud.com', 'PCU', NULL, NULL, NULL, 'admin@procol.com', 'goshin26@icloud.com-PCU'),
(0x11ef3d2455933b4c8309f02f74204fe8, 'sessione', '2024-07-08 14:19:15', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3d246fe8ea7e8309f02f74204fe8, 'scheda', '2024-07-08 14:19:59', 'goshin26@icloud.com', 'Aggiunta Descrizione Scheda', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8'),
(0x11ef3d247a2bb0db8309f02f74204fe8, 'scheda', '2024-07-08 14:20:16', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8#repl=11ef3d247a2b83728309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8-11ef3d247a2b83728309f02f74204fe8'),
(0x11ef3d247e1c216b8309f02f74204fe8, 'scheda', '2024-07-08 14:20:23', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8#repl=11ef3d247e1b6db68309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8-11ef3d247e1b6db68309f02f74204fe8'),
(0x11ef3d24841198228309f02f74204fe8, 'scheda', '2024-07-08 14:20:33', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8#repl=11ef3d248410cc0d8309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8-11ef3d248410cc0d8309f02f74204fe8'),
(0x11ef3d24874f9ba68309f02f74204fe8, 'scheda', '2024-07-08 14:20:38', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8#repl=11ef3d24874f848c8309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8-11ef3d24874f848c8309f02f74204fe8'),
(0x11ef3d248ca3ea458309f02f74204fe8, 'scheda', '2024-07-08 14:20:47', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8#repl=11ef3d248ca3d0a28309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8-11ef3d248ca3d0a28309f02f74204fe8'),
(0x11ef3d249575d53b8309f02f74204fe8, 'scheda', '2024-07-08 14:21:02', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8#repl=11ef3d249575b92b8309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8-11ef3d249575b92b8309f02f74204fe8'),
(0x11ef3d249be9d87f8309f02f74204fe8, 'scheda', '2024-07-08 14:21:13', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8#repl=11ef3d249be921ab8309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8-11ef3d249be921ab8309f02f74204fe8'),
(0x11ef3d24a0e091bf8309f02f74204fe8, 'scheda', '2024-07-08 14:21:21', 'goshin26@icloud.com', 'Assegnazione Scheda', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8'),
(0x11ef3d24a86182838309f02f74204fe8, 'scheda', '2024-07-08 14:21:33', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8#repl=11ef3d24a86166128309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8-11ef3d24a86166128309f02f74204fe8'),
(0x11ef3d24ab8d03008309f02f74204fe8, 'scheda', '2024-07-08 14:21:39', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8#repl=11ef3d24ab8c6eb88309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8-11ef3d24ab8c6eb88309f02f74204fe8'),
(0x11ef3d24af4557cf8309f02f74204fe8, 'scheda', '2024-07-08 14:21:45', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8#repl=11ef3d24af4541f58309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8-11ef3d24af4541f58309f02f74204fe8'),
(0x11ef3d24b25414dc8309f02f74204fe8, 'scheda', '2024-07-08 14:21:50', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8#repl=11ef3d24b25377498309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8-11ef3d24b25377498309f02f74204fe8'),
(0x11ef3d24b57d50968309f02f74204fe8, 'scheda', '2024-07-08 14:21:55', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8#repl=11ef3d24b57d37588309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8-11ef3d24b57d37588309f02f74204fe8'),
(0x11ef3d24bafc04638309f02f74204fe8, 'scheda', '2024-07-08 14:22:05', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8#repl=11ef3d24bafb58e58309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8-11ef3d24bafb58e58309f02f74204fe8'),
(0x11ef3d24bda1bac98309f02f74204fe8, 'scheda', '2024-07-08 14:22:09', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8#repl=11ef3d24bda1a4bf8309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8-11ef3d24bda1a4bf8309f02f74204fe8'),
(0x11ef3d24c043a1aa8309f02f74204fe8, 'scheda', '2024-07-08 14:22:14', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8#repl=11ef3d24c0437abb8309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8-11ef3d24c0437abb8309f02f74204fe8'),
(0x11ef3d24c44732298309f02f74204fe8, 'scheda', '2024-07-08 14:22:20', 'goshin26@icloud.com', 'Creazione Commento', 'board.html?proj=15&post=11ef0bebc48c857e813af02f74204fe8#repl=11ef3d24c447068f8309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Completate', 0x11ef0bebc48c857e813af02f74204fe8, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Completate-11ef0bebc48c857e813af02f74204fe8-11ef3d24c447068f8309f02f74204fe8'),
(0x11ef3d2761fbe23b8309f02f74204fe8, 'sessione', '2024-07-08 14:41:04', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3d51833d11e98309f02f74204fe8, 'sessione', '2024-07-08 19:42:39', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef3d53d9deb3ef8309f02f74204fe8, 'utente', '2024-07-08 19:59:23', 'admin@procol.com', 'Eliminazione Utente', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'admin2@procol.com'),
(0x11ef3d53e63cf00d8309f02f74204fe8, 'utente', '2024-07-08 19:59:44', 'admin@procol.com', 'Declassamento Utente', NULL, 'goshin26@icloud.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'goshin26@icloud.com'),
(0x11ef3d5482c1f9268309f02f74204fe8, 'utente', '2024-07-08 20:04:06', 'admin@procol.com', 'Promozione Utente', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'antimo.puca@procol.com'),
(0x11ef3d5484fe3b8a8309f02f74204fe8, 'utente', '2024-07-08 20:04:10', 'admin@procol.com', 'Declassamento Utente', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'antimo.puca@procol.com'),
(0x11ef3d5a26431f598309f02f74204fe8, 'progetto', '2024-07-08 20:44:28', 'admin@procol.com', 'Assegnazione Progetto', 'board.html?proj=60', NULL, NULL, 60, NULL, NULL, 'admin@procol.com', 'No Utente-No Team-60'),
(0x11ef3d5e666087968309f02f74204fe8, 'utente', '2024-07-08 21:14:54', 'admin@procol.com', 'Promozione Utente', NULL, 'goshin26@icloud.com', NULL, NULL, NULL, NULL, 'admin@procol.com', 'goshin26@icloud.com'),
(0x11ef3d7b01d9bdb68309f02f74204fe8, 'sessione', '2024-07-09 00:39:40', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef3dfc3dfef54f8309f02f74204fe8, 'sessione', '2024-07-09 16:04:44', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef3e00ab7a4a358309f02f74204fe8, 'sessione', '2024-07-09 16:36:26', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3e02157d0fdf8309f02f74204fe8, 'sessione', '2024-07-09 16:46:33', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3e0e0f9b08b38309f02f74204fe8, 'sessione', '2024-07-09 18:12:17', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3e10b04e81a28309f02f74204fe8, 'scheda', '2024-07-09 18:31:06', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=15&post=11ef0bee9fdbf109813af02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'In Ritardo', 0x11ef0bee9fdbf109813af02f74204fe8, 'goshin26@icloud.com', '15-In Ritardo-11ef0bee9fdbf109813af02f74204fe8'),
(0x11ef3e19b36ebf728309f02f74204fe8, 'sessione', '2024-07-09 19:35:37', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3e1be66626bd8309f02f74204fe8, 'sessione', '2024-07-09 19:51:21', 'stefano.romano@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'stefano.romano@procol.com', NULL),
(0x11ef3e1c143771548309f02f74204fe8, 'sessione', '2024-07-09 19:52:38', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef3e1c4551558c8309f02f74204fe8, 'sessione', '2024-07-09 19:54:00', 'francesca.neri@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'francesca.neri@procol.com', NULL),
(0x11ef3e1c8e1013b68309f02f74204fe8, 'sessione', '2024-07-09 19:56:02', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef3e1cb81e843f8309f02f74204fe8, 'progetto', '2024-07-09 19:57:13', 'admin@procol.com', 'Aggiornamento Progetto', 'board.html?proj=46', NULL, 'CRH', 46, NULL, NULL, 'admin@procol.com', 'No Utente-CRH-46'),
(0x11ef3e1ef19ef13c8309f02f74204fe8, 'sessione', '2024-07-09 20:13:08', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3e1f452b53168309f02f74204fe8, 'sessione', '2024-07-09 20:15:29', 'francesca.neri@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'francesca.neri@procol.com', NULL),
(0x11ef3e1f539b13ab8309f02f74204fe8, 'sessione', '2024-07-09 20:15:53', 'simone.lombardi@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'simone.lombardi@procol.com', NULL),
(0x11ef3e1f5df2b0ca8309f02f74204fe8, 'sessione', '2024-07-09 20:16:10', 'carlo.barbieri@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'carlo.barbieri@procol.com', NULL),
(0x11ef3e1fad8d08528309f02f74204fe8, 'scheda', '2024-07-09 20:18:24', 'francesca.neri@procol.com', 'Creazione Scheda', 'board.html?proj=46&post=11ef3e1fad8c5db68309f02f74204fe8', NULL, 'CRH', 46, 'In Corso', 0x11ef3e1fad8c5db68309f02f74204fe8, 'francesca.neri@procol.com', 'No Utente-CRH-46-In Corso-11ef3e1fad8c5db68309f02f74204fe8'),
(0x11ef3e1fb7cf43af8309f02f74204fe8, 'scheda', '2024-07-09 20:18:41', 'francesca.neri@procol.com', 'Creazione Scheda', 'board.html?proj=46&post=11ef3e1fb7cf32328309f02f74204fe8', NULL, 'CRH', 46, 'In Corso', 0x11ef3e1fb7cf32328309f02f74204fe8, 'francesca.neri@procol.com', 'No Utente-CRH-46-In Corso-11ef3e1fb7cf32328309f02f74204fe8'),
(0x11ef3e1fc09ac9668309f02f74204fe8, 'scheda', '2024-07-09 20:18:56', 'francesca.neri@procol.com', 'Assegnazione Scheda', 'board.html?proj=46&post=11ef3e1fad8c5db68309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e1fad8c5db68309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e1fad8c5db68309f02f74204fe8'),
(0x11ef3e1fd0c5875f8309f02f74204fe8, 'scheda', '2024-07-09 20:19:23', 'francesca.neri@procol.com', 'Aggiunta Descrizione Scheda', 'board.html?proj=46&post=11ef3e1fad8c5db68309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e1fad8c5db68309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e1fad8c5db68309f02f74204fe8'),
(0x11ef3e1fd81f72cc8309f02f74204fe8, 'scheda', '2024-07-09 20:19:35', 'francesca.neri@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e1fad8c5db68309f02f74204fe8#repl=11ef3e1fd81efb9a8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e1fad8c5db68309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e1fad8c5db68309f02f74204fe8-11ef3e1fd81efb9a8309f02f74204fe8'),
(0x11ef3e1ff1503ad68309f02f74204fe8, 'scheda', '2024-07-09 20:20:17', 'carlo.barbieri@procol.com', 'Risposta Commento', 'board.html?proj=46&post=11ef3e1fad8c5db68309f02f74204fe8#repl=11ef3e1ff15011098309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e1fad8c5db68309f02f74204fe8, 'carlo.barbieri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e1fad8c5db68309f02f74204fe8-11ef3e1ff15011098309f02f74204fe8'),
(0x11ef3e1fff67aa298309f02f74204fe8, 'scheda', '2024-07-09 20:20:41', 'francesca.neri@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e1fad8c5db68309f02f74204fe8#repl=11ef3e1fff66f0be8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e1fad8c5db68309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e1fad8c5db68309f02f74204fe8-11ef3e1fff66f0be8309f02f74204fe8'),
(0x11ef3e20217a6f888309f02f74204fe8, 'scheda', '2024-07-09 20:21:38', 'francesca.neri@procol.com', 'Aggiunta Descrizione Scheda', 'board.html?proj=46&post=11ef3e1fb7cf32328309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e1fb7cf32328309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e1fb7cf32328309f02f74204fe8'),
(0x11ef3e203025cd018309f02f74204fe8, 'scheda', '2024-07-09 20:22:03', 'francesca.neri@procol.com', 'Assegnazione Scheda', 'board.html?proj=46&post=11ef3e1fb7cf32328309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e1fb7cf32328309f02f74204fe8, 'francesca.neri@procol.com', 'simone.lombardi@procol.com-CRH-46-In Corso-11ef3e1fb7cf32328309f02f74204fe8'),
(0x11ef3e204242aa448309f02f74204fe8, 'scheda', '2024-07-09 20:22:33', 'simone.lombardi@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e1fb7cf32328309f02f74204fe8#repl=11ef3e204242953a8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e1fb7cf32328309f02f74204fe8, 'simone.lombardi@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e1fb7cf32328309f02f74204fe8-11ef3e204242953a8309f02f74204fe8'),
(0x11ef3e205ea50b488309f02f74204fe8, 'scheda', '2024-07-09 20:23:21', 'francesca.neri@procol.com', 'Risposta Commento', 'board.html?proj=46&post=11ef3e1fb7cf32328309f02f74204fe8#repl=11ef3e205ea4758a8309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e1fb7cf32328309f02f74204fe8, 'francesca.neri@procol.com', 'simone.lombardi@procol.com-CRH-46-In Corso-11ef3e1fb7cf32328309f02f74204fe8-11ef3e205ea4758a8309f02f74204fe8'),
(0x11ef3e206c5205b88309f02f74204fe8, 'scheda', '2024-07-09 20:23:44', 'simone.lombardi@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e1fb7cf32328309f02f74204fe8#repl=11ef3e206c51da988309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e1fb7cf32328309f02f74204fe8, 'simone.lombardi@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e1fb7cf32328309f02f74204fe8-11ef3e206c51da988309f02f74204fe8'),
(0x11ef3e2082d2e1418309f02f74204fe8, 'scheda', '2024-07-09 20:24:22', 'carlo.barbieri@procol.com', 'Creazione Scheda', 'board.html?proj=46&post=11ef3e2082d10ec78309f02f74204fe8', NULL, 'CRH', 46, 'In Attesa', 0x11ef3e2082d10ec78309f02f74204fe8, 'carlo.barbieri@procol.com', 'No Utente-CRH-46-In Attesa-11ef3e2082d10ec78309f02f74204fe8'),
(0x11ef3e2082d453f08309f02f74204fe8, 'scheda', '2024-07-09 20:24:22', 'carlo.barbieri@procol.com', 'Creazione Scheda', 'board.html?proj=46&post=11ef3e2082d437c58309f02f74204fe8', NULL, 'CRH', 46, 'In Attesa', NULL, 'carlo.barbieri@procol.com', 'No Utente-CRH-46-In Attesa-11ef3e2082d437c58309f02f74204fe8'),
(0x11ef3e208a77bbfb8309f02f74204fe8, 'scheda', '2024-07-09 20:24:34', 'carlo.barbieri@procol.com', 'Archiviazione Scheda', 'board.html?proj=46&post=11ef3e2082d437c58309f02f74204fe8', 'carlo.barbieri@procol.com', 'CRH', 46, 'In Attesa', NULL, 'carlo.barbieri@procol.com', '46-In Attesa-11ef3e2082d437c58309f02f74204fe8'),
(0x11ef3e2097cb02338309f02f74204fe8, 'scheda', '2024-07-09 20:24:57', 'carlo.barbieri@procol.com', 'Aggiunta Descrizione Scheda', 'board.html?proj=46&post=11ef3e2082d10ec78309f02f74204fe8', 'carlo.barbieri@procol.com', 'CRH', 46, 'In Attesa', 0x11ef3e2082d10ec78309f02f74204fe8, 'carlo.barbieri@procol.com', 'carlo.barbieri@procol.com-CRH-46-In Attesa-11ef3e2082d10ec78309f02f74204fe8'),
(0x11ef3e209e01ceae8309f02f74204fe8, 'scheda', '2024-07-09 20:25:07', 'carlo.barbieri@procol.com', 'Assegnazione Scheda', 'board.html?proj=46&post=11ef3e2082d10ec78309f02f74204fe8', 'carlo.barbieri@procol.com', 'CRH', 46, 'In Attesa', 0x11ef3e2082d10ec78309f02f74204fe8, 'carlo.barbieri@procol.com', 'carlo.barbieri@procol.com-CRH-46-In Attesa-11ef3e2082d10ec78309f02f74204fe8'),
(0x11ef3e20a6c6b7188309f02f74204fe8, 'scheda', '2024-07-09 20:25:22', 'carlo.barbieri@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e2082d10ec78309f02f74204fe8#repl=11ef3e20a6c5b99f8309f02f74204fe8', 'carlo.barbieri@procol.com', 'CRH', 46, 'In Attesa', 0x11ef3e2082d10ec78309f02f74204fe8, 'carlo.barbieri@procol.com', 'carlo.barbieri@procol.com-CRH-46-In Attesa-11ef3e2082d10ec78309f02f74204fe8-11ef3e20a6c5b99f8309f02f74204fe8'),
(0x11ef3e20afe3853e8309f02f74204fe8, 'scheda', '2024-07-09 20:25:37', 'francesca.neri@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e1fb7cf32328309f02f74204fe8#repl=11ef3e20afe361168309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e1fb7cf32328309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e1fb7cf32328309f02f74204fe8-11ef3e20afe361168309f02f74204fe8'),
(0x11ef3e20b9fe37458309f02f74204fe8, 'scheda', '2024-07-09 20:25:54', 'francesca.neri@procol.com', 'Eliminazione Commento', 'board.html?proj=46&post=11ef3e1fb7cf32328309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e1fb7cf32328309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e1fb7cf32328309f02f74204fe8-11ef3e20afe361168309f02f74204fe8'),
(0x11ef3e20bd2eba5f8309f02f74204fe8, 'scheda', '2024-07-09 20:25:59', 'francesca.neri@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e2082d10ec78309f02f74204fe8#repl=11ef3e20bd2e96d98309f02f74204fe8', 'carlo.barbieri@procol.com', 'CRH', 46, 'In Attesa', 0x11ef3e2082d10ec78309f02f74204fe8, 'francesca.neri@procol.com', 'carlo.barbieri@procol.com-CRH-46-In Attesa-11ef3e2082d10ec78309f02f74204fe8-11ef3e20bd2e96d98309f02f74204fe8'),
(0x11ef3e20d4a57b768309f02f74204fe8, 'scheda', '2024-07-09 20:26:39', 'francesca.neri@procol.com', 'Creazione Scheda', 'board.html?proj=46&post=11ef3e20d4a4d26d8309f02f74204fe8', NULL, 'CRH', 46, 'In Attesa', 0x11ef3e20d4a4d26d8309f02f74204fe8, 'francesca.neri@procol.com', 'No Utente-CRH-46-In Attesa-11ef3e20d4a4d26d8309f02f74204fe8'),
(0x11ef3e20e0f60f6b8309f02f74204fe8, 'scheda', '2024-07-09 20:26:59', 'francesca.neri@procol.com', 'Assegnazione Scheda', 'board.html?proj=46&post=11ef3e20d4a4d26d8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Attesa', 0x11ef3e20d4a4d26d8309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Attesa-11ef3e20d4a4d26d8309f02f74204fe8'),
(0x11ef3e20e654bdf18309f02f74204fe8, 'scheda', '2024-07-09 20:27:08', 'francesca.neri@procol.com', 'Riassegnazione Scheda', 'board.html?proj=46&post=11ef3e20d4a4d26d8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Attesa', 0x11ef3e20d4a4d26d8309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Attesa-11ef3e20d4a4d26d8309f02f74204fe8'),
(0x11ef3e20ee71342a8309f02f74204fe8, 'scheda', '2024-07-09 20:27:22', 'francesca.neri@procol.com', 'Aggiunta Descrizione Scheda', 'board.html?proj=46&post=11ef3e20d4a4d26d8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Attesa', 0x11ef3e20d4a4d26d8309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Attesa-11ef3e20d4a4d26d8309f02f74204fe8'),
(0x11ef3e20f48a94998309f02f74204fe8, 'scheda', '2024-07-09 20:27:32', 'francesca.neri@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e20d4a4d26d8309f02f74204fe8#repl=11ef3e20f48a79db8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Attesa', 0x11ef3e20d4a4d26d8309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Attesa-11ef3e20d4a4d26d8309f02f74204fe8-11ef3e20f48a79db8309f02f74204fe8'),
(0x11ef3e20fe5adb338309f02f74204fe8, 'scheda', '2024-07-09 20:27:49', 'simone.lombardi@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e20d4a4d26d8309f02f74204fe8#repl=11ef3e20fe5a1cbc8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Attesa', 0x11ef3e20d4a4d26d8309f02f74204fe8, 'simone.lombardi@procol.com', 'francesca.neri@procol.com-CRH-46-In Attesa-11ef3e20d4a4d26d8309f02f74204fe8-11ef3e20fe5a1cbc8309f02f74204fe8'),
(0x11ef3e211f8ee0ea8309f02f74204fe8, 'scheda', '2024-07-09 20:28:44', 'francesca.neri@procol.com', 'Modifica Commento', 'board.html?proj=46&post=11ef3e20d4a4d26d8309f02f74204fe8#repl=11ef3e20f48a79db8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Attesa', 0x11ef3e20d4a4d26d8309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Attesa-11ef3e20d4a4d26d8309f02f74204fe8-11ef3e20f48a79db8309f02f74204fe8'),
(0x11ef3e21235d53a58309f02f74204fe8, 'scheda', '2024-07-09 20:28:51', 'francesca.neri@procol.com', 'Modifica Commento', 'board.html?proj=46&post=11ef3e20d4a4d26d8309f02f74204fe8#repl=11ef3e20fe5a1cbc8309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'In Attesa', 0x11ef3e20d4a4d26d8309f02f74204fe8, 'francesca.neri@procol.com', 'simone.lombardi@procol.com-CRH-46-In Attesa-11ef3e20d4a4d26d8309f02f74204fe8-11ef3e20fe5a1cbc8309f02f74204fe8'),
(0x11ef3e2128422c418309f02f74204fe8, 'scheda', '2024-07-09 20:28:59', 'francesca.neri@procol.com', 'Modifica Commento', 'board.html?proj=46&post=11ef3e20d4a4d26d8309f02f74204fe8#repl=11ef3e20f48a79db8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Attesa', 0x11ef3e20d4a4d26d8309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Attesa-11ef3e20d4a4d26d8309f02f74204fe8-11ef3e20f48a79db8309f02f74204fe8'),
(0x11ef3e22a554bb6e8309f02f74204fe8, 'scheda', '2024-07-09 20:39:38', 'simone.lombardi@procol.com', 'Modifica Commento', 'board.html?proj=46&post=11ef3e20d4a4d26d8309f02f74204fe8#repl=11ef3e20fe5a1cbc8309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'In Attesa', 0x11ef3e20d4a4d26d8309f02f74204fe8, 'simone.lombardi@procol.com', 'simone.lombardi@procol.com-CRH-46-In Attesa-11ef3e20d4a4d26d8309f02f74204fe8-11ef3e20fe5a1cbc8309f02f74204fe8'),
(0x11ef3e266a5271ca8309f02f74204fe8, 'scheda', '2024-07-09 21:06:37', 'simone.lombardi@procol.com', 'Creazione Scheda', 'board.html?proj=46&post=11ef3e266a5100898309f02f74204fe8', NULL, 'CRH', 46, 'In Ritardo', NULL, 'simone.lombardi@procol.com', 'No Utente-CRH-46-In Ritardo-11ef3e266a5100898309f02f74204fe8'),
(0x11ef3e48078cab978309f02f74204fe8, 'scheda', '2024-07-10 01:07:16', 'simone.lombardi@procol.com', 'Archiviazione Scheda', 'board.html?proj=46&post=11ef3e266a5100898309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'In Ritardo', NULL, 'simone.lombardi@procol.com', '46-In Ritardo-11ef3e266a5100898309f02f74204fe8'),
(0x11ef3e4f023c92138309f02f74204fe8, 'scheda', '2024-07-10 01:57:13', 'simone.lombardi@procol.com', 'Creazione Scheda', 'board.html?proj=46&post=11ef3e4f023a977b8309f02f74204fe8', NULL, 'CRH', 46, 'In Corso', 0x11ef3e4f023a977b8309f02f74204fe8, 'simone.lombardi@procol.com', 'No Utente-CRH-46-In Corso-11ef3e4f023a977b8309f02f74204fe8'),
(0x11ef3e4f0cc795ec8309f02f74204fe8, 'scheda', '2024-07-10 01:57:31', 'simone.lombardi@procol.com', 'Aggiunta Descrizione Scheda', 'board.html?proj=46&post=11ef3e4f023a977b8309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e4f023a977b8309f02f74204fe8, 'simone.lombardi@procol.com', 'simone.lombardi@procol.com-CRH-46-In Corso-11ef3e4f023a977b8309f02f74204fe8'),
(0x11ef3e4f44e021d48309f02f74204fe8, 'scheda', '2024-07-10 01:59:05', 'simone.lombardi@procol.com', 'Assegnazione Scheda', 'board.html?proj=46&post=11ef3e4f023a977b8309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e4f023a977b8309f02f74204fe8, 'simone.lombardi@procol.com', 'simone.lombardi@procol.com-CRH-46-In Corso-11ef3e4f023a977b8309f02f74204fe8'),
(0x11ef3e4f5990292b8309f02f74204fe8, 'scheda', '2024-07-10 01:59:40', 'francesca.neri@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e4f023a977b8309f02f74204fe8#repl=11ef3e4f598e891c8309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e4f023a977b8309f02f74204fe8, 'francesca.neri@procol.com', 'simone.lombardi@procol.com-CRH-46-In Corso-11ef3e4f023a977b8309f02f74204fe8-11ef3e4f598e891c8309f02f74204fe8'),
(0x11ef3e4f65ea23ea8309f02f74204fe8, 'scheda', '2024-07-10 02:00:01', 'francesca.neri@procol.com', 'Cambiamento Stato', 'board.html?proj=46&post=11ef3e4f023a977b8309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'In Ritardo', 0x11ef3e4f023a977b8309f02f74204fe8, 'francesca.neri@procol.com', 'simone.lombardi@procol.com-CRH-46-In Ritardo-11ef3e4f023a977b8309f02f74204fe8'),
(0x11ef3e4f707d5ae98309f02f74204fe8, 'scheda', '2024-07-10 02:00:18', 'simone.lombardi@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e4f023a977b8309f02f74204fe8#repl=11ef3e4f707d16558309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'In Ritardo', 0x11ef3e4f023a977b8309f02f74204fe8, 'simone.lombardi@procol.com', 'simone.lombardi@procol.com-CRH-46-In Ritardo-11ef3e4f023a977b8309f02f74204fe8-11ef3e4f707d16558309f02f74204fe8'),
(0x11ef3e4f89daa0cd8309f02f74204fe8, 'scheda', '2024-07-10 02:01:01', 'simone.lombardi@procol.com', 'Creazione Scheda', 'board.html?proj=46&post=11ef3e4f89da63a88309f02f74204fe8', NULL, 'CRH', 46, 'In Attesa', 0x11ef3e4f89da63a88309f02f74204fe8, 'simone.lombardi@procol.com', 'No Utente-CRH-46-In Attesa-11ef3e4f89da63a88309f02f74204fe8'),
(0x11ef3e4f9199a8d08309f02f74204fe8, 'scheda', '2024-07-10 02:01:14', 'simone.lombardi@procol.com', 'Aggiunta Descrizione Scheda', 'board.html?proj=46&post=11ef3e4f89da63a88309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'In Attesa', 0x11ef3e4f89da63a88309f02f74204fe8, 'simone.lombardi@procol.com', 'simone.lombardi@procol.com-CRH-46-In Attesa-11ef3e4f89da63a88309f02f74204fe8'),
(0x11ef3e501e4ef4c48309f02f74204fe8, 'scheda', '2024-07-10 02:05:10', 'simone.lombardi@procol.com', 'Assegnazione Scheda', 'board.html?proj=46&post=11ef3e4f89da63a88309f02f74204fe8', 'carlo.barbieri@procol.com', 'CRH', 46, 'In Attesa', 0x11ef3e4f89da63a88309f02f74204fe8, 'simone.lombardi@procol.com', 'carlo.barbieri@procol.com-CRH-46-In Attesa-11ef3e4f89da63a88309f02f74204fe8'),
(0x11ef3e503a4dfdf58309f02f74204fe8, 'scheda', '2024-07-10 02:05:57', 'francesca.neri@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e4f89da63a88309f02f74204fe8#repl=11ef3e503a4d6ece8309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'In Attesa', 0x11ef3e4f89da63a88309f02f74204fe8, 'francesca.neri@procol.com', 'simone.lombardi@procol.com-CRH-46-In Attesa-11ef3e4f89da63a88309f02f74204fe8-11ef3e503a4d6ece8309f02f74204fe8'),
(0x11ef3e503c91ec628309f02f74204fe8, 'scheda', '2024-07-10 02:06:01', 'francesca.neri@procol.com', 'Cambiamento Stato', 'board.html?proj=46&post=11ef3e4f89da63a88309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'In Ritardo', 0x11ef3e4f89da63a88309f02f74204fe8, 'francesca.neri@procol.com', 'simone.lombardi@procol.com-CRH-46-In Ritardo-11ef3e4f89da63a88309f02f74204fe8'),
(0x11ef3e53144562318309f02f74204fe8, 'scheda', '2024-07-10 02:26:22', 'carlo.barbieri@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e4f89da63a88309f02f74204fe8#repl=11ef3e531444ea2c8309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'In Ritardo', 0x11ef3e4f89da63a88309f02f74204fe8, 'carlo.barbieri@procol.com', 'simone.lombardi@procol.com-CRH-46-In Ritardo-11ef3e4f89da63a88309f02f74204fe8-11ef3e531444ea2c8309f02f74204fe8'),
(0x11ef3e536e8702048309f02f74204fe8, 'sessione', '2024-07-10 02:28:53', 'francesca.neri@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'francesca.neri@procol.com', NULL),
(0x11ef3e538c942a2b8309f02f74204fe8, 'scheda', '2024-07-10 02:29:43', 'francesca.neri@procol.com', 'Creazione Scheda', 'board.html?proj=46&post=11ef3e538c93655b8309f02f74204fe8', NULL, 'CRH', 46, 'In Corso', 0x11ef3e538c93655b8309f02f74204fe8, 'francesca.neri@procol.com', 'No Utente-CRH-46-In Corso-11ef3e538c93655b8309f02f74204fe8'),
(0x11ef3e5390d674418309f02f74204fe8, 'scheda', '2024-07-10 02:29:51', 'francesca.neri@procol.com', 'Aggiunta Descrizione Scheda', 'board.html?proj=46&post=11ef3e538c93655b8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e538c93655b8309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e538c93655b8309f02f74204fe8'),
(0x11ef3e53a2494e9d8309f02f74204fe8, 'scheda', '2024-07-10 02:30:20', 'francesca.neri@procol.com', 'Assegnazione Scheda', 'board.html?proj=46&post=11ef3e538c93655b8309f02f74204fe8', 'carlo.barbieri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e538c93655b8309f02f74204fe8, 'francesca.neri@procol.com', 'carlo.barbieri@procol.com-CRH-46-In Corso-11ef3e538c93655b8309f02f74204fe8'),
(0x11ef3e53ad2bf1368309f02f74204fe8, 'scheda', '2024-07-10 02:30:38', 'francesca.neri@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e538c93655b8309f02f74204fe8#repl=11ef3e53ad2bd25c8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e538c93655b8309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e538c93655b8309f02f74204fe8-11ef3e53ad2bd25c8309f02f74204fe8'),
(0x11ef3e53b16b83458309f02f74204fe8, 'scheda', '2024-07-10 02:30:45', 'francesca.neri@procol.com', 'Archiviazione Scheda', 'board.html?proj=46&post=11ef3e538c93655b8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e538c93655b8309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e538c93655b8309f02f74204fe8'),
(0x11ef3e53b652f88c8309f02f74204fe8, 'scheda', '2024-07-10 02:30:53', 'francesca.neri@procol.com', 'Eliminazione Scheda', 'board.html?proj=46&post=11ef3e266a5100898309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'Eliminate', NULL, 'francesca.neri@procol.com', 'simone.lombardi@procol.com-CRH-46-Eliminate-11ef3e266a5100898309f02f74204fe8'),
(0x11ef3e53bac6f6008309f02f74204fe8, 'scheda', '2024-07-10 02:31:01', 'francesca.neri@procol.com', 'Eliminazione Scheda', 'board.html?proj=46&post=11ef3e2082d437c58309f02f74204fe8', 'carlo.barbieri@procol.com', 'CRH', 46, 'Eliminate', NULL, 'francesca.neri@procol.com', 'carlo.barbieri@procol.com-CRH-46-Eliminate-11ef3e2082d437c58309f02f74204fe8'),
(0x11ef3e53c908f0148309f02f74204fe8, 'scheda', '2024-07-10 02:31:25', 'francesca.neri@procol.com', 'Creazione Scheda', 'board.html?proj=46&post=11ef3e53c908d0ef8309f02f74204fe8', NULL, 'CRH', 46, 'In Corso', NULL, 'francesca.neri@procol.com', 'No Utente-CRH-46-In Corso-11ef3e53c908d0ef8309f02f74204fe8'),
(0x11ef3e53c90b4cc08309f02f74204fe8, 'scheda', '2024-07-10 02:31:25', 'francesca.neri@procol.com', 'Creazione Scheda', 'board.html?proj=46&post=11ef3e53c909e9e58309f02f74204fe8', NULL, 'CRH', 46, 'In Corso', NULL, 'francesca.neri@procol.com', 'No Utente-CRH-46-In Corso-11ef3e53c909e9e58309f02f74204fe8'),
(0x11ef3e53cab6e83e8309f02f74204fe8, 'scheda', '2024-07-10 02:31:28', 'francesca.neri@procol.com', 'Archiviazione Scheda', 'board.html?proj=46&post=11ef3e53c909e9e58309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', NULL, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e53c909e9e58309f02f74204fe8'),
(0x11ef3e53cc50d52e8309f02f74204fe8, 'scheda', '2024-07-10 02:31:30', 'francesca.neri@procol.com', 'Archiviazione Scheda', 'board.html?proj=46&post=11ef3e53c908d0ef8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', NULL, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e53c908d0ef8309f02f74204fe8'),
(0x11ef3e53d104621d8309f02f74204fe8, 'progetto', '2024-07-10 02:31:38', 'francesca.neri@procol.com', 'Creazione Categoria', 'board.html?proj=46', NULL, 'CRH', 46, 'Prova', NULL, 'francesca.neri@procol.com', 'No Utente-CRH-46-Prova'),
(0x11ef3e53d3fb74c48309f02f74204fe8, 'progetto', '2024-07-10 02:31:43', 'francesca.neri@procol.com', 'Eliminazione Categoria', 'board.html?proj=46', NULL, 'CRH', 46, 'Prova', NULL, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-No Utente-CRH-46-Prova'),
(0x11ef3e53d7092b6c8309f02f74204fe8, 'scheda', '2024-07-10 02:31:48', 'francesca.neri@procol.com', 'Eliminazione Scheda', 'board.html?proj=46&post=11ef3e53c908d0ef8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'Eliminate', NULL, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-Eliminate-11ef3e53c908d0ef8309f02f74204fe8'),
(0x11ef3e53d84ba2808309f02f74204fe8, 'scheda', '2024-07-10 02:31:50', 'francesca.neri@procol.com', 'Eliminazione Scheda', 'board.html?proj=46&post=11ef3e53c909e9e58309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'Eliminate', NULL, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-Eliminate-11ef3e53c909e9e58309f02f74204fe8'),
(0x11ef3e53fb40e25e8309f02f74204fe8, 'scheda', '2024-07-10 02:32:49', 'francesca.neri@procol.com', 'Creazione Scheda', 'board.html?proj=46&post=11ef3e53fb405f018309f02f74204fe8', NULL, 'CRH', 46, 'In Corso', 0x11ef3e53fb405f018309f02f74204fe8, 'francesca.neri@procol.com', 'No Utente-CRH-46-In Corso-11ef3e53fb405f018309f02f74204fe8'),
(0x11ef3e540d53a1628309f02f74204fe8, 'scheda', '2024-07-10 02:33:19', 'francesca.neri@procol.com', 'Aggiunta Descrizione Scheda', 'board.html?proj=46&post=11ef3e53fb405f018309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e53fb405f018309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e53fb405f018309f02f74204fe8'),
(0x11ef3e54180a01588309f02f74204fe8, 'scheda', '2024-07-10 02:33:37', 'francesca.neri@procol.com', 'Assegnazione Scheda', 'board.html?proj=46&post=11ef3e53fb405f018309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e53fb405f018309f02f74204fe8, 'francesca.neri@procol.com', 'simone.lombardi@procol.com-CRH-46-In Corso-11ef3e53fb405f018309f02f74204fe8'),
(0x11ef3e5438af51f08309f02f74204fe8, 'scheda', '2024-07-10 02:34:32', 'simone.lombardi@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e53fb405f018309f02f74204fe8#repl=11ef3e5438af32a38309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e53fb405f018309f02f74204fe8, 'simone.lombardi@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e53fb405f018309f02f74204fe8-11ef3e5438af32a38309f02f74204fe8'),
(0x11ef3e544b2643728309f02f74204fe8, 'scheda', '2024-07-10 02:35:03', 'francesca.neri@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e53fb405f018309f02f74204fe8#repl=11ef3e544b258c2f8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e53fb405f018309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e53fb405f018309f02f74204fe8-11ef3e544b258c2f8309f02f74204fe8'),
(0x11ef3e544d0e0c278309f02f74204fe8, 'scheda', '2024-07-10 02:35:06', 'francesca.neri@procol.com', 'Archiviazione Scheda', 'board.html?proj=46&post=11ef3e53fb405f018309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e53fb405f018309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e53fb405f018309f02f74204fe8'),
(0x11ef3e545bd1ec428309f02f74204fe8, 'scheda', '2024-07-10 02:35:31', 'francesca.neri@procol.com', 'Creazione Scheda', 'board.html?proj=46&post=11ef3e545bd1d33f8309f02f74204fe8', NULL, 'CRH', 46, 'In Corso', 0x11ef3e545bd1d33f8309f02f74204fe8, 'francesca.neri@procol.com', 'No Utente-CRH-46-In Corso-11ef3e545bd1d33f8309f02f74204fe8'),
(0x11ef3e546256e6a78309f02f74204fe8, 'scheda', '2024-07-10 02:35:42', 'francesca.neri@procol.com', 'Aggiunta Descrizione Scheda', 'board.html?proj=46&post=11ef3e545bd1d33f8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e545bd1d33f8309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e545bd1d33f8309f02f74204fe8'),
(0x11ef3e546f5e01328309f02f74204fe8, 'scheda', '2024-07-10 02:36:04', 'francesca.neri@procol.com', 'Assegnazione Scheda', 'board.html?proj=46&post=11ef3e545bd1d33f8309f02f74204fe8', 'carlo.barbieri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e545bd1d33f8309f02f74204fe8, 'francesca.neri@procol.com', 'carlo.barbieri@procol.com-CRH-46-In Corso-11ef3e545bd1d33f8309f02f74204fe8');
INSERT INTO `report` (`uuid_report`, `tipo_azione`, `timestamp`, `attore`, `descrizione`, `link`, `utente`, `team`, `progetto`, `categoria`, `scheda`, `attore_era`, `bersaglio_era`) VALUES
(0x11ef3e54855ab33a8309f02f74204fe8, 'scheda', '2024-07-10 02:36:41', 'carlo.barbieri@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e545bd1d33f8309f02f74204fe8#repl=11ef3e54855a9b968309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e545bd1d33f8309f02f74204fe8, 'carlo.barbieri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e545bd1d33f8309f02f74204fe8-11ef3e54855a9b968309f02f74204fe8'),
(0x11ef3e5488e1e76f8309f02f74204fe8, 'scheda', '2024-07-10 02:36:47', 'francesca.neri@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e545bd1d33f8309f02f74204fe8#repl=11ef3e5488e1d5978309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e545bd1d33f8309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e545bd1d33f8309f02f74204fe8-11ef3e5488e1d5978309f02f74204fe8'),
(0x11ef3e548bc952d58309f02f74204fe8, 'scheda', '2024-07-10 02:36:52', 'francesca.neri@procol.com', 'Modifica Commento', 'board.html?proj=46&post=11ef3e545bd1d33f8309f02f74204fe8#repl=11ef3e5488e1d5978309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e545bd1d33f8309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e545bd1d33f8309f02f74204fe8-11ef3e5488e1d5978309f02f74204fe8'),
(0x11ef3e54919d5f5c8309f02f74204fe8, 'scheda', '2024-07-10 02:37:01', 'francesca.neri@procol.com', 'Cambiamento Stato', 'board.html?proj=46&post=11ef3e545bd1d33f8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'Completate', 0x11ef3e545bd1d33f8309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-Completate-11ef3e545bd1d33f8309f02f74204fe8'),
(0x11ef3e54decdcfaf8309f02f74204fe8, 'scheda', '2024-07-10 02:39:11', 'francesca.neri@procol.com', 'Creazione Scheda', 'board.html?proj=46&post=11ef3e54decc890c8309f02f74204fe8', NULL, 'CRH', 46, 'In Corso', 0x11ef3e54decc890c8309f02f74204fe8, 'francesca.neri@procol.com', 'No Utente-CRH-46-In Corso-11ef3e54decc890c8309f02f74204fe8'),
(0x11ef3e54e485839c8309f02f74204fe8, 'scheda', '2024-07-10 02:39:20', 'francesca.neri@procol.com', 'Aggiunta Descrizione Scheda', 'board.html?proj=46&post=11ef3e54decc890c8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e54decc890c8309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e54decc890c8309f02f74204fe8'),
(0x11ef3e54eb2167fe8309f02f74204fe8, 'scheda', '2024-07-10 02:39:31', 'francesca.neri@procol.com', 'Assegnazione Scheda', 'board.html?proj=46&post=11ef3e54decc890c8309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e54decc890c8309f02f74204fe8, 'francesca.neri@procol.com', 'simone.lombardi@procol.com-CRH-46-In Corso-11ef3e54decc890c8309f02f74204fe8'),
(0x11ef3e54f52d3fb78309f02f74204fe8, 'scheda', '2024-07-10 02:39:48', 'simone.lombardi@procol.com', 'Creazione Commento', 'board.html?proj=46&post=11ef3e54decc890c8309f02f74204fe8#repl=11ef3e54f52c2c2d8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e54decc890c8309f02f74204fe8, 'simone.lombardi@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e54decc890c8309f02f74204fe8-11ef3e54f52c2c2d8309f02f74204fe8'),
(0x11ef3e550f4b166c8309f02f74204fe8, 'scheda', '2024-07-10 02:40:32', 'francesca.neri@procol.com', 'Risposta Commento', 'board.html?proj=46&post=11ef3e54decc890c8309f02f74204fe8#repl=11ef3e550f4afa448309f02f74204fe8', 'simone.lombardi@procol.com', 'CRH', 46, 'In Corso', 0x11ef3e54decc890c8309f02f74204fe8, 'francesca.neri@procol.com', 'simone.lombardi@procol.com-CRH-46-In Corso-11ef3e54decc890c8309f02f74204fe8-11ef3e550f4afa448309f02f74204fe8'),
(0x11ef3e5511a779858309f02f74204fe8, 'scheda', '2024-07-10 02:40:36', 'francesca.neri@procol.com', 'Cambiamento Stato', 'board.html?proj=46&post=11ef3e54decc890c8309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'Completate', 0x11ef3e54decc890c8309f02f74204fe8, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-Completate-11ef3e54decc890c8309f02f74204fe8'),
(0x11ef3e56c215a5da8309f02f74204fe8, 'scheda', '2024-07-10 02:52:42', 'francesca.neri@procol.com', 'Creazione Scheda', 'board.html?proj=46&post=11ef3e56c2149a718309f02f74204fe8', NULL, 'CRH', 46, 'Eliminate', NULL, 'francesca.neri@procol.com', 'No Utente-CRH-46-Eliminate-11ef3e56c2149a718309f02f74204fe8'),
(0x11ef3e56c40bc4418309f02f74204fe8, 'scheda', '2024-07-10 02:52:45', 'francesca.neri@procol.com', 'Eliminazione Scheda', 'board.html?proj=46&post=11ef3e56c2149a718309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'Eliminate', NULL, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-Eliminate-11ef3e56c2149a718309f02f74204fe8'),
(0x11ef3e56cad13d838309f02f74204fe8, 'scheda', '2024-07-10 02:52:56', 'francesca.neri@procol.com', 'Creazione Scheda', 'board.html?proj=46&post=11ef3e56cad0bd218309f02f74204fe8', NULL, 'CRH', 46, 'In Corso', NULL, 'francesca.neri@procol.com', 'No Utente-CRH-46-In Corso-11ef3e56cad0bd218309f02f74204fe8'),
(0x11ef3e56cd7ab2e58309f02f74204fe8, 'scheda', '2024-07-10 02:53:01', 'francesca.neri@procol.com', 'Archiviazione Scheda', 'board.html?proj=46&post=11ef3e56cad0bd218309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'In Corso', NULL, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-In Corso-11ef3e56cad0bd218309f02f74204fe8'),
(0x11ef3e56cf666a578309f02f74204fe8, 'scheda', '2024-07-10 02:53:04', 'francesca.neri@procol.com', 'Eliminazione Scheda', 'board.html?proj=46&post=11ef3e56cad0bd218309f02f74204fe8', 'francesca.neri@procol.com', 'CRH', 46, 'Eliminate', NULL, 'francesca.neri@procol.com', 'francesca.neri@procol.com-CRH-46-Eliminate-11ef3e56cad0bd218309f02f74204fe8'),
(0x11ef3e5b0a3fd7a78309f02f74204fe8, 'sessione', '2024-07-10 03:23:21', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef3e5dc3c5f8148309f02f74204fe8, 'scheda', '2024-07-10 03:42:51', 'admin@procol.com', 'Eliminazione Scheda', 'board.html?proj=74&post=11ef3af5a8dd44558309f02f74204fe8', 'imma.capuano@procol.com', 'GFS', 74, 'Eliminate', NULL, 'admin@procol.com', 'imma.capuano@procol.com-GFS-74-Eliminate-11ef3af5a8dd44558309f02f74204fe8'),
(0x11ef3e5de155d48c8309f02f74204fe8, 'sessione', '2024-07-10 03:43:41', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef3e5e01175fd78309f02f74204fe8, 'team', '2024-07-10 03:44:34', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'filomena.marasco@procol.it', 'PCU', NULL, NULL, NULL, 'admin@procol.com', 'filomena.marasco@procol.it-PCU'),
(0x11ef3e604b126c2d8309f02f74204fe8, 'sessione', '2024-07-10 04:00:57', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef3e6059c27da28309f02f74204fe8, 'sessione', '2024-07-10 04:01:22', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3e6091132dd58309f02f74204fe8, 'sessione', '2024-07-10 04:02:54', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3ee1c37a07168309f02f74204fe8, 'sessione', '2024-07-10 19:27:42', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3ee2270085ef8309f02f74204fe8, 'scheda', '2024-07-10 19:30:29', 'goshin26@icloud.com', 'Creazione Scheda', 'board.html?proj=15&post=11ef3ee226ffb8af8309f02f74204fe8', NULL, 'PCU', 15, 'In Corso', NULL, 'goshin26@icloud.com', 'No Utente-PCU-15-In Corso-11ef3ee226ffb8af8309f02f74204fe8'),
(0x11ef3ee2289f90c28309f02f74204fe8, 'progetto', '2024-07-10 19:30:32', 'goshin26@icloud.com', 'Creazione Categoria', 'board.html?proj=15', NULL, 'PCU', 15, 'Lol', NULL, 'goshin26@icloud.com', 'No Utente-PCU-15-Lol'),
(0x11ef3ee24d99cdbe8309f02f74204fe8, 'scheda', '2024-07-10 19:31:34', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=15&post=11ef3ee226ffb8af8309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'In Ritardo', NULL, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-In Ritardo-11ef3ee226ffb8af8309f02f74204fe8'),
(0x11ef3ee25cbb25b18309f02f74204fe8, 'scheda', '2024-07-10 19:31:59', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=15&post=11ef3ee226ffb8af8309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'In Corso', NULL, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-In Corso-11ef3ee226ffb8af8309f02f74204fe8'),
(0x11ef3ee25fe78df38309f02f74204fe8, 'scheda', '2024-07-10 19:32:04', 'goshin26@icloud.com', 'Cambiamento Stato', 'board.html?proj=15&post=11ef3ee226ffb8af8309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'In Ritardo', NULL, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-In Ritardo-11ef3ee226ffb8af8309f02f74204fe8'),
(0x11ef3ee26994f0ea8309f02f74204fe8, 'scheda', '2024-07-10 19:32:21', 'goshin26@icloud.com', 'Archiviazione Scheda', 'board.html?proj=15&post=11ef3ee226ffb8af8309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'In Ritardo', NULL, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-In Ritardo-11ef3ee226ffb8af8309f02f74204fe8'),
(0x11ef3ee2733f9ca18309f02f74204fe8, 'sessione', '2024-07-10 19:32:37', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3ee27d3670408309f02f74204fe8, 'sessione', '2024-07-10 19:32:53', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef3ee2927fa4b88309f02f74204fe8, 'team', '2024-07-10 19:33:29', 'admin@procol.com', 'Assegnazione Team', NULL, 'goshin26@icloud.com', 'PCU', NULL, NULL, NULL, 'admin@procol.com', 'goshin26@icloud.com-PCU'),
(0x11ef3ee29e2d42778309f02f74204fe8, 'utente', '2024-07-10 19:33:49', 'admin@procol.com', 'Eliminazione Utente', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', 'antimo.puca@procol.com'),
(0x11ef3ee2b0654b3b8309f02f74204fe8, 'sessione', '2024-07-10 19:34:19', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL),
(0x11ef3ee2b6e0e52f8309f02f74204fe8, 'scheda', '2024-07-10 19:34:30', 'goshin26@icloud.com', 'Eliminazione Scheda', 'board.html?proj=15&post=11ef3ee226ffb8af8309f02f74204fe8', 'goshin26@icloud.com', 'PCU', 15, 'Eliminate', NULL, 'goshin26@icloud.com', 'goshin26@icloud.com-PCU-15-Eliminate-11ef3ee226ffb8af8309f02f74204fe8'),
(0x11ef3ee2ba39b7d68309f02f74204fe8, 'progetto', '2024-07-10 19:34:36', 'goshin26@icloud.com', 'Eliminazione Categoria', 'board.html?proj=15', NULL, 'PCU', 15, 'Lol', NULL, 'goshin26@icloud.com', 'No Utente-PCU-15-Lol'),
(0x11ef3ee3945d6b7c8309f02f74204fe8, 'sessione', '2024-07-10 19:40:42', 'admin@procol.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'admin@procol.com', NULL),
(0x11ef3ee3b4db8a628309f02f74204fe8, 'team', '2024-07-10 19:41:36', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'antimo.puca@procol.com', 'PCU', NULL, NULL, NULL, 'admin@procol.com', 'antimo.puca@procol.com-PCU'),
(0x11ef3ee3b4dc39838309f02f74204fe8, 'team', '2024-07-10 19:41:36', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'giuseppina.puca@procol.com', 'PCU', NULL, NULL, NULL, 'admin@procol.com', 'giuseppina.puca@procol.com-PCU'),
(0x11ef3ee3b4dc580c8309f02f74204fe8, 'team', '2024-07-10 19:41:36', 'admin@procol.com', 'Aggiunta Utente Nel Team', NULL, 'giovanni.puca@procol.com', 'PCU', NULL, NULL, NULL, 'admin@procol.com', 'giovanni.puca@procol.com-PCU'),
(0x11ef3ee3c9acbfb98309f02f74204fe8, 'sessione', '2024-07-10 19:42:11', 'goshin26@icloud.com', 'Accesso', NULL, NULL, NULL, NULL, NULL, NULL, 'goshin26@icloud.com', NULL);

--
-- Trigger `report`
--
DROP TRIGGER IF EXISTS `anticipo_inserimento_report`;
DELIMITER $$
CREATE TRIGGER `anticipo_inserimento_report` BEFORE INSERT ON `report` FOR EACH ROW BEGIN
	SET @uuid = UUID();
	SET NEW.uuid_report = UNHEX(CONCAT(
		SUBSTR(@uuid, 15, 4),
		SUBSTR(@uuid, 10, 4),
		SUBSTR(@uuid, 1, 8),
		SUBSTR(@uuid, 20, 4),
		SUBSTR(@uuid, 25))
	);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struttura della tabella `schede`
--

DROP TABLE IF EXISTS `schede`;
CREATE TABLE IF NOT EXISTS `schede` (
  `uuid_scheda` binary(16) NOT NULL,
  `id_progetto` int(11) DEFAULT NULL,
  `stato` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `titolo` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `descrizione` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `autore` varchar(255) DEFAULT NULL,
  `creazione` datetime NOT NULL DEFAULT current_timestamp(),
  `scadenza` datetime DEFAULT NULL,
  `ordine_schede` int(10) UNSIGNED NOT NULL
) ;

--
-- Dump dei dati per la tabella `schede`
--

INSERT INTO `schede` (`uuid_scheda`, `id_progetto`, `stato`, `titolo`, `descrizione`, `autore`, `creazione`, `scadenza`, `ordine_schede`) VALUES
(0x11ef0bebc48909f3813af02f74204fe8, 15, 'In Ritardo', 'Bug Fixes', '', 'goshin26@icloud.com', '2024-05-06 23:01:06', NULL, 0),
(0x11ef0bebc48c857e813af02f74204fe8, 15, 'Completate', 'Strutturazione Database', 'Il database é stato completato&nbsp;', 'goshin26@icloud.com', '2024-05-06 23:01:06', NULL, 0),
(0x11ef0bebc48f1669813af02f74204fe8, 15, 'In Ritardo', 'Gestione Calendario', '', 'goshin26@icloud.com', '2024-05-06 23:01:06', NULL, 1),
(0x11ef0bebc491eb66813af02f74204fe8, 15, 'Completate', 'Pagina di Login', '', 'goshin26@icloud.com', '2024-05-06 23:01:06', NULL, 1),
(0x11ef0bebc495894b813af02f74204fe8, 15, 'In Ritardo', 'Attachments', '', 'goshin26@icloud.com', '2024-05-06 23:01:06', NULL, 2),
(0x11ef0bee92cbdddc813af02f74204fe8, 15, 'In Ritardo', 'Ristrutturazione Grafica', '', 'goshin26@icloud.com', '2024-05-06 23:21:11', NULL, 3),
(0x11ef0bee9fd76d48813af02f74204fe8, 15, 'In Ritardo', 'Risemplificazione', '', 'goshin26@icloud.com', '2024-05-06 23:21:33', NULL, 4),
(0x11ef0bee9fdae55f813af02f74204fe8, 15, 'In Ritardo', 'Funzione Alias per Utenti', '', 'goshin26@icloud.com', '2024-05-06 23:21:33', NULL, 5),
(0x11ef0bee9fdbf109813af02f74204fe8, 15, 'Eliminate', 'Resoconto disconnessioni', '', 'goshin26@icloud.com', '2024-05-06 23:21:33', NULL, 0),
(0x11ef3491ab45987d8309f02f74204fe8, 14, 'Eliminate', 'si', '', 'goshin26@icloud.com', '2024-06-27 16:29:27', NULL, 0),
(0x11ef34db5d7220d08309f02f74204fe8, 14, 'Completate', 'Dashboard per Admin', '', 'goshin26@icloud.com', '2024-06-28 01:16:59', NULL, 0),
(0x11ef34e4ac36c58c8309f02f74204fe8, 14, 'Sql Prova', 'ciao 1', '', 'goshin26@icloud.com', '2024-06-28 02:23:37', NULL, 0),
(0x11ef34eb93b6eb178309f02f74204fe8, 14, 'Eliminate', 'daje', '', 'goshin26@icloud.com', '2024-06-28 03:13:02', NULL, 1),
(0x11ef3af4d31f30bc8309f02f74204fe8, 74, 'In Corso', 'Giando Fa Schifo', 'Il nostro team si occupa principalmente di maltrattare ed insultare giando.&nbsp;<br>Per qualsiasi informazione o per una consulenza non esitate a contattarci.&nbsp;<br>Inoltre il nostro team, come segno di ringraziamento, offre una dimostrazione omaggio su richiesta.&nbsp;<br>Quindi cosa state aspettando? Affrettatevi!<br>Siamo disposti anche ad offrire più di una dimostrazione gratuita per divertirci insieme come un vero team', 'imma.capuano@procol.com', '2024-07-05 19:34:11', NULL, 0),
(0x11ef3e1fad8c5db68309f02f74204fe8, 46, 'In Corso', 'Installazione Pannelli Solari', 'Installazione di pannelli solari sui tetti degli edifici residenziali.', 'francesca.neri@procol.com', '2024-07-09 20:18:24', NULL, 0),
(0x11ef3e1fb7cf32328309f02f74204fe8, 46, 'In Corso', 'Manutenzione Turbine Eoliche', 'Verifica e manutenzione delle turbine eoliche nel parco.', 'francesca.neri@procol.com', '2024-07-09 20:18:41', NULL, 1),
(0x11ef3e2082d10ec78309f02f74204fe8, 46, 'In Attesa', 'Approvazione Progetto Biomasse', 'Attesa dell\'approvazione del progetto per la costruzione di un impianto a biomasse.', 'carlo.barbieri@procol.com', '2024-07-09 20:24:21', NULL, 0),
(0x11ef3e20d4a4d26d8309f02f74204fe8, 46, 'In Attesa', 'Finanziamento Impianto Idroelettrico', 'Richiesta di finanziamento per la costruzione di un nuovo impianto idroelettrico.', 'francesca.neri@procol.com', '2024-07-09 20:26:39', NULL, 1),
(0x11ef3e4f023a977b8309f02f74204fe8, 46, 'In Ritardo', 'Progetto Microgrid', 'Implementazione di una microgrid per la comunità rurale.', 'simone.lombardi@procol.com', '2024-07-10 01:57:13', '2024-07-02 19:42:27', 0),
(0x11ef3e4f89da63a88309f02f74204fe8, 46, 'In Ritardo', 'Upgrade Sistema di Stoccaggio', 'Miglioramento del sistema di stoccaggio energetico.', 'simone.lombardi@procol.com', '2024-07-10 02:01:01', '2024-07-02 02:43:19', 1),
(0x11ef3e538c93655b8309f02f74204fe8, 46, 'Eliminate', 'Progetto Geotermico', 'Esplorazione della fattibilità di un impianto geotermico.', 'francesca.neri@procol.com', '2024-07-10 02:29:43', NULL, 2),
(0x11ef3e53fb405f018309f02f74204fe8, 46, 'Eliminate', 'Recupero Calori di Scarto', 'Utilizzo del calore di scarto per la produzione di energia.', 'francesca.neri@procol.com', '2024-07-10 02:32:49', NULL, 3),
(0x11ef3e545bd1d33f8309f02f74204fe8, 46, 'Completate', 'Progetto Fotovoltaico Scuola', 'Installazione di un impianto fotovoltaico presso una scuola locale.', 'francesca.neri@procol.com', '2024-07-10 02:35:31', NULL, 0),
(0x11ef3e54decc890c8309f02f74204fe8, 46, 'Completate', 'Implementazione Sistema di Monitoraggio', 'Implementazione di un sistema di monitoraggio per il consumo energetico.', 'francesca.neri@procol.com', '2024-07-10 02:39:11', NULL, 1);

--
-- Trigger `schede`
--
DROP TRIGGER IF EXISTS `anticipo_inserimento_scheda`;
DELIMITER $$
CREATE TRIGGER `anticipo_inserimento_scheda` BEFORE INSERT ON `schede` FOR EACH ROW BEGIN
	SET @uuid = UUID();
	SET NEW.uuid_scheda = UNHEX(CONCAT(
		SUBSTR(@uuid, 15, 4),
		SUBSTR(@uuid, 10, 4),
		SUBSTR(@uuid, 1, 8),
		SUBSTR(@uuid, 20, 4),
		SUBSTR(@uuid, 25))
	);
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `crea_info_schede_dopo_inserimento`;
DELIMITER $$
CREATE TRIGGER `crea_info_schede_dopo_inserimento` AFTER INSERT ON `schede` FOR EACH ROW BEGIN
    INSERT INTO info_schede (uuid_scheda, incaricato, inizio_mandato, fine_mandato, spostamento, spostato_da, data_inizio, data_fine, ultima_modifica, modificato_da)
    VALUES (NEW.uuid_scheda, NULL, NULL, NULL, CURRENT_TIMESTAMP(), NEW.autore, CURRENT_TIMESTAMP(), NULL, NULL, NULL);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struttura della tabella `stati`
--

DROP TABLE IF EXISTS `stati`;
CREATE TABLE IF NOT EXISTS `stati` (
  `id_progetto` int(11) NOT NULL,
  `stato` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `colore_hex` varchar(9) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#ffffffff',
  `ordine_stati` int(10) UNSIGNED NOT NULL,
  `visibile` tinyint(1) NOT NULL
) ;

--
-- Dump dei dati per la tabella `stati`
--

INSERT INTO `stati` (`id_progetto`, `stato`, `colore_hex`, `ordine_stati`, `visibile`) VALUES
(14, 'Asdsaasdsadsad', '#4D057BFF', 11, 1),
(14, 'Ciao', '#EEFF00FF', 8, 1),
(14, 'Completate', '#00FF00FF', 2, 1),
(14, 'Eliminate', '#808080FF', 4, 0),
(14, 'Hahah', '#4D057BFF', 7, 1),
(14, 'In Attesa', '#FFFF00FF', 1, 1),
(14, 'In Corso', '#FFA500FF', 0, 1),
(14, 'In Ritardo', '#FF0000FF', 3, 1),
(14, 'Nuooo', '#4D057BFF', 9, 1),
(14, 'Sddasd', '#4D057BFF', 10, 1),
(14, 'Sql Prova', '#00FFE175', 5, 1),
(14, 'Vittoria', '#4D057BFF', 6, 1),
(15, 'Completate', '#00FF00FF', 2, 1),
(15, 'Eliminate', '#808080FF', 4, 0),
(15, 'In Attesa', '#FFFF00FF', 1, 1),
(15, 'In Corso', '#FFA500FF', 0, 1),
(15, 'In Ritardo', '#FF0000FF', 3, 1),
(24, '219 225', '#4D057BFF', 5, 1),
(24, 'Completate', '#00FF00FF', 2, 1),
(24, 'Eliminate', '#808080FF', 4, 0),
(24, 'In Attesa', '#FFFF00FF', 1, 1),
(24, 'In Corso', '#FFA500FF', 0, 1),
(24, 'In Ritardo', '#FF0000FF', 3, 1),
(25, 'Completate', '#00FF00FF', 2, 1),
(25, 'Eliminate', '#808080FF', 4, 0),
(25, 'In Attesa', '#FFFF00FF', 1, 1),
(25, 'In Corso', '#FFA500FF', 0, 1),
(25, 'In Ritardo', '#FF0000FF', 3, 1),
(27, 'Completate', '#00FF00FF', 2, 1),
(27, 'Eliminate', '#808080FF', 4, 0),
(27, 'In Attesa', '#FFFF00FF', 1, 1),
(27, 'In Corso', '#FFA500FF', 0, 1),
(27, 'In Ritardo', '#FF0000FF', 3, 1),
(35, 'Completate', '#00FF00FF', 2, 1),
(35, 'Eliminate', '#808080FF', 4, 0),
(35, 'In Attesa', '#FFFF00FF', 1, 1),
(35, 'In Corso', '#FFA500FF', 0, 1),
(35, 'In Ritardo', '#FF0000FF', 3, 1),
(39, 'Completate', '#00FF00FF', 2, 1),
(39, 'Eliminate', '#808080FF', 4, 0),
(39, 'In Attesa', '#FFFF00FF', 1, 1),
(39, 'In Corso', '#FFA500FF', 0, 1),
(39, 'In Ritardo', '#FF0000FF', 3, 1),
(40, 'Completate', '#00FF00FF', 2, 1),
(40, 'Eliminate', '#808080FF', 4, 0),
(40, 'In Attesa', '#FFFF00FF', 1, 1),
(40, 'In Corso', '#FFA500FF', 0, 1),
(40, 'In Ritardo', '#FF0000FF', 3, 1),
(41, 'Completate', '#00FF00FF', 2, 1),
(41, 'Eliminate', '#808080FF', 4, 0),
(41, 'In Attesa', '#FFFF00FF', 1, 1),
(41, 'In Corso', '#FFA500FF', 0, 1),
(41, 'In Ritardo', '#FF0000FF', 3, 1),
(42, 'Completate', '#00FF00FF', 2, 1),
(42, 'Eliminate', '#808080FF', 4, 0),
(42, 'In Attesa', '#FFFF00FF', 1, 1),
(42, 'In Corso', '#FFA500FF', 0, 1),
(42, 'In Ritardo', '#FF0000FF', 3, 1),
(45, 'Completate', '#00FF00FF', 2, 1),
(45, 'Eliminate', '#808080FF', 4, 0),
(45, 'In Attesa', '#FFFF00FF', 1, 1),
(45, 'In Corso', '#FFA500FF', 0, 1),
(45, 'In Ritardo', '#FF0000FF', 3, 1),
(46, 'Completate', '#00FF00FF', 2, 1),
(46, 'Eliminate', '#808080FF', 4, 0),
(46, 'In Attesa', '#FFFF00FF', 1, 1),
(46, 'In Corso', '#FFA500FF', 0, 1),
(46, 'In Ritardo', '#FF0000FF', 3, 1),
(47, 'Completate', '#00FF00FF', 2, 1),
(47, 'Eliminate', '#808080FF', 4, 0),
(47, 'In Attesa', '#FFFF00FF', 1, 1),
(47, 'In Corso', '#FFA500FF', 0, 1),
(47, 'In Ritardo', '#FF0000FF', 3, 1),
(49, 'Completate', '#00FF00FF', 2, 1),
(49, 'Eliminate', '#808080FF', 4, 0),
(49, 'In Attesa', '#FFFF00FF', 1, 1),
(49, 'In Corso', '#FFA500FF', 0, 1),
(49, 'In Ritardo', '#FF0000FF', 3, 1),
(50, 'Completate', '#00FF00FF', 2, 1),
(50, 'Eliminate', '#808080FF', 4, 0),
(50, 'In Attesa', '#FFFF00FF', 1, 1),
(50, 'In Corso', '#FFA500FF', 0, 1),
(50, 'In Ritardo', '#FF0000FF', 3, 1),
(52, 'Completate', '#00FF00FF', 2, 1),
(52, 'Eliminate', '#808080FF', 4, 0),
(52, 'In Attesa', '#FFFF00FF', 1, 1),
(52, 'In Corso', '#FFA500FF', 0, 1),
(52, 'In Ritardo', '#FF0000FF', 3, 1),
(55, 'Asd', '#4D057BFF', 5, 1),
(55, 'Completate', '#00FF00FF', 2, 1),
(55, 'Eliminate', '#808080FF', 4, 0),
(55, 'In Attesa', '#FFFF00FF', 1, 1),
(55, 'In Corso', '#FFA500FF', 0, 1),
(55, 'In Ritardo', '#FF0000FF', 3, 1),
(57, 'Completate', '#00FF00FF', 2, 1),
(57, 'Eliminate', '#808080FF', 4, 0),
(57, 'In Attesa', '#FFFF00FF', 1, 1),
(57, 'In Corso', '#FFA500FF', 0, 1),
(57, 'In Ritardo', '#FF0000FF', 3, 1),
(60, 'Completate', '#00FF00FF', 2, 1),
(60, 'Eliminate', '#808080FF', 4, 0),
(60, 'In Attesa', '#FFFF00FF', 1, 1),
(60, 'In Corso', '#FFA500FF', 0, 1),
(60, 'In Ritardo', '#FF0000FF', 3, 1),
(61, 'Completate', '#00FF00FF', 2, 1),
(61, 'Eliminate', '#808080FF', 4, 0),
(61, 'In Attesa', '#FFFF00FF', 1, 1),
(61, 'In Corso', '#FFA500FF', 0, 1),
(61, 'In Ritardo', '#FF0000FF', 3, 1),
(64, 'Completate', '#00FF00FF', 2, 1),
(64, 'Eliminate', '#808080FF', 4, 0),
(64, 'In Attesa', '#FFFF00FF', 1, 1),
(64, 'In Corso', '#FFA500FF', 0, 1),
(64, 'In Ritardo', '#FF0000FF', 3, 1),
(74, 'Completate', '#00FF00FF', 2, 1),
(74, 'Eliminate', '#808080FF', 4, 0),
(74, 'In Attesa', '#FFFF00FF', 1, 1),
(74, 'In Corso', '#FFA500FF', 0, 1),
(74, 'In Ritardo', '#FF0000FF', 3, 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `team`
--

DROP TABLE IF EXISTS `team`;
CREATE TABLE IF NOT EXISTS `team` (
  `sigla` varchar(3) NOT NULL,
  `nome` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `responsabile` varchar(255) NOT NULL,
  `numero_progetti` int(10) UNSIGNED DEFAULT 0
) ;

--
-- Dump dei dati per la tabella `team`
--

INSERT INTO `team` (`sigla`, `nome`, `responsabile`, `numero_progetti`) VALUES
('CAI', 'Copilot', 'utente.prova2@procol.com', 1),
('CRH', 'Crimson Hawks', 'francesca.neri@procol.com', 2),
('ETE', 'Ethereal Eagles', 'federico.greco@procol.com', 2),
('GFS', 'Che Cosa Fa Giando', 'imma.capuano@procol.com', 1),
('GPH', 'Golden Phoenix', 'andre.conti@procol.com', 1),
('LUF', 'Luminous Falcons', 'marco.rossi@procol.com', 2),
('MVN', 'MetaVerse Network', 'utente.prova1@procol.com', 1),
('MYT', 'Mystic Tigers', 'valentina.esposito@procol.com', 0),
('NBD', 'Nebula Dragons', 'stefano.romano@procol.com', 1),
('PCU', 'Casa Puca', 'goshin26@icloud.com', 1),
('QWO', 'Quantum Wolves', 'giulia.verdi@procol.com', 0),
('SLX', 'Silver Lynx', 'luca.bianchi@procol.com', 0);

--
-- Trigger `team`
--
DROP TRIGGER IF EXISTS `anticipo_assegna_team`;
DELIMITER $$
CREATE TRIGGER `anticipo_assegna_team` BEFORE INSERT ON `team` FOR EACH ROW BEGIN
    DECLARE capo_count INT;
    SET capo_count = (SELECT COUNT(*) FROM utenti WHERE email = NEW.responsabile AND (ruolo = 'capo_team' OR ruolo='admin'));
    IF capo_count = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'L''utente specificato non esiste o non puó essere capo del team.';
    END IF;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `associo_a_team`;
DELIMITER $$
CREATE TRIGGER `associo_a_team` AFTER INSERT ON `team` FOR EACH ROW BEGIN
    IF EXISTS (SELECT 1 FROM utenti WHERE email = NEW.responsabile AND (ruolo = 'capo_team' OR ruolo = 'admin')) THEN
        UPDATE utenti SET team = NEW.sigla WHERE email = NEW.responsabile;
    END IF;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `associo_a_team_posticipo_update`;
DELIMITER $$
CREATE TRIGGER `associo_a_team_posticipo_update` AFTER UPDATE ON `team` FOR EACH ROW BEGIN
    IF EXISTS (SELECT 1 FROM utenti WHERE email = NEW.responsabile AND (ruolo = 'capo_team' OR ruolo = 'admin')) THEN
        UPDATE utenti SET team = NEW.sigla WHERE email = NEW.responsabile;
    END IF;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `blocca_aggiornamento_team`;
DELIMITER $$
CREATE TRIGGER `blocca_aggiornamento_team` BEFORE UPDATE ON `team` FOR EACH ROW BEGIN
    DECLARE count_utenti_validi INT;
    SELECT COUNT(*) INTO count_utenti_validi FROM utenti WHERE email = NEW.responsabile AND ruolo IN ('capo_team', 'admin') AND (team IS NULL OR team = NEW.sigla);
    IF count_utenti_validi = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Errore aggiornamento: l’utente potrebbe non esistere, avere un ruolo incompatibile o appartenere già ad un team';
    END IF;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `blocca_inserimento_team`;
DELIMITER $$
CREATE TRIGGER `blocca_inserimento_team` BEFORE INSERT ON `team` FOR EACH ROW BEGIN
    DECLARE count_utenti_validi INT;
    SELECT COUNT(*) INTO count_utenti_validi FROM utenti WHERE email = NEW.responsabile AND ruolo IN ('capo_team', 'admin') AND (team IS NULL OR team = NEW.sigla);
    IF count_utenti_validi = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'L’utente potrebbe non esistere, avere un ruolo incompatibile o appartenere già ad un team. Non cambiare sigla e responsabile insieme';
    END IF;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `post_eliminazione_team`;
DELIMITER $$
CREATE TRIGGER `post_eliminazione_team` AFTER DELETE ON `team` FOR EACH ROW BEGIN 
    UPDATE utenti 
    SET team = NULL WHERE team = OLD.sigla;
END
$$
DELIMITER ;

-- --------------------------------------------------------


--
-- Struttura stand-in per le viste `vista_progetti_team`
-- (Vedi sotto per la vista effettiva)
--
DROP VIEW IF EXISTS `vista_progetti_team`;
CREATE TABLE IF NOT EXISTS `vista_progetti_team` (
`id_progetto` int(11)
,`nome` varchar(50)
,`descrizione` varchar(255)
,`scadenza` datetime
,`sigla_team` varchar(3)
,`team` varchar(20)
);

-- --------------------------------------------------------

--
-- Struttura stand-in per le viste `vista_progetti_team_utenti`
-- (Vedi sotto per la vista effettiva)
--
DROP VIEW IF EXISTS `vista_progetti_team_utenti`;
CREATE TABLE IF NOT EXISTS `vista_progetti_team_utenti` (
`id_progetto` int(11)
,`nome` varchar(50)
,`descrizione` varchar(255)
,`scadenza` datetime
,`sigla_team` varchar(3)
,`team` varchar(20)
,`email_responsabile` varchar(255)
,`anagrafica` varchar(101)
);

-- --------------------------------------------------------

--
-- Struttura stand-in per le viste `vista_schede_completate`
-- (Vedi sotto per la vista effettiva)
--
DROP VIEW IF EXISTS `vista_schede_completate`;
CREATE TABLE IF NOT EXISTS `vista_schede_completate` (
`uuid_scheda` binary(16)
,`id_progetto` int(11)
,`titolo` varchar(50)
,`stato` varchar(20)
,`spostamento` datetime
);

-- --------------------------------------------------------

--
-- Struttura stand-in per le viste `vista_schede_in_ritardo`
-- (Vedi sotto per la vista effettiva)
--
DROP VIEW IF EXISTS `vista_schede_in_ritardo`;
CREATE TABLE IF NOT EXISTS `vista_schede_in_ritardo` (
`uuid_scheda` binary(16)
,`id_progetto` int(11)
,`titolo` varchar(50)
,`stato` varchar(20)
,`spostamento` datetime
);

-- --------------------------------------------------------

--
-- Struttura stand-in per le viste `vista_team_utenti`
-- (Vedi sotto per la vista effettiva)
--
DROP VIEW IF EXISTS `vista_team_utenti`;
CREATE TABLE IF NOT EXISTS `vista_team_utenti` (
`sigla_team` varchar(3)
,`nome_team` varchar(20)
,`numero_progetti` int(10) unsigned
,`responsabile_team` varchar(255)
,`anagrafica_utente` varchar(101)
);

-- --------------------------------------------------------

--
-- Struttura per vista `vista_progetti_team`
--
DROP TABLE IF EXISTS `vista_progetti_team`;

DROP VIEW IF EXISTS `vista_progetti_team`;
CREATE OR REPLACE VIEW `vista_progetti_team`  AS SELECT `p`.`id_progetto` AS `id_progetto`, `p`.`PROGETTO` AS `nome`, `p`.`descrizione` AS `descrizione`, `p`.`scadenza` AS `scadenza`, `t`.`sigla` AS `sigla_team`, `t`.`nome` AS `team` FROM (`progetti` `p` left join `team` `t` on(`p`.`team_responsabile` = `t`.`sigla`)) ;

-- --------------------------------------------------------

--
-- Struttura per vista `vista_progetti_team_utenti`
--
DROP TABLE IF EXISTS `vista_progetti_team_utenti`;

DROP VIEW IF EXISTS `vista_progetti_team_utenti`;
CREATE OR REPLACE VIEW `vista_progetti_team_utenti`  AS SELECT `p`.`id_progetto` AS `id_progetto`, `p`.`PROGETTO` AS `nome`, `p`.`descrizione` AS `descrizione`, `p`.`scadenza` AS `scadenza`, `j`.`sigla` AS `sigla_team`, `j`.`team` AS `team`, `j`.`email_responsabile` AS `email_responsabile`, concat(`j`.`nome`,' ',`j`.`cognome`) AS `anagrafica` FROM (`progetti` `p` left join (select `t1`.`sigla` AS `sigla`,`t1`.`nome` AS `team`,`t1`.`responsabile` AS `email_responsabile`,`u1`.`nome` AS `nome`,`u1`.`cognome` AS `cognome` from (`team` `t1` left join `utenti` `u1` on(`t1`.`responsabile` = `u1`.`email`))) `j` on(`p`.`team_responsabile` = `j`.`sigla`)) ;

-- --------------------------------------------------------

--
-- Struttura per vista `vista_schede_completate`
--
DROP TABLE IF EXISTS `vista_schede_completate`;

DROP VIEW IF EXISTS `vista_schede_completate`;
CREATE OR REPLACE VIEW `vista_schede_completate`  AS SELECT `s`.`uuid_scheda` AS `uuid_scheda`, `s`.`id_progetto` AS `id_progetto`, `s`.`titolo` AS `titolo`, `s`.`stato` AS `stato`, `i`.`spostamento` AS `spostamento` FROM (`schede` `s` join `info_schede` `i` on(`s`.`uuid_scheda` = `i`.`uuid_scheda`)) WHERE `s`.`stato` = 'Completate' ;

-- --------------------------------------------------------

--
-- Struttura per vista `vista_schede_in_ritardo`
--
DROP TABLE IF EXISTS `vista_schede_in_ritardo`;

DROP VIEW IF EXISTS `vista_schede_in_ritardo`;
CREATE OR REPLACE VIEW `vista_schede_in_ritardo`  AS SELECT `s`.`uuid_scheda` AS `uuid_scheda`, `s`.`id_progetto` AS `id_progetto`, `s`.`titolo` AS `titolo`, `s`.`stato` AS `stato`, `i`.`spostamento` AS `spostamento` FROM (`schede` `s` join `info_schede` `i` on(`s`.`uuid_scheda` = `i`.`uuid_scheda`)) WHERE `s`.`stato` = 'In Ritardo' ;

-- --------------------------------------------------------

--
-- Struttura per vista `vista_team_utenti`
--
DROP TABLE IF EXISTS `vista_team_utenti`;

DROP VIEW IF EXISTS `vista_team_utenti`;
CREATE OR REPLACE VIEW `vista_team_utenti`  AS SELECT `t`.`sigla` AS `sigla_team`, `t`.`nome` AS `nome_team`, `t`.`numero_progetti` AS `numero_progetti`, `t`.`responsabile` AS `responsabile_team`, concat(`u`.`cognome`,' ',`u`.`nome`) AS `anagrafica_utente` FROM (`team` `t` left join `utenti` `u` on(`t`.`responsabile` = `u`.`email`)) ;

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `commenti`
--
ALTER TABLE `commenti`
  ADD PRIMARY KEY (`uuid_commento`),
  ADD KEY `uuid_scheda` (`uuid_scheda`),
  ADD KEY `mittente` (`mittente`),
  ADD KEY `destinatario` (`destinatario`);

--
-- Indici per le tabelle `info_schede`
--
ALTER TABLE `info_schede`
  ADD PRIMARY KEY (`uuid_scheda`),
  ADD KEY `incaricato` (`incaricato`),
  ADD KEY `spostato_da` (`spostato_da`),
  ADD KEY `modificato_da` (`modificato_da`);

--
-- Indici per le tabelle `progetti`
--
ALTER TABLE `progetti`
  ADD PRIMARY KEY (`id_progetto`),
  ADD UNIQUE KEY `PROGETTO` (`PROGETTO`),
  ADD KEY `team_responsabile` (`team_responsabile`);

--
-- Indici per le tabelle `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`uuid_report`),
  ADD KEY `attore` (`attore`),
  ADD KEY `utente` (`utente`),
  ADD KEY `team` (`team`),
  ADD KEY `progetto` (`progetto`),
  ADD KEY `scheda` (`scheda`);

--
-- Indici per le tabelle `schede`
--
ALTER TABLE `schede`
  ADD PRIMARY KEY (`uuid_scheda`),
  ADD UNIQUE KEY `id_progetto` (`id_progetto`,`stato`,`ordine_schede`),
  ADD KEY `autore` (`autore`);

--
-- Indici per le tabelle `stati`
--
ALTER TABLE `stati`
  ADD PRIMARY KEY (`id_progetto`,`stato`),
  ADD UNIQUE KEY `id_progetto` (`id_progetto`,`ordine_stati`);

--
-- Indici per le tabelle `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`sigla`),
  ADD UNIQUE KEY `responsabile` (`responsabile`),
  ADD UNIQUE KEY `nome` (`nome`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`uuid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `progetti`
--
ALTER TABLE `progetti`
  MODIFY `id_progetto` int(11) NOT NULL AUTO_INCREMENT;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella utenti
--

ALTER TABLE `utenti`
  ADD CONSTRAINT `valida_nome` CHECK (`nome` REGEXP '^[a-zA-ZÀ-ÿ](?:[a-zA-ZÀ-ÿ\'\\s]{0,48}[a-zA-ZÀ-ÿ])?$'),
  ADD CONSTRAINT `valida_cognome` CHECK (`cognome` REGEXP '^[a-zA-ZÀ-ÿ](?:[a-zA-ZÀ-ÿ\'\\s]{0,48}[a-zA-ZÀ-ÿ])?$'),
  ADD CONSTRAINT `valida_genere` CHECK (`genere` = 'maschio' OR `genere` = 'femmina'),
  ADD CONSTRAINT `valida_email` CHECK (`email` REGEXP '^[a-zA-Z0-9]+([._-][a-zA-Z0-9]+)*@[a-zA-Z0-9]+([._-][a-zA-Z0-9]+)*.[a-zA-Z]{2,4}$'),
  ADD CONSTRAINT `valida_password` CHECK (LENGTH(`password`) >= 8);

--
-- Limiti per la tabella `team`
--
ALTER TABLE `team`
  ADD CONSTRAINT `team_ibfk_1` FOREIGN KEY (`responsabile`) REFERENCES `utenti` (`email`),
  ADD CONSTRAINT `valida_sigla` CHECK (`sigla` REGEXP '^[a-zA-Z0-9]{1,3}$'),
  ADD CONSTRAINT `valida_nome_team` CHECK (`nome` REGEXP '^[a-zA-ZÀ-ÿ](?:[a-zA-ZÀ-ÿ\'\\s]{0,18}[a-zA-ZÀ-ÿ])?$');

--
-- Limiti per la tabella `progetti`
--
ALTER TABLE `progetti`
  ADD CONSTRAINT `progetti_ibfk_1` FOREIGN KEY (`team_responsabile`) REFERENCES `team` (`sigla`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `valida_nome_progetto` CHECK (`progetto` REGEXP '^[a-zA-ZÀ-ÿ](?:[a-zA-ZÀ-ÿ\'\\s]{0,48}[a-zA-ZÀ-ÿ])?$');

--
-- Limiti per la tabella `stati`
--
ALTER TABLE `stati`
  ADD CONSTRAINT `stati_ibfk_1` FOREIGN KEY (`id_progetto`) REFERENCES `progetti` (`id_progetto`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `valida_stato` CHECK (`stato` REGEXP '^[a-zA-Z0-9]{1}[a-zA-Z0-9\\s]{0,19}$'),
  ADD CONSTRAINT `valida_colore_hex` CHECK (`colore_hex` REGEXP '^#[0-9a-fA-F]{8}$');

ALTER TABLE `schede`
  ADD CONSTRAINT `schede_ibfk_1` FOREIGN KEY (`autore`) REFERENCES `utenti` (`email`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `schede_ibfk_2` FOREIGN KEY (`id_progetto`,`stato`) REFERENCES `stati` (`id_progetto`, `stato`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `valida_stato` CHECK (`stato` REGEXP '^[a-zA-Z0-9]{1}[a-zA-Z0-9\\s]{0,19}$'),
  ADD CONSTRAINT `valida_titolo` CHECK (`titolo` REGEXP '^[a-zA-Z0-9]{1}[$£€¥&@#ÀàÁáÂâÃãÄäÅåÆæÇçÈèÉéÊêËëÌìÍíÎîÏïÐðÑñÒòÓóÔôÕõÖöØøÙùÚúÛûÜüÝýÞþßÿa-zA-Z0-9 \\s \' . , : ; ! ? \\% -]{0,49}$');

--
-- Limiti per la tabella `commenti`
--
ALTER TABLE `commenti`
  ADD CONSTRAINT `commenti_ibfk_1` FOREIGN KEY (`uuid_scheda`) REFERENCES `schede` (`uuid_scheda`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `commenti_ibfk_2` FOREIGN KEY (`mittente`) REFERENCES `utenti` (`email`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `commenti_ibfk_3` FOREIGN KEY (`destinatario`) REFERENCES `utenti` (`email`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT valida_fragment CHECK (uuid_in_risposta REGEXP '^[0-9a-fA-F]{32}$');

--
-- Limiti per la tabella `info_schede`
--
ALTER TABLE `info_schede`
  ADD CONSTRAINT `info_schede_ibfk_1` FOREIGN KEY (`uuid_scheda`) REFERENCES `schede` (`uuid_scheda`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `info_schede_ibfk_2` FOREIGN KEY (`incaricato`) REFERENCES `utenti` (`email`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `info_schede_ibfk_3` FOREIGN KEY (`spostato_da`) REFERENCES `utenti` (`email`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `info_schede_ibfk_4` FOREIGN KEY (`modificato_da`) REFERENCES `utenti` (`email`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Limiti per la tabella `report`
--
ALTER TABLE `report`
  ADD CONSTRAINT `report_ibfk_1` FOREIGN KEY (`attore`) REFERENCES `utenti` (`email`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `report_ibfk_2` FOREIGN KEY (`utente`) REFERENCES `utenti` (`email`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `report_ibfk_3` FOREIGN KEY (`team`) REFERENCES `team` (`sigla`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `report_ibfk_4` FOREIGN KEY (`progetto`) REFERENCES `progetti` (`id_progetto`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `report_ibfk_5` FOREIGN KEY (`scheda`) REFERENCES `schede` (`uuid_scheda`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `valida_link` CHECK (`link` REGEXP '^[a-zA-Z0-9\\-._~:/?#[\\]@!$&\'()*+,;=%]{0,255}$');

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
SET FOREIGN_KEY_CHECKS = 1;
